package com.ssd.mvd.personidentificationservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonIdentificationServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
