package com.ssd.mvd.personidentificationservice.publisher;

import com.ssd.mvd.personidentificationservice.request.RequestForModelOfAddress;
import com.ssd.mvd.personidentificationservice.entity.modelForFioOfPerson.FIO;
import com.ssd.mvd.personidentificationservice.request.RequestForWorkbook;
import com.ssd.mvd.personidentificationservice.request.RequestForPassport;
import com.ssd.mvd.personidentificationservice.inspectors.LogInspector;
import com.ssd.mvd.personidentificationservice.request.RequestForFio;
import com.ssd.mvd.personidentificationservice.controller.SerDes;

import org.reactivestreams.Subscription;
import org.reactivestreams.Subscriber;
import org.reactivestreams.Publisher;

public final class CustomPublisherForRequest extends LogInspector implements Publisher< String > {
    private final String value;

    public CustomPublisherForRequest ( final Integer integer, final Object object ) {
        this.value = SerDes
            .getSerDes()
            .getGson()
            .toJson( switch ( integer ) {
                case 1 -> new RequestForFio( (FIO) object );
                case 2 -> new RequestForPassport( String.valueOf( object ) );
                case 3 -> new RequestForWorkbook( String.valueOf( object ) );
                default -> new RequestForModelOfAddress( String.valueOf( object ) ); } ); }

    @Override
    public void subscribe( final Subscriber subscriber ) { subscriber.onSubscribe( new Subscription() {
        @Override
        public void request( final long l ) {
            subscriber.onNext( value );
            subscriber.onComplete(); }

        @Override
        public void cancel() { subscriber.onError( new Exception( "Message was not sent!!!" ) ); } } ); }
}
