package com.ssd.mvd.personidentificationservice.entity;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class Image {
    private String image;
}
