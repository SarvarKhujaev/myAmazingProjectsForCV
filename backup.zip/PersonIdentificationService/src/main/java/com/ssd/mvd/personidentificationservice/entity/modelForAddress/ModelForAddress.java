package com.ssd.mvd.personidentificationservice.entity.modelForAddress;

import com.ssd.mvd.personidentificationservice.constants.ErrorResponse;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import java.util.List;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public final class ModelForAddress {
    private com.ssd.mvd.personidentificationservice.entity.modelForPassport.RequestGuid RequestGuid;
    private PermanentRegistration PermanentRegistration;
    @JsonDeserialize
    private List< com.ssd.mvd.personidentificationservice.entity.modelForAddress.TemproaryRegistration > TemproaryRegistration;

    private ErrorResponse errorResponse;

    public ModelForAddress ( final ErrorResponse errorResponse ) { this.setErrorResponse( errorResponse ); }
}