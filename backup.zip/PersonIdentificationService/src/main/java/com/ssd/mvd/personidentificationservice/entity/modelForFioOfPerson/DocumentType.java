package com.ssd.mvd.personidentificationservice.entity.modelForFioOfPerson;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public final class DocumentType {
    private String Value;
    private Integer Id;
}
