package com.ssd.mvd.personidentificationservice.entity.modelForFioOfPerson;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public final class Region {
    private Integer Id;
    private String Value;
}
