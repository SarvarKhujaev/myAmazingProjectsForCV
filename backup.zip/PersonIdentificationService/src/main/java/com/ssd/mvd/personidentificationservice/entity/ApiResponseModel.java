package com.ssd.mvd.personidentificationservice.entity;

import java.util.List;

@lombok.Data
@lombok.Builder
public final class ApiResponseModel {
    private Integer count;
    private final List< PsychologyCard > persons;
}
