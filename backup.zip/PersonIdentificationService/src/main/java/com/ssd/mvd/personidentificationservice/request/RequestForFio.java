package com.ssd.mvd.personidentificationservice.request;

import com.ssd.mvd.personidentificationservice.entity.modelForFioOfPerson.FIO;
import java.util.Locale;

@lombok.Data
public final class RequestForFio {
    private final String Name;
    private final String Surname;
    private final String Patronym;

    public RequestForFio ( final FIO fio ) {
        this.Patronym = fio.getPatronym().toUpperCase( Locale.ROOT );
        this.Surname = fio.getSurname().toUpperCase( Locale.ROOT );
        this.Name = fio.getName().toUpperCase( Locale.ROOT ); }
}
