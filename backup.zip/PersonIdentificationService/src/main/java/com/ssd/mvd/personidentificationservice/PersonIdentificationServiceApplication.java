package com.ssd.mvd.personidentificationservice;

import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;
import com.ssd.mvd.personidentificationservice.controller.SerDes;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PersonIdentificationServiceApplication {
    public static ApplicationContext context;

    public static void main( String[] args ) {
        context = SpringApplication.run( PersonIdentificationServiceApplication.class, args );
        SerDes.getSerDes(); }
}
