package com.ssd.mvd.personidentificationservice.controller;

import com.ssd.mvd.personidentificationservice.entity.modelForFioOfPerson.FIO;
import com.ssd.mvd.personidentificationservice.component.FindFaceComponent;
import com.ssd.mvd.personidentificationservice.entity.ApiResponseModel;
import com.ssd.mvd.personidentificationservice.inspectors.LogInspector;
import com.ssd.mvd.personidentificationservice.entity.PsychologyCard;
import com.ssd.mvd.personidentificationservice.entity.e_mehnat.Data;
import com.ssd.mvd.personidentificationservice.constants.Methods;
import com.ssd.mvd.personidentificationservice.constants.Errors;
import com.ssd.mvd.personidentificationservice.entity.Image;

import com.googlecode.jsonrpc4j.spring.AutoJsonRpcServiceImpl;
import com.googlecode.jsonrpc4j.JsonRpcService;
import org.springframework.stereotype.Service;
import com.googlecode.jsonrpc4j.JsonRpcMethod;
import com.googlecode.jsonrpc4j.JsonRpcParam;
import java.util.Collections;

@Service
@AutoJsonRpcServiceImpl
@JsonRpcService( value = "/api/v1/card" )
public final class RequestController extends LogInspector {
    @JsonRpcMethod( value = "image.by.pinfl" ) // по пинфл возвращает фото человека
    public Image getImageByPinfl ( @JsonRpcParam( value = "pinfl" ) final String pinfl ) {
        super.logging( pinfl, Methods.IMAGE_BY_PINFL );
        return SerDes.getSerDes().getFlag()
                ? new Image( SerDes
                .getSerDes()
                .getGetImageByPinfl()
                .apply( pinfl )
                .block() )
                : new Image(); }

    @JsonRpcMethod( value = "list.by.name" ) // находит данные по ФИО человека
    public ApiResponseModel getPersonTotalDataByFIO ( @JsonRpcParam( value = "fio" ) final FIO fio ) {
        super.logging( fio, Methods.LIST_BY_NAME );
        return SerDes.getSerDes().getFlag()
                ? super.getResponse.apply(
                        SerDes
                                .getSerDes()
                                .getGetPersonTotalDataByFIO()
                                .apply( fio )
                                .block() )
                : super.getErrorResponse.get(); }

    @JsonRpcMethod( value = "list.by.pinfl" ) // находит данные по пинфл человека
    public ApiResponseModel getPersonTotalDataByPinfl ( @JsonRpcParam( value = "pinfl" ) final String pinfl ) {
        super.logging( pinfl, Methods.LIST_BY_PINFL );
        return SerDes.getSerDes().getFlag()
                ? super.checkData.test( 1, pinfl )
                ? super.getResponse.apply(
                        Collections.singletonList(
                                SerDes
                                        .getSerDes()
                                        .getGetPsychologyCardByPinfl()
                                        .apply( pinfl )
                                        .block() ) )
                : super.getErrorResponse.get()
                : super.getErrorResponse.get(); }

    @JsonRpcMethod( value = "list.by.photo" ) // находит данные по фотке человека
    public ApiResponseModel getPsychologyCardByImage ( @JsonRpcParam( value = "photo" ) final String photo ) {
        super.logging( photo.length(), Methods.LIST_BY_PHOTO );
        return SerDes.getSerDes().getFlag()
                ? super.checkData.test( 1, photo )
                ? super.getResponse.apply(
                        FindFaceComponent
                                .getInstance()
                                .getGetPapilonList()
                                .apply( photo )
                                .filter( value -> super.checkData.test( 2, value.getResults() ) )
                                .flatMap( results -> SerDes
                                        .getSerDes()
                                        .getGetPsychologyCardByImage()
                                        .apply( results ) )
                        .block() )
                : super.getErrorResponse.get()
                : super.getErrorResponse.get(); }

    @JsonRpcMethod( value = "list.by.passport" ) // находит данные по номеру паспорта и дате рождения
    public ApiResponseModel getPersonDataByPassportSeriesAndBirthdate (
            @JsonRpcParam( value = "birthDate" ) final String birthDate,
            @JsonRpcParam( value = "passNumber" ) final String passNumber,
            @JsonRpcParam( value = "passSerial" ) final String passSerial ) {
        super.logging( birthDate + " : " + passNumber + " : " + passSerial, Methods.LIST_BY_PASSPORT );
        return super.checkData.test( 1, birthDate )
                && super.checkData.test( 1, passNumber )
                && super.checkData.test( 1, passSerial )
                ? SerDes.getSerDes().getFlag()
                ? super.getResponse.apply(
                        Collections.singletonList( SerDes
                                .getSerDes()
                                .getGetModelForPassport()
                                .apply( passSerial + passNumber, birthDate )
                                .flatMap( data -> SerDes
                                        .getSerDes()
                                        .getGetPsychologyCardByData()
                                        .apply( data ) )
                                .onErrorResume( io.netty.handler.timeout.ReadTimeoutException.class,
                                        throwable -> super.convert( new PsychologyCard() ) )
                                .onErrorReturn( new PsychologyCard() )
                                .block() ) )
                : super.getErrorResponse.get()
                : super.getErrorResponse.get(); }

    @JsonRpcMethod( value = "workbook.by.pinfl" )
    public Data getWorkbook ( @JsonRpcParam( value = "pinfl" ) final String pinfl ) {
        return SerDes
                .getSerDes()
                .getGetWorkExperience()
                .apply( pinfl )
                .onErrorReturn( new Data( super.error.apply( Errors.SERVICE_WORK_ERROR.name(), 2 ) ) )
                .block(); }
}