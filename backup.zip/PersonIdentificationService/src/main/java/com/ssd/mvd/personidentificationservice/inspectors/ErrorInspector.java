package com.ssd.mvd.personidentificationservice.inspectors;

import com.ssd.mvd.personidentificationservice.entity.modelForPassport.ModelForPassport;
import com.ssd.mvd.personidentificationservice.entity.modelForAddress.ModelForAddress;
import com.ssd.mvd.personidentificationservice.entityForLogging.IntegratedServiceApis;
import com.ssd.mvd.personidentificationservice.entityForLogging.ErrorLog;
import com.ssd.mvd.personidentificationservice.constants.ErrorResponse;
import com.ssd.mvd.personidentificationservice.entity.ApiResponseModel;
import com.ssd.mvd.personidentificationservice.kafka.KafkaDataControl;
import com.ssd.mvd.personidentificationservice.entity.PsychologyCard;
import com.ssd.mvd.personidentificationservice.kafka.Notification;
import com.ssd.mvd.personidentificationservice.constants.Methods;
import com.ssd.mvd.personidentificationservice.controller.SerDes;
import com.ssd.mvd.personidentificationservice.constants.Errors;
import com.ssd.mvd.personidentificationservice.entity.Pinpp;

import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;
import reactor.core.publisher.Mono;

import java.util.Collections;
import java.util.List;
import java.util.Date;

public class ErrorInspector extends DataValidateInspector {
    private final Notification notification = new Notification();

    private Notification getNotification () { return this.notification; }

    protected final BiFunction< String, Integer, ErrorResponse > error = ( error, value ) -> ErrorResponse
            .builder()
            .message( switch ( value ) {
                case 1 -> "Error in external service: " + error;
                case 2 -> "Service error: " + error;
                case 3 -> "Data for: " + error + " was not found";
                case 4 -> "Connection Error: " + error;
                default -> "Service: " + error + " does not return response!!!"; } )
            .errors( switch ( value ) {
                case 1 -> Errors.EXTERNAL_SERVICE_500_ERROR;
                case 2 -> Errors.SERVICE_WORK_ERROR;
                case 3 -> Errors.DATA_NOT_FOUND;
                case 4 -> Errors.RESPONSE_FROM_SERVICE_NOT_RECEIVED;
                default -> Errors.TOO_MANY_RETRIES_ERROR; } )
            .build();

    protected final Supplier< ApiResponseModel > getErrorResponse = () -> {
            SerDes.getSerDes().getUpdateTokens().get();
            return ApiResponseModel
                    .builder()
                    .count( 0 )
                    .persons( Collections.singletonList( new PsychologyCard() ) )
                    .build(); };

    protected final Function< List< PsychologyCard >, ApiResponseModel > getResponse = psychologyCardList ->
            ApiResponseModel
                    .builder()
                    .count( psychologyCardList.size() )
                    .persons( psychologyCardList )
                    .build();

    // логирует любые ошибки
    protected void saveErrorLog ( final String methodName,
                                final String params,
                                final String reason ) {
            this.getNotification().setPinfl( params );
            this.getNotification().setReason( reason );
            this.getNotification().setMethodName( methodName );
            this.getNotification().setCallingTime( new Date() );
            KafkaDataControl
                    .getInstance()
                    .getWriteErrorLog()
                    .accept( SerDes
                            .getSerDes()
                            .getGson()
                            .toJson( this.getNotification() ) ); }

    // отправляет ошибку на сервис Шамсиддина, в случае если какой - либо сервис не отвечает
    protected void saveErrorLog ( final String errorMessage ) {
            KafkaDataControl
                    .getInstance()
                    .getWriteToKafkaErrorLog()
                    .accept( SerDes
                            .getSerDes()
                            .getGson()
                            .toJson( ErrorLog
                                    .builder()
                                    .errorMessage( errorMessage )
                                    .createdAt( new Date().getTime() )
                                    .integratedService( IntegratedServiceApis.OVIR.getName() )
                                    .integratedServiceApiDescription( IntegratedServiceApis.OVIR.getDescription() )
                                    .build() ) ); }

    // saves error from external service
    protected final BiFunction< String, Methods, Mono< ? > > saveErrorLog = ( errorMessage, methods ) -> {
            KafkaDataControl
                    .getInstance()
                    .getWriteToKafkaErrorLog()
                    .accept( SerDes
                            .getSerDes()
                            .getGson()
                            .toJson( ErrorLog
                                    .builder()
                                    .errorMessage( errorMessage )
                                    .createdAt( new Date().getTime() )
                                    .integratedService( IntegratedServiceApis.OVIR.getName() )
                                    .integratedServiceApiDescription( IntegratedServiceApis.OVIR.getDescription() )
                                    .build() ) );
            return super.convert( switch ( methods ) {
                case GET_MODEL_FOR_PASSPORT -> new ModelForPassport( this.error.apply( errorMessage, 1 ) );
                case GET_MODEL_FOR_ADDRESS -> new ModelForAddress( this.error.apply( errorMessage, 1 ) );
                case GET_PINPP -> new Pinpp( this.error.apply( errorMessage, 1 ) );
                default -> Errors.EXTERNAL_SERVICE_500_ERROR.name(); } ); };
}
