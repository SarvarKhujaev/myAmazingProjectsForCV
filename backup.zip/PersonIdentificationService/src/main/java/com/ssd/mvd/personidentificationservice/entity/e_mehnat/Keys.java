package com.ssd.mvd.personidentificationservice.entity.e_mehnat;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import java.util.List;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public final class Keys {
    private Diploms diploms;
    @JsonDeserialize
    private List< Workbook > workbook;
}
