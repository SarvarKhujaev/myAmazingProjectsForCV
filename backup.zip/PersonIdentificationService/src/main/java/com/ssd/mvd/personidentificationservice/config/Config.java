package com.ssd.mvd.personidentificationservice.config;

import com.ssd.mvd.personidentificationservice.PersonIdentificationServiceApplication;
import com.ssd.mvd.personidentificationservice.inspectors.LogInspector;

import java.util.HashMap;
import java.util.Map;

public class Config extends LogInspector {
    public Boolean getFlag() { return this.flag; }

    protected void setFlag ( final Boolean flag ) { this.flag = flag; }

    protected String getTokenForGai() { return this.tokenForGai; }

    protected void setTokenForGai ( final String tokenForGai ) { this.tokenForGai = tokenForGai; }

    protected String getTokenForFio() { return this.tokenForFio; }

    protected String getTokenForPassport() { return this.tokenForPassport; }

    protected void setTokenForPassport ( final String tokenForPassport ) { this.tokenForPassport = tokenForPassport; }

    protected Integer getWaitingMins() { return this.waitingMins; }

    protected void setWaitingMins ( final Integer waitingMins ) { this.waitingMins = waitingMins; }

    protected String getLOGIN_FOR_GAI_TOKEN() { return this.LOGIN_FOR_GAI_TOKEN; }

    protected String getCURRENT_SYSTEM_FOR_GAI() { return this.CURRENT_SYSTEM_FOR_GAI; }

    protected String getPASSWORD_FOR_GAI_TOKEN() { return this.PASSWORD_FOR_GAI_TOKEN; }

    protected String getAPI_FOR_GAI_TOKEN() { return this.API_FOR_GAI_TOKEN; }

    protected String getAPI_FOR_PINPP() { return this.API_FOR_PINPP; }

    protected String getAPI_FOR_PERSON_IMAGE() { return this.API_FOR_PERSON_IMAGE; }

    protected String getAPI_FOR_PASSPORT_MODEL() { return this.API_FOR_PASSPORT_MODEL; }

    protected String getAPI_FOR_MODEL_FOR_ADDRESS() { return this.API_FOR_MODEL_FOR_ADDRESS; }

    protected String getAPI_FOR_PERSON_DATA_FROM_ZAKS() { return this.API_FOR_PERSON_DATA_FROM_ZAKS; }

    protected String getERROR_LOGS() { return this.ERROR_LOGS; }

    protected String getADMIN_PANEL() { return this.ADMIN_PANEL; }

    protected String getADMIN_PANEL_ERROR_LOG() { return this.ADMIN_PANEL_ERROR_LOG; }

    private final Map< String, Object > fields = new HashMap<>();
    private final Map< String, String > headers = new HashMap<>();

    protected Map< String, Object > getFields() { return this.fields; }

    protected Map< String, String > getHeaders() { return this.headers; }

    private Boolean flag = true;
    private String tokenForGai;
    private String tokenForFio;
    private String tokenForPassport;
    // how many minutes to wait for Thread in SerDes class
    // 180 mins by default
    private Integer waitingMins = 180;

    private final String LOGIN_FOR_GAI_TOKEN = PersonIdentificationServiceApplication
            .context
            .getEnvironment()
            .getProperty( "variables.GAI_VARIABLES.LOGIN_FOR_GAI_TOKEN" );

    private final String CURRENT_SYSTEM_FOR_GAI = PersonIdentificationServiceApplication
            .context
            .getEnvironment()
            .getProperty( "variables.GAI_VARIABLES.CURRENT_SYSTEM_FOR_GAI" );

    private final String PASSWORD_FOR_GAI_TOKEN = PersonIdentificationServiceApplication
            .context
            .getEnvironment()
            .getProperty( "variables.GAI_VARIABLES.PASSWORD_FOR_GAI_TOKEN" );

    private final String API_FOR_GAI_TOKEN = PersonIdentificationServiceApplication
            .context
            .getEnvironment()
            .getProperty( "variables.GAI_VARIABLES.API_FOR_GAI_TOKEN" );

    private final String API_FOR_PINPP = PersonIdentificationServiceApplication
            .context
            .getEnvironment()
            .getProperty( "variables.OVIR_VARIABLES.API_FOR_PINPP" );

    private final String API_FOR_PERSON_IMAGE = PersonIdentificationServiceApplication
            .context
            .getEnvironment()
            .getProperty( "variables.OVIR_VARIABLES.API_FOR_PERSON_IMAGE" );

    private final String API_FOR_PASSPORT_MODEL = PersonIdentificationServiceApplication
            .context
            .getEnvironment()
            .getProperty( "variables.OVIR_VARIABLES.API_FOR_PASSPORT_MODEL" );

    private final String API_FOR_MODEL_FOR_ADDRESS = PersonIdentificationServiceApplication
            .context
            .getEnvironment()
            .getProperty( "variables.OVIR_VARIABLES.API_FOR_MODEL_FOR_ADDRESS" );

    private final String API_FOR_PERSON_DATA_FROM_ZAKS = PersonIdentificationServiceApplication
            .context
            .getEnvironment()
            .getProperty( "variables.OVIR_VARIABLES.API_FOR_PERSON_DATA_FROM_ZAKS" );

    private final String ERROR_LOGS = PersonIdentificationServiceApplication
            .context
            .getEnvironment()
            .getProperty( "variables.KAFKA_VARIABLES.KAFKA_TOPICS.ERROR_LOGS" );

    private final String ADMIN_PANEL = PersonIdentificationServiceApplication
            .context
            .getEnvironment()
            .getProperty( "variables.KAFKA_VARIABLES.KAFKA_TOPICS.ADMIN_PANEL" );

    private final String ADMIN_PANEL_ERROR_LOG = PersonIdentificationServiceApplication
            .context
            .getEnvironment()
            .getProperty( "variables.KAFKA_VARIABLES.KAFKA_TOPICS.ADMIN_PANEL_ERROR_LOG" );
}
