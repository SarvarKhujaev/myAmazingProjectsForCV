package com.ssd.mvd.personidentificationservice.controller;

import com.ssd.mvd.personidentificationservice.entity.modelForFioOfPerson.PersonTotalDataByFIO;
import com.ssd.mvd.personidentificationservice.entity.modelForPassport.ModelForPassport;
import com.ssd.mvd.personidentificationservice.entity.modelForAddress.ModelForAddress;
import com.ssd.mvd.personidentificationservice.publisher.CustomPublisherForRequest;
import com.ssd.mvd.personidentificationservice.entity.modelForFioOfPerson.FIO;
import com.ssd.mvd.personidentificationservice.entity.e_mehnat.Data;
import com.ssd.mvd.personidentificationservice.constants.Methods;
import com.ssd.mvd.personidentificationservice.constants.Errors;
import com.ssd.mvd.personidentificationservice.config.Config;
import com.ssd.mvd.personidentificationservice.entity.*;

import com.mashape.unirest.http.exceptions.UnirestException;
import com.mashape.unirest.http.ObjectMapper;
import com.mashape.unirest.http.Unirest;

import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import io.netty.channel.ConnectTimeoutException;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.SslProvider;
import io.netty.handler.ssl.SslContext;
import javax.net.ssl.*;

import reactor.netty.transport.logging.AdvancedByteBufFormat;
import reactor.netty.http.client.HttpClient;
import reactor.netty.ByteBufFlux;
import reactor.util.retry.Retry;

import com.fasterxml.jackson.core.JsonProcessingException;
import io.netty.handler.logging.LogLevel;
import com.google.gson.Gson;

import reactor.core.scheduler.Schedulers;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.concurrent.TimeUnit;
import java.util.function.BiFunction;
import java.util.function.Supplier;
import java.util.function.Function;
import java.time.Duration;
import java.util.*;

@lombok.Data
public final class SerDes extends Config implements Runnable {
    private Thread thread;
    private final Gson gson = new Gson();
    private static SerDes serDes = new SerDes();
    private final HttpClient httpClient = HttpClient
            .create()
            .responseTimeout( Duration.ofSeconds( 30 ) )
            .headers( h -> h.add( "Content-Type", "application/json" ) )
            .wiretap( "reactor.netty.http.client.HttpClient", LogLevel.DEBUG, AdvancedByteBufFormat.TEXTUAL );

    public static SerDes getSerDes () { return serDes != null ? serDes : ( serDes = new SerDes() ); }

    private SerDes () {
        Unirest.setObjectMapper( new ObjectMapper() {
            private final com.fasterxml.jackson.databind.ObjectMapper objectMapper = new com.fasterxml.jackson.databind.ObjectMapper();

            @Override
            public String writeValue( final Object o ) {
                try { return this.objectMapper.writeValueAsString( o ); }
                catch ( final JsonProcessingException e ) { throw new RuntimeException(e); } }

            @Override
            public <T> T readValue( final String s, final Class<T> aClass ) {
                try { return this.objectMapper.readValue( s, aClass ); }
                catch ( final JsonProcessingException e ) { throw new RuntimeException(e); } } } );
        this.getHeaders().put( "accept", "application/json" );
        this.setThread( new Thread( this, this.getClass().getName() ) );
        this.getThread().start(); }

    private final Supplier< SerDes > updateTokens = () -> {
        super.logging( "Updating tokens..." );
        super.getFields().put( "Login", super.getLOGIN_FOR_GAI_TOKEN() );
        super.getFields().put( "Password" , super.getPASSWORD_FOR_GAI_TOKEN() );
        super.getFields().put( "CurrentSystem", super.getCURRENT_SYSTEM_FOR_GAI() );
        try { super.setTokenForGai( String.valueOf( Unirest.post( super.getAPI_FOR_GAI_TOKEN() )
                .fields( this.getFields() )
                .asJson()
                .getBody()
                .getObject()
                .get( "access_token" ) ) );
            super.setTokenForPassport( super.getTokenForGai() );
            super.setWaitingMins( 180 );
            super.setFlag( true );
            return this; }
        catch ( final UnirestException e ) {
            super.setFlag( false );
            super.setWaitingMins( 3 );
            super.saveErrorLog( e.getMessage() );
            super.saveErrorLog( Methods.UPDATE_TOKENS.name(), "access_token", "Error: " + e.getMessage() ); }
        return this; };

    private final Function< String, Mono< Pinpp > > getPinpp = pinfl -> this.getHttpClient()
            .headers( h -> h.add( "Authorization", "Bearer " + super.getTokenForPassport() ) )
            .get()
            .uri( super.getAPI_FOR_PINPP() + pinfl )
            .responseSingle( ( res, content ) -> switch ( res.status().code() ) {
                case 401 -> this.getUpdateTokens().get().getGetPinpp().apply( pinfl );
                case 500 | 501 | 502 | 503 -> ( Mono< Pinpp > ) super.saveErrorLog.apply( res.status().toString(), Methods.GET_PINPP );
                default -> super.checkResponse.test( res, content )
                        ? content
                        .asString()
                        .map( s -> this.getGson().fromJson( s, Pinpp.class ) )
                        : super.convert( new Pinpp( super.error.apply( pinfl, 3 ) ) ); } )
            .retryWhen( Retry.backoff( 2, Duration.ofSeconds( 3 ) )
                    .doBeforeRetry( retrySignal -> super.logging( retrySignal, Methods.GET_PINPP ) )
                    .doAfterRetry( retrySignal -> super.logging( Methods.GET_PINPP, retrySignal ) )
                    .onRetryExhaustedThrow( ( retryBackoffSpec, retrySignal ) -> new IllegalArgumentException() ) )
            .onErrorResume( io.netty.channel.ConnectTimeoutException.class,
                    throwable -> super.convert( new Pinpp( super.error.apply( throwable.getMessage(), 4 ) ) ) )
            .onErrorResume( IllegalArgumentException.class,
                    throwable -> super.convert( new Pinpp( super.error.apply( Methods.GET_PINPP.name(), 5 ) ) ) )
            .doOnError( throwable -> super.logging( throwable, Methods.GET_PINPP, pinfl ) )
            .doOnSuccess( value -> super.logging( Methods.GET_PINPP, value ) )
            .doOnSubscribe( value -> super.logging( super.getAPI_FOR_PINPP() ) );

    private final Function< String, Mono< String > > getImageByPinfl = pinfl -> this.getHttpClient()
            .headers( h -> h.add( "Authorization", "Bearer " + super.getTokenForGai() ) )
            .get()
            .uri( super.getAPI_FOR_PERSON_IMAGE() + pinfl )
            .responseSingle( ( res, content ) -> switch ( res.status().code() ) {
                case 401 -> this.getUpdateTokens().get().getGetImageByPinfl().apply( pinfl );
                case 501 | 502 | 503 -> ( Mono< String > ) super.saveErrorLog.apply( res.status().toString(), Methods.GET_IMAGE_BY_PINFL );
                default -> super.checkResponse.test( res, content )
                        ? content
                        .asString()
                        .map( s -> s.substring( s.indexOf( "Data" ) + 7, s.indexOf( ",\"AnswereId" ) - 1 ) )
                        : super.convert( Errors.DATA_NOT_FOUND.name() ); } )
            .retryWhen( Retry.backoff( 2, Duration.ofSeconds( 3 ) )
                    .doBeforeRetry( retrySignal -> super.logging( retrySignal, Methods.GET_IMAGE_BY_PINFL ) )
                    .doAfterRetry( retrySignal -> super.logging( Methods.GET_IMAGE_BY_PINFL, retrySignal ) )
                    .onRetryExhaustedThrow( ( retryBackoffSpec, retrySignal ) -> new IllegalArgumentException() ) )
            .onErrorResume( io.netty.channel.ConnectTimeoutException.class,
                    throwable -> super.convert( Errors.RESPONSE_FROM_SERVICE_NOT_RECEIVED + " : " + throwable.getMessage() ) )
            .onErrorResume( IllegalArgumentException.class,
                    throwable -> super.convert( Errors.TOO_MANY_RETRIES_ERROR + " : " + throwable.getMessage() ) )
            .doOnError( e -> super.logging( e, Methods.GET_IMAGE_BY_PINFL, pinfl ) )
            .doOnSubscribe( value -> super.logging( super.getAPI_FOR_PERSON_IMAGE() ) )
            .onErrorReturn( Errors.DATA_NOT_FOUND.name() );

    private final Function< String, Mono< ModelForAddress > > getModelForAddress = pinfl -> this.getHttpClient()
            .headers( h -> h.add( "Authorization", "Bearer " + super.getTokenForGai() ) )
            .post()
            .uri( super.getAPI_FOR_MODEL_FOR_ADDRESS() )
            .send( ByteBufFlux.fromString( new CustomPublisherForRequest( 0, pinfl ) ) )
            .responseSingle( ( res, content ) -> switch ( res.status().code() ) {
                case 401 -> this.getUpdateTokens().get().getGetModelForAddress().apply( pinfl );
                case 501 | 502 | 503 -> ( Mono< ModelForAddress > ) super.saveErrorLog.apply( res.status().toString(), Methods.GET_MODEL_FOR_ADDRESS );
                default -> super.checkResponse.test( res, content )
                        ? content
                        .asString()
                        .map( s -> this.getGson().fromJson(
                                s.substring( s.indexOf( "Data" ) + 6, s.indexOf( ",\"AnswereId" ) ),
                                ModelForAddress.class ) )
                        : super.convert( new ModelForAddress( super.error.apply( pinfl, 3 ) ) ); } )
            .retryWhen( Retry.backoff( 2, Duration.ofSeconds( 3 ) )
                    .doBeforeRetry( retrySignal -> super.logging( retrySignal, Methods.GET_MODEL_FOR_ADDRESS ) )
                    .doAfterRetry( retrySignal -> super.logging( Methods.GET_MODEL_FOR_ADDRESS, retrySignal ) )
                    .onRetryExhaustedThrow( ( retryBackoffSpec, retrySignal ) -> new IllegalArgumentException() ) )
            .onErrorResume( io.netty.channel.ConnectTimeoutException.class,
                    throwable -> super.convert( new ModelForAddress( super.error.apply( throwable.getMessage(), 4 ) ) ) )
            .onErrorResume( IllegalArgumentException.class,
                    throwable -> super.convert( new ModelForAddress( super.error.apply( Methods.GET_MODEL_FOR_ADDRESS.name(), 5 ) ) ) )
            .doOnError( e -> super.logging( e, Methods.GET_MODEL_FOR_ADDRESS, pinfl ) )
            .doOnSuccess( value -> super.logging( Methods.GET_MODEL_FOR_ADDRESS, value ) )
            .doOnSubscribe( value -> super.logging( super.getAPI_FOR_MODEL_FOR_ADDRESS() ) )
            .onErrorReturn( new ModelForAddress( super.error.apply( Errors.SERVICE_WORK_ERROR.name(), 2 ) ) );

    private final BiFunction< String, String, Mono< ModelForPassport > > getModelForPassport =
            ( SerialNumber, BirthDate ) -> this.getHttpClient()
                    .headers( h -> h.add( "Authorization", "Bearer " + super.getTokenForPassport() ) )
                    .post()
                    .uri( super.getAPI_FOR_PASSPORT_MODEL() )
                    .send( ByteBufFlux.fromString( new CustomPublisherForRequest( 2, SerialNumber + " " + BirthDate ) ) )
                    .responseSingle( ( res, content ) -> switch ( res.status().code() ) {
                        case 401 -> this.getUpdateTokens().get().getGetModelForPassport().apply( SerialNumber, BirthDate );
                        case 501 | 502 | 503 -> ( Mono< ModelForPassport > )
                                super.saveErrorLog.apply( res.status().toString(), Methods.GET_MODEL_FOR_PASSPORT );
                        default -> super.checkResponse.test( res, content )
                                ? content
                                .asString()
                                .map( s -> this.getGson().fromJson( s, ModelForPassport.class ) )
                                : super.convert( new ModelForPassport( super.error.apply( SerialNumber + " : " + SerialNumber, 3 ) ) ); } )
                    .retryWhen( Retry.backoff( 2, Duration.ofSeconds( 3 ) )
                            .doBeforeRetry( retrySignal -> super.logging( retrySignal, Methods.GET_MODEL_FOR_PASSPORT ) )
                            .doAfterRetry( retrySignal -> super.logging( Methods.GET_MODEL_FOR_PASSPORT, retrySignal ) )
                            .onRetryExhaustedThrow( ( retryBackoffSpec, retrySignal ) -> new IllegalArgumentException() ) )
                    .onErrorResume( io.netty.channel.ConnectTimeoutException.class,
                            throwable -> super.convert( new ModelForPassport( super.error.apply( throwable.getMessage(), 4 ) ) ) )
                    .onErrorResume( IllegalArgumentException.class,
                            throwable -> super.convert( new ModelForPassport( super.error.apply( Methods.GET_MODEL_FOR_PASSPORT.name(), 5 ) ) ) )
                    .doOnError( e -> super.logging( e, Methods.GET_MODEL_FOR_PASSPORT, SerialNumber + "_" + BirthDate ) )
                    .doOnSuccess( value -> super.logging( Methods.GET_MODEL_FOR_PASSPORT, value ) )
                    .doOnSubscribe( value -> super.logging( super.getAPI_FOR_PASSPORT_MODEL() ) )
                    .onErrorReturn( new ModelForPassport( super.error.apply( Errors.SERVICE_WORK_ERROR.name(), 2 ) ) );

    // используется при запросе по ФИО
    private final Function< FIO, Mono< List< PsychologyCard > > > getPersonTotalDataByFIO = fio -> this.getHttpClient()
            .headers( h -> h.add( "Authorization", "Bearer " + super.getTokenForFio() ) )
            .post()
            .uri( super.getAPI_FOR_PERSON_DATA_FROM_ZAKS() )
            .send( ByteBufFlux.fromString( new CustomPublisherForRequest( 1, fio ) ) )
            .responseSingle( ( res, content ) -> res.status().code() == 401
                    ? this.getUpdateTokens().get().getGetPersonTotalDataByFIO().apply( fio )
                    : super.checkResponse.test( res, content )
                    ? content
                    .asString()
                    .flatMap( s -> Optional.ofNullable( this.getGson().fromJson( s, PersonTotalDataByFIO.class ) )
                            .filter( person -> person != null && super.checkData.test( 2, person.getData() ) )
                            .map( person -> Flux.fromStream( person.getData().stream() )
                                    .parallel( super.checkDifference.apply( person.getData().size() ) )
                                    .runOn( Schedulers.parallel() )
                                    .flatMap( person1 -> Mono.zip(
                                            this.getGetPinpp().apply( person1.getPinpp() ),
                                            this.getGetImageByPinfl().apply( person1.getPinpp() ) )
                                            .flatMap( tuple2 -> Mono.zip(
                                                    this.getGetModelForAddress().apply( tuple2.getT1().getPCitizen() ),
                                                    this.getGetModelForPassport().apply(
                                                            tuple2.getT1().getPassport(), tuple2.getT1().getBirthDate() ) )
                                                    .map( objects -> new PsychologyCard( objects, tuple2 ) ) ) )
                                    .sequential()
                                    .publishOn( Schedulers.single() )
                                    .collectList() )
                            .orElseGet( () -> super.convert( Collections.singletonList( new PsychologyCard() ) ) ) )
                    : super.convert( Collections.singletonList( new PsychologyCard() ) ) )
            .doOnError( e -> super.logging( e, Methods.GET_DATA_BY_FIO, fio.getName() ) )
            .onErrorReturn( Collections.singletonList( new PsychologyCard() ) );

    // используется при запросе по пинфл
    private final Function< String, Mono< PsychologyCard > > getPsychologyCardByPinfl = pinfl ->
            super.checkData.test( 1, pinfl )
                    ? Mono.zip(
                            this.getGetPinpp().apply( pinfl ),
                            this.getGetImageByPinfl().apply( pinfl ) )
                    .flatMap( tuple2 -> Mono.zip(
                            this.getGetModelForAddress().apply( tuple2.getT1().getPCitizen() ),
                            this.getGetModelForPassport().apply(
                                    tuple2.getT1().getPassport(), tuple2.getT1().getBirthDate() ) )
                            .map( objects -> new PsychologyCard( objects, tuple2 ) ) )
                    : super.convert( new PsychologyCard() );

    // используется при запросе по фото
    private final Function< Results, Mono< List< PsychologyCard > > > getPsychologyCardByImage = results ->
            Flux.fromStream( results.getResults().stream() )
                    .parallel( super.checkDifference.apply( results.getResults().size() ) )
                    .runOn( Schedulers.parallel() )
                    .flatMap( papilonData -> this.getGetPinpp().apply( papilonData.getPersonal_code() )
                            .flatMap( pinpp -> Mono.zip(
                                    this.getGetModelForAddress().apply( pinpp.getPCitizen() ),
                                    this.getGetModelForPassport().apply( pinpp.getPassport(), pinpp.getBirthDate() ) )
                                    .map( tuple -> new PsychologyCard( pinpp, papilonData, tuple ) ) ) )
                    .sequential()
                    .publishOn( Schedulers.single() )
                    .onErrorResume( throwable -> super.convert( new PsychologyCard() ) )
                    .collectList();

    // используется при запросе по номеру паспорта и номер серии
    private final Function< ModelForPassport, Mono< PsychologyCard > > getPsychologyCardByData = modelForPassport ->
            super.checkData.test( 0, modelForPassport )
                    ? Mono.zip(
                            this.getGetPinpp().apply( modelForPassport.getData().getPerson().getPinpp() ),
                            this.getGetImageByPinfl().apply( modelForPassport.getData().getPerson().getPinpp() ),
                            this.getGetModelForAddress().apply( modelForPassport.getData().getPerson().getPCitizen() ) )
                    .map( tuple -> new PsychologyCard( modelForPassport, tuple ) )
            : super.convert( new PsychologyCard() );

    private final Function< String, Mono< Data > > getWorkExperience = pinfl -> {
            final SslContext sslContext;
            try { sslContext = SslContextBuilder
                    .forClient()
                    .sslProvider( SslProvider.JDK )
                    .trustManager( InsecureTrustManagerFactory.INSTANCE )
                    .build();
            } catch ( final Exception e ) { throw new RuntimeException( e ); }
            return this.getHttpClient()
                    .secure( t -> t.sslContext( sslContext ).handlerConfigurator( handler -> {
                        final SSLEngine engine = handler.engine();
                        //engine.setNeedClientAuth(true);
                        final SSLParameters params = new SSLParameters();
                        final List< SNIMatcher > matchers = new LinkedList<>();
                        final SNIMatcher matcher = new SNIMatcher( 0 ) {
                            @Override
                            public boolean matches( SNIServerName serverName ) { return true; } };
                        matchers.add( matcher );
                        params.setSNIMatchers( matchers );
                        engine.setSSLParameters( params ); } ) )
                    .headers( h -> {
                        h.add( "Token", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6Ik1WRCIsImV4cCI6MTY2Mjc5MjI0N30.oig7UlzlgIIiJckFNK6Ed12gGQ0Ec7gyqOPZRQXYDOE" );
                        h.add( "Host", "apigateway.mehnat.uz" ); } )
                    .followRedirect( Boolean.TRUE )
                    .post()
                    .uri( "https://apigateway.mehnat.uz/api/v1/services" )
                    .send( ByteBufFlux.fromString( new CustomPublisherForRequest( 3, pinfl ) ) )
                    .responseSingle( ( res, content ) -> switch ( res.status().code() ) {
                            case 401 -> this.getUpdateTokens().get().getGetWorkExperience().apply( pinfl );
                            case 501 | 502 | 503 -> ( Mono< Data > ) super.saveErrorLog.apply( res.status().toString(), Methods.GET_MODEL_FOR_ADDRESS );
                            default -> super.checkResponse.test( res, content )
                                    ? content
                                    .asString()
                                    .map( s -> this.getGson().fromJson(
                                                s.substring( s.indexOf( "data" ) + 6, s.indexOf( "message" ) - 2 ),
                                                Data.class ) )
                                    : super.convert( new Data( super.error.apply( pinfl, 3 ) ) ); } )
                    .retryWhen( Retry.backoff( 2, Duration.ofSeconds( 3 ) )
                            .doBeforeRetry( retrySignal -> super.logging( retrySignal, Methods.GET_MODEL_FOR_ADDRESS ) )
                            .doAfterRetry( retrySignal -> super.logging( Methods.GET_MODEL_FOR_ADDRESS, retrySignal ) )
                            .onRetryExhaustedThrow( ( retryBackoffSpec, retrySignal ) -> new IllegalArgumentException() ) )
                    .onErrorResume( ConnectTimeoutException.class,
                            throwable -> super.convert( new Data( super.error.apply( throwable.getMessage(), 4 ) ) ) )
                    .onErrorResume( IllegalArgumentException.class,
                            throwable -> super.convert( new Data( super.error.apply( Methods.GET_MODEL_FOR_ADDRESS.name(), 5 ) ) ) )
                    .doOnError( e -> super.logging( e, Methods.GET_MODEL_FOR_ADDRESS, pinfl ) )
                    .doOnSuccess( value -> super.logging( Methods.GET_MODEL_FOR_ADDRESS, value ) )
                    .doOnSubscribe( value -> super.logging( "https://apigateway.mehnat.uz/api/v1/services" ) )
                    .onErrorReturn( new Data( super.error.apply( Errors.SERVICE_WORK_ERROR.name(), 2 ) ) ); };

    @Override
    public void run () {
        while ( this.getThread().isAlive() ) {
            this.getUpdateTokens().get();
            try { TimeUnit.MINUTES.sleep( super.getWaitingMins() ); }
            catch ( InterruptedException e ) {
                serDes = null;
                this.setFlag( false );
                super.logging( e, Methods.UPDATE_TOKENS, "" );
                SerDes.getSerDes(); } }
        SerDes.getSerDes(); }
}