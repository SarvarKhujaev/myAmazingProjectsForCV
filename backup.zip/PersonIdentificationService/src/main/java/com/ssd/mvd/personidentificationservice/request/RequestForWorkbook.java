package com.ssd.mvd.personidentificationservice.request;

@lombok.Data
public final class RequestForWorkbook {
    private final Long id  = 123456L;
    private final Params params;

    private final String jsonrpc = "2.0";
    private final String method = "enst.citizen.fulldata";

    public RequestForWorkbook ( final String pinfl ) { this.params = new Params( pinfl ); }
}
