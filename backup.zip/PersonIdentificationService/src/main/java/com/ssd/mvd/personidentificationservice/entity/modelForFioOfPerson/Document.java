package com.ssd.mvd.personidentificationservice.entity.modelForFioOfPerson;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public final class Document {
    @JsonDeserialize
    private DocumentType DocumentType;
    @JsonDeserialize
    private DateIssue DateIssue;
    @JsonDeserialize
    private DateValid DateValid;

    private String SerialNumber;
    private String IssuedBy;
}
