package com.ssd.mvd.personidentificationservice.entity.modelForPassport;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public final class Sex {
    private Integer Id;
    private String Value;
    private String IdValue;
}
