package com.ssd.mvd.personidentificationservice.entity.modelForAddress;

import com.ssd.mvd.personidentificationservice.inspectors.DataValidateInspector;

@lombok.Data
public final class Address {
    private String actualAddress;
    private String registerAddress;

    public Address ( final ModelForAddress modelForAddress ) {
        this.setActualAddress(
                DataValidateInspector
                        .getInstance()
                        .checkData
                        .test( 4, modelForAddress.getPermanentRegistration() )
                        ? modelForAddress.getPermanentRegistration().getPAddress()
                        : null );
        this.setRegisterAddress(
                DataValidateInspector
                        .getInstance()
                        .checkData
                        .test( 3, modelForAddress.getTemproaryRegistration() )
                        ? modelForAddress.getTemproaryRegistration().get( 0 ).getPAddress()
                        : null ); }
}
