package com.ssd.mvd.personidentificationservice.entity.modelForPassport;

@lombok.Data
public final class RequestGuid {}
