package com.ssd.mvd.personidentificationservice.entity.e_mehnat;

import com.ssd.mvd.personidentificationservice.constants.ErrorResponse;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public final class Data {
    private String pin;
    private String tin;
    private String surname;
    private String passport;
    private String firstname;
    private String birth_date;
    private String patronymic;

    private Keys keys;
    private Float gender;
    private ErrorResponse errorResponse;

    public Data ( final ErrorResponse errorResponse ) { this.setErrorResponse( errorResponse ); }
}
