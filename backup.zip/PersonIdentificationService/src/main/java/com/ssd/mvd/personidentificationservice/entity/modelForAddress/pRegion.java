package com.ssd.mvd.personidentificationservice.entity.modelForAddress;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public final class pRegion {
    private Integer Id;
    private String value;
    private String IdValue;
}
