package com.ssd.mvd.personidentificationservice.entity.e_mehnat;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import java.util.List;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public final class Diploms {
    @JsonDeserialize
    private List< DiplomData > localDiploms;
    @JsonDeserialize
    private List< String > foreignDiplomas;
}
