package com.ssd.mvd.personidentificationservice.request;

@lombok.Data
public final class Params {
    private final Body body;

    public Params ( final String pinfl ) { this.body = new Body( pinfl ); }
}
