package com.ssd.mvd.personidentificationservice.entity;

import com.ssd.mvd.personidentificationservice.entity.modelForPassport.ModelForPassport;
import com.ssd.mvd.personidentificationservice.entity.modelForAddress.ModelForAddress;
import com.ssd.mvd.personidentificationservice.inspectors.DataValidateInspector;
import com.ssd.mvd.personidentificationservice.entity.modelForAddress.Address;
import reactor.util.function.*;

@lombok.Data
@lombok.NoArgsConstructor
public final class PsychologyCard {
    private String fio;
    private String sex;
    private String name;
    private String photo;
    private String pinfl;
    private String surname;
    private String cadastre;
    private String pCitizen;
    private String fatherName;
    private String passNumber;
    private String passSeries;
    private String dateOfBirth;

    private Address address;

    // используется при запросе по фотографии
    public PsychologyCard ( final Pinpp pinpp,
                            final PapilonData papilonData,
                            final Tuple2< ModelForAddress, ModelForPassport > tuple ) {
        this.setPinfl( pinpp.getPinpp() );
        this.setPhoto( papilonData.getPhoto() );
        this.setCadastre( pinpp.getCadastre() );
        this.setDateOfBirth( pinpp.getBirthDate() );
        this.setFio( DataValidateInspector
                .getInstance()
                .getFullName
                .apply( pinpp ) );
        this.save( tuple ); }

    // используется при запросе по пинфл или ФИО
    public PsychologyCard( final Tuple2< ModelForAddress, ModelForPassport > objects,
                           final Tuple2< Pinpp, String > tuple ) {
        this.setPhoto( tuple.getT2() );
        this.setName( tuple.getT1().getName() );
        this.setPinfl( tuple.getT1().getPinpp() );
        this.setSurname( tuple.getT1().getSurname() );
        this.setPCitizen( tuple.getT1().getPCitizen() );
        this.setCadastre( tuple.getT1().getCadastre() );
        this.setFatherName( tuple.getT1().getPatronym() );
        this.setDateOfBirth( tuple.getT1().getBirthDate() );
        this.setPassSeries( tuple.getT1().getPassport().replaceAll( "-", "" ).replaceAll( "\\d", "" ) );
        this.setPassNumber( tuple.getT1().getPassport().replaceAll( "-", "" ).replaceAll( "([A-Z])", "" ) );
        this.setFio( DataValidateInspector
                .getInstance()
                .getFullName
                .apply( tuple.getT1() ) );

        this.save( objects ); }

    private void save ( final Tuple2<
            ModelForAddress,
            ModelForPassport > tuple ) {
        this.setSex( DataValidateInspector
                .getInstance()
                .checkData
                .test( 0, tuple.getT2() )
                ? DataValidateInspector
                .getInstance()
                .setSex
                .apply( tuple.getT2()
                        .getData()
                        .getPerson()
                        .getSex()
                        .getValue() )
                : null );
        this.setAddress( new Address( tuple.getT1() ) ); }

    // используется при запросе по номеру паспорта и номер серии
    public PsychologyCard (
            final ModelForPassport modelForPassport,
            final Tuple3<
                    Pinpp,
                    String,
                    ModelForAddress > tuple ) {
        this.setPhoto( tuple.getT2() );
        this.setSex( DataValidateInspector
                .getInstance()
                .checkData
                .test( 0, modelForPassport )
                ? DataValidateInspector
                .getInstance()
                .setSex
                .apply( modelForPassport
                        .getData()
                        .getPerson()
                        .getSex()
                        .getValue() )
                : null );

        this.setPinfl( tuple.getT1().getPinpp() );
        this.setAddress( new Address( tuple.getT3() ) );
        this.setCadastre( tuple.getT1().getCadastre() );
        this.setDateOfBirth( tuple.getT1().getBirthDate() );

        this.setFio( DataValidateInspector
                .getInstance()
                .getFullName
                .apply( tuple.getT1() ) ); }
}