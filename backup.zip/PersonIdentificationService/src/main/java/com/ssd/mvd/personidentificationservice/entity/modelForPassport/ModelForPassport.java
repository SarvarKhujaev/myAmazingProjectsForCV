package com.ssd.mvd.personidentificationservice.entity.modelForPassport;

import com.ssd.mvd.personidentificationservice.constants.ErrorResponse;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public final class ModelForPassport {
    private Integer AnswereId;
    private String AnswereMessage;
    private String AnswereComment;
    @JsonDeserialize
    private com.ssd.mvd.personidentificationservice.entity.modelForPassport.Data Data;

    private ErrorResponse errorResponse;

    public ModelForPassport ( final ErrorResponse errorResponse ) { this.setErrorResponse( errorResponse ); }
}
