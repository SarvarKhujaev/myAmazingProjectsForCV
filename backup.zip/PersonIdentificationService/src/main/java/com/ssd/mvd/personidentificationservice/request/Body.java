package com.ssd.mvd.personidentificationservice.request;

import java.util.List;

public final class Body {
    private final String pin;
    private final List< String > keys = List.of( "workbook", "diploms" );

    public Body ( final String pin ) { this.pin = pin; }
}
