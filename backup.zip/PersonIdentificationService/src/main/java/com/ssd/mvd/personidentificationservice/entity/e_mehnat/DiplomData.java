package com.ssd.mvd.personidentificationservice.entity.e_mehnat;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public final class DiplomData {
    private Float id;
    private Float degree_id;
    private Float status_id;
    private Float edu_form_id;
    private Float edu_type_id;
    private Float speciality_id;
    private Float institution_id;
    private Float diploma_type_id;
    private Float diploma_serial_id;
    private Float institution_type_id;

    private String mhe_errors;
    private String mhe_status;
    private String reg_number;
    private String status_name;
    private String degree_name;
    private String edu_form_name;
    private String edu_type_name;
    private String diploma_serial;
    private String diploma_number;
    private String speciality_name;
    private String edu_duration_id;
    private String institution_name;
    private String edu_starting_date;
    private String diploma_type_name;
    private String edu_duration_name;
    private String edu_finishing_date;
    private String diploma_given_date;
    private String institution_old_name;
    private String institution_type_name;
    private String institution_old_name_id;
}
