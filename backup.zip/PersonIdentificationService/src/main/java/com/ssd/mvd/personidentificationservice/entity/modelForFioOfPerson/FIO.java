package com.ssd.mvd.personidentificationservice.entity.modelForFioOfPerson;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public final class FIO {
    private String name;
    private String surname;
    private String patronym;
}
