package com.ssd.mvd.personidentificationservice.entity.modelForPassport;

import com.ssd.mvd.personidentificationservice.constants.ErrorResponse;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public final class Data {
    @JsonDeserialize
    private Person Person;
    @JsonDeserialize
    private Document Document;
    @JsonDeserialize
    private RequestGuid RequestGuid;

    private ErrorResponse errorResponse;
}
