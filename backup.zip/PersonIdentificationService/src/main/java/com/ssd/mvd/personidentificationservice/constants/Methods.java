package com.ssd.mvd.personidentificationservice.constants;

public enum Methods {
    CADASTER,
    GET_PINPP,
    UPDATE_TOKENS,
    GET_DATA_BY_FIO,
    GET_IMAGE_BY_PINFL,
    GET_MODEL_FOR_ADDRESS,
    GET_MODEL_FOR_PASSPORT,
    CONVERT_BASE64_TO_LINK,

    // for Popilon service
    GET_FACE_CARD,

    // for RequestController methods
    LIST_BY_NAME,
    LIST_BY_PINFL,
    LIST_BY_PHOTO,
    IMAGE_BY_PINFL,
    LIST_BY_PASSPORT,
}
