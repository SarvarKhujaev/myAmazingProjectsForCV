package com.ssd.mvd.personidentificationservice.entity.modelForFioOfPerson;

import com.ssd.mvd.personidentificationservice.constants.ErrorResponse;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import java.util.List;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public final class PersonTotalDataByFIO {
    private Integer AnswereId;
    private String AnswereMessage;
    private String AnswereComment;
    @JsonDeserialize
    private List< Person > Data;

    private ErrorResponse errorResponse;
}
