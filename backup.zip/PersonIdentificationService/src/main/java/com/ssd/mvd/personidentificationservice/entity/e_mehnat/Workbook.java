package com.ssd.mvd.personidentificationservice.entity.e_mehnat;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public final class Workbook {
    private String code_gs;
    private String date_stop;
    private String date_start;
    private String company_tin;
    private String position_name;
    private String stop_order_date;
    private String start_order_date;
    private String stop_order_number;
    private String start_order_number;
    private String company_profile_name;
}
