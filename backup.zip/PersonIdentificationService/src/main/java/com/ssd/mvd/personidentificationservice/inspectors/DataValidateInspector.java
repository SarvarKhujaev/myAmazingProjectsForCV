package com.ssd.mvd.personidentificationservice.inspectors;

import com.ssd.mvd.personidentificationservice.entity.modelForAddress.PermanentRegistration;
import com.ssd.mvd.personidentificationservice.entity.modelForAddress.TemproaryRegistration;
import com.ssd.mvd.personidentificationservice.entity.modelForPassport.ModelForPassport;
import com.ssd.mvd.personidentificationservice.entity.Pinpp;

import reactor.netty.http.client.HttpClientResponse;
import reactor.core.publisher.Mono;
import reactor.netty.ByteBufMono;

import java.util.function.BiPredicate;
import java.util.function.Function;
import java.util.Optional;
import java.util.List;

public class DataValidateInspector {
    private final static DataValidateInspector INSTANCE = new DataValidateInspector();

    public static DataValidateInspector getInstance () { return INSTANCE; }

    protected <T> Mono< T > convert ( final T o ) { return Optional.ofNullable( o ).isPresent() ? Mono.just( o ) : Mono.empty(); }

    public final BiPredicate< Integer, Object > checkData = ( integer, o ) -> switch ( integer ) {
            case 1 -> o != null && !String.valueOf( o ).isEmpty();
            case 2 -> o != null && !( ( List<?> ) o ).isEmpty();
            case 3 -> o != null
                    && !( ( List< TemproaryRegistration > ) o ).isEmpty()
                    && ( ( List< TemproaryRegistration > ) o ).get( 0 ).getPAddress() != null
                    && ( ( List< TemproaryRegistration > ) o ).get( 0 ).getPAddress().length() > 1;

            case 4 -> o != null
                    && ( (PermanentRegistration) o ).getPAddress() != null
                    && !( (PermanentRegistration) o ).getPAddress().isEmpty();

            default -> ( (ModelForPassport) o ).getData() != null
                    && ( (ModelForPassport) o ).getData().getPerson() != null
                    && ( (ModelForPassport) o ).getData().getPerson().getSex() != null; };

    protected final Function< Integer, Integer > checkDifference = integer -> integer > 0 && integer < 100 ? integer : 10;

    public final Function< Pinpp, String > getFullName = pinpp ->
            String.join( " ", pinpp.getName(), pinpp.getSurname(), pinpp.getPatronym() );

    public final Function< String, String > setSex = s -> s.compareTo( "ЭРКАК" ) == 0 ? "MALE" : "FEMALE";

    protected final BiPredicate< HttpClientResponse, ByteBufMono > checkResponse =
            ( httpClientResponse, byteBufMono ) -> byteBufMono != null && httpClientResponse.status().code() == 200;
}
