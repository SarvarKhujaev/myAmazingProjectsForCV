package com.ssd.mvd.personidentificationservice.component;

import com.ssd.mvd.personidentificationservice.PersonIdentificationServiceApplication;
import com.ssd.mvd.personidentificationservice.constants.Methods;
import com.ssd.mvd.personidentificationservice.entity.Results;

import org.springframework.messaging.rsocket.RSocketRequester;
import java.util.function.Function;
import reactor.core.publisher.Mono;

@lombok.Data
public final class FindFaceComponent {
    private final RSocketRequester requester;
    private final static FindFaceComponent component = new FindFaceComponent();

    public static FindFaceComponent getInstance () { return component; }

    private FindFaceComponent () { this.requester = PersonIdentificationServiceApplication.context.getBean( RSocketRequester.class ); }

    private final Function< String, Mono< Results > > getPapilonList = base64url -> this.getRequester()
            .route( Methods.GET_FACE_CARD.name() )
            .data( base64url )
            .retrieveMono( Results.class )
            .onErrorReturn( new Results() );
}
