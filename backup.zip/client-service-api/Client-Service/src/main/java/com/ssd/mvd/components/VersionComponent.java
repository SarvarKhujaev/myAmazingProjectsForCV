package com.ssd.mvd.components;

import org.springframework.messaging.rsocket.RSocketRequester;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import com.ssd.mvd.entity.AndroidVersionUpdate;
import com.ssd.mvd.inspectors.LogInspector;
import com.ssd.mvd.entity.ApiResponseModel;

@Component
@lombok.RequiredArgsConstructor
public class VersionComponent extends LogInspector {
    private final RSocketRequester requester;

    public Mono< ApiResponseModel > getLastAndroidVersion () {
        return this.requester
                .route( "getLastAndroidVersion" )
                .retrieveMono( ApiResponseModel.class ); }

    public Mono< ApiResponseModel > checkVersionForAndroid ( String version ) {
        return this.requester
                .route( "checkVersionForAndroid" )
                .data( version )
                .retrieveMono( ApiResponseModel.class )
                .defaultIfEmpty( super.getGetErrorResponse().get() )
                .onErrorContinue( super::logging )
                .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< ApiResponseModel > updateLastVersion ( AndroidVersionUpdate version ) {
        return this.requester
                .route( "saveLastVersion" )
                .data( version )
                .retrieveMono( ApiResponseModel.class )
                .defaultIfEmpty( super.getGetErrorResponse().get() )
                .onErrorContinue( super::logging )
                .onErrorReturn( super.getGetErrorResponse().get() ); }
}
