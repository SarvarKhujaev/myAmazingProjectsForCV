package com.ssd.mvd.components;

import com.ssd.mvd.controllerForEscort.PolygonForEscort;
import com.ssd.mvd.entity.ApiResponseModel;
import com.ssd.mvd.inspectors.LogInspector;

import org.springframework.messaging.rsocket.RSocketRequester;
import org.springframework.stereotype.Component;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Component
@lombok.RequiredArgsConstructor
public class PolygonForEscortComponent extends LogInspector {
    private final RSocketRequester requester;

    public Mono< ApiResponseModel > delete ( String uuid ) { return this.requester
            .route( "deletePolygonForEscort" )
            .data( uuid )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Flux< PolygonForEscort > getAllPolygonForEscort() { return this.requester
            .route( "getAllPolygonForEscort" )
            .retrieveFlux( PolygonForEscort.class )
            .onErrorContinue( super::logging ); }

    public Mono< ApiResponseModel > update ( PolygonForEscort polygon ) { return this.requester
            .route( "updatePolygonForEscort" )
            .data( polygon )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< PolygonForEscort > getCurrentPolygonForEscort( String uuid ) { return this.requester
            .route( "getCurrentPolygonForEscort" )
            .data( uuid )
            .retrieveMono( PolygonForEscort.class )
            .onErrorContinue( super::logging ); }

    public Mono< ApiResponseModel > addNewPolygonForEscort( PolygonForEscort polygonForEscort ) { return this.requester
            .route( "addNewPolygonForEscort" )
            .data( polygonForEscort )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }
}
