package com.ssd.mvd.controllerForTablets;

import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.bind.annotation.*;

import com.ssd.mvd.components.PolygonTypeComponent;
import com.ssd.mvd.configs.RSocketPingService;
import com.ssd.mvd.inspectors.LogInspector;
import com.ssd.mvd.entity.PolygonType;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Objects;
import java.util.UUID;

@CrossOrigin
@RestController
@lombok.RequiredArgsConstructor
@RequestMapping( value = "/clientService/api/v1/polygonType" )
public class PolygonTypeController extends LogInspector {
    private final PolygonTypeComponent polygonTypeComponent;

    @GetMapping ( value = "/get" )
    public Flux< ? > get () {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                ( (ServletRequestAttributes) Objects
                        .requireNonNull( RequestContextHolder
                                .getRequestAttributes() ) )
                        .getRequest()
                        .getHeader( "Authorization" ) )
                ? this.polygonTypeComponent.getAllPolygonTypes()
                : Flux.just( super.getGet401Error().get() )
                : Flux.just( super.getGet503Error().get() );
        } catch ( Exception e ) {
            super.logging( e );
            return Flux.just( super.getGet401Error().get() ); } }

    @GetMapping ( value = "/get/{id}" )
    public Mono< ? > getCurrentPolygonType ( @PathVariable ( value = "id" ) final String uuid ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                ( (ServletRequestAttributes) Objects
                        .requireNonNull( RequestContextHolder
                                .getRequestAttributes() ) )
                        .getRequest()
                        .getHeader( "Authorization" ) )
                ? this.polygonTypeComponent.getCurrentPolygonType( UUID.fromString( uuid ) )
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @PostMapping( value = "/add" )
    public Mono< ? > addPolygonType ( @RequestBody final PolygonType polygonType ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test( ( (ServletRequestAttributes) Objects
                            .requireNonNull( RequestContextHolder
                                    .getRequestAttributes() ) )
                            .getRequest()
                            .getHeader( "Authorization" ) )
                ? this.polygonTypeComponent.addPolygonType( polygonType )
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @PutMapping( value = "/update" )
    public Mono< ? > updatePolygonType ( @RequestBody final PolygonType polygonType ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test( ( (ServletRequestAttributes) Objects
                            .requireNonNull( RequestContextHolder
                                    .getRequestAttributes() ) )
                            .getRequest()
                            .getHeader( "Authorization" ) )
                ? this.polygonTypeComponent.updatePolygonType( polygonType )
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @DeleteMapping ( value = "/delete/{id}" )
    public Mono< ? > deletePolygonType ( @PathVariable ( value = "id" ) final String id ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test( ( (ServletRequestAttributes) Objects
                            .requireNonNull( RequestContextHolder
                                    .getRequestAttributes() ) )
                            .getRequest()
                            .getHeader( "Authorization" ) )
                ? this.polygonTypeComponent.deletePolygonType( UUID.fromString( id ) )
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }
}
