package com.ssd.mvd;

import com.ssd.mvd.configs.RSocketPingService;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClientServiceApplication {
    public static ApplicationContext context;

    public static void main( String[] args ) {
        context = SpringApplication.run( ClientServiceApplication.class, args );
        RSocketPingService.getInstance(); }
}
