package com.ssd.mvd.task.card;

import com.ssd.mvd.entity.ReportForCard;
import java.util.List;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class TaskDetails {
    private String date;
    private String title;
    private String fabula;

    private Long timeWastedToArrive;
    private Long totalTimeConsumption;

    private ReportForCard reportForCardList;
    private List< PositionInfo > positionInfoList;
}
