package com.ssd.mvd.controllerForTablets;

import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.bind.annotation.*;

import com.ssd.mvd.components.PolygonComponent;
import com.ssd.mvd.configs.RSocketPingService;
import com.ssd.mvd.inspectors.LogInspector;
import com.ssd.mvd.entity.Polygon;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Objects;
import java.util.Map;

@CrossOrigin
@RestController
@lombok.RequiredArgsConstructor
@RequestMapping("/clientService/api/v1/polygon")
public class PolygonController extends LogInspector { // responsible for all operations with polygons
    private final PolygonComponent polygonComponent;

    @GetMapping( value = "/list" )
    public Flux< ? > getPolygonList () {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                        .requireNonNull( RequestContextHolder
                                .getRequestAttributes() ) )
                        .getRequest()
                        .getHeader( "Authorization" ) )
                ? polygonComponent.getPolygonList()
                : Flux.just( super.getGet401Error().get() )
                : Flux.just( super.getGet401Error().get() );
        } catch ( Exception e ) { 
            super.logging( e );
            return Flux.just( super.getGet401Error().get() ); } }

    @PostMapping ( value = "/add" )
    public Mono< ? > addNewPolygon ( @RequestBody final Polygon polygon ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                        .requireNonNull( RequestContextHolder
                                .getRequestAttributes() ) )
                        .getRequest()
                        .getHeader( "Authorization" ) )
                ? this.polygonComponent.addNewPolygon( polygon )
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( Exception e ) { 
            super.logging( e );
            return super.getGet401Error().get(); } }

    @PutMapping ( value = "/update" )
    public Mono< ? > updatePolygon ( @RequestBody final Polygon polygon ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                        .requireNonNull( RequestContextHolder
                                .getRequestAttributes() ) )
                        .getRequest()
                        .getHeader( "Authorization" ) )
                ? this.polygonComponent.updatePolygon( polygon )
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( Exception e ) { 
            super.logging( e );
            return super.getGet401Error().get(); } }

    @GetMapping( value = "/filter" ) // params might contain region organ or polygonType
    public Flux< ? > filterByType ( @RequestParam final Map< String, String >  params ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                        .requireNonNull( RequestContextHolder
                                .getRequestAttributes() ) )
                        .getRequest()
                        .getHeader( "Authorization" ) )
                ? !params.containsKey( "name" ) ?
                    this.polygonComponent.getPolygonList()
                            .filter( polygon -> super.check( polygon, params ) )
                    : this.polygonComponent.getPolygonList()
                .filter( polygon -> polygon
                        .getName()
                        .equals( params.get( "name" ) ) )
                : Flux.just( super.getGet401Error().get() )
                : Flux.just( super.getGet503Error().get() );
        } catch ( Exception e ) { 
            super.logging( e );
            return Flux.just( super.getGet401Error().get() ); } }

    @DeleteMapping( value = "/delete/{polygonName}" )
    public Mono< ? > deletePolygon ( @PathVariable( "polygonName" ) final String polygonName ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                        .requireNonNull( RequestContextHolder
                                .getRequestAttributes() ) )
                        .getRequest()
                        .getHeader( "Authorization" ) )
                ? this.polygonComponent.deletePolygon( polygonName )
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( Exception e ) { 
            super.logging( e );
            return super.getGet401Error().get(); } }
}
