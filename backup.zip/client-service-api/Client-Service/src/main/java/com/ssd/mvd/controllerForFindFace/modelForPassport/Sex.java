package com.ssd.mvd.controllerForFindFace.modelForPassport;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class Sex {
    private Integer Id;
    private String Value;
    private String IdValue;
}
