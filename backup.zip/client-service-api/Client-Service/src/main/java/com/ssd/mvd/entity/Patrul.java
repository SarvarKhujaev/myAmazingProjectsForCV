package com.ssd.mvd.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.ssd.mvd.constants.TaskTypes;
import com.ssd.mvd.constants.Status;

import java.util.Date;
import java.util.UUID;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
@JsonIgnoreProperties ( ignoreUnknown = true )
public final class Patrul {
    private Date taskDate; // for registration of exact time when patrul started to deal with task
    private Date lastActiveDate; // shows when user was online lastly
    private Date startedToWorkDate; // the time
    private Date dateOfRegistration;

    private Double distance;
    private Double latitude; // the current location of the user
    private Double longitude; // the current location of the user
    private Double latitudeOfTask;
    private Double longitudeOfTask;

    private UUID uuid; // own id of the patrul
    private UUID organ; // choosing from dictionary
    private UUID uuidOfEscort; // UUID of the Escort which this car is linked to
    private UUID uuidForPatrulCar; // choosing from dictionary
    private UUID uuidForEscortCar; // choosing from dictionary

    private Long regionId;
    private Long mahallaId;
    private Long districtId; // choosing from dictionary
    private Long totalActivityTime;

    private Integer batteryLevel;
    private Boolean inPolygon;
    private Boolean tuplePermission; // показывает модноо ли патрульному участвовать в кортеже

    private String name;
    private String rank;
    private String email;
    private String login;
    private String taskId;
    private String carType; // модель машины
    private String surname;
    private String password;
    private String carNumber;
    private String organName;
    private String regionName;
    private String policeType; // choosing from dictionary
    private String fatherName;
    private String dateOfBirth;
    private String phoneNumber;
    private String specialToken;
    private String districtName;
    private String tokenForLogin;
    private String simCardNumber;
    private String passportNumber;
    private String patrulImageLink;
    private String surnameNameFatherName = this.getName() + " " + this.getSurname() + " " + this.getFatherName();

    private Status status = Status.FREE; // busy, free by default, available or not available
    private TaskTypes taskTypes = TaskTypes.FREE; // task type which was attached to the current patrul
}
