package com.ssd.mvd.components;

import org.springframework.messaging.rsocket.RSocketRequester;
import org.springframework.stereotype.Component;

import com.ssd.mvd.controllerForEscort.EscortTuple;
import com.ssd.mvd.inspectors.LogInspector;
import com.ssd.mvd.entity.ApiResponseModel;
import com.ssd.mvd.entity.TupleTotalData;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Component
@lombok.RequiredArgsConstructor
public class EscortComponent extends LogInspector {
    private final RSocketRequester requester;

    public Flux< EscortTuple > getAllEscort() { return this.requester
            .route(  "getAllEscort" )
            .retrieveFlux( EscortTuple.class )
            .onErrorContinue( super::logging ); }

    public Mono< ApiResponseModel > deleteEscort( String uuid ) { return this.requester
            .route( "deleteEscort" )
            .data( uuid )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< EscortTuple > getCurrentEscort ( String uuid ) { return this.requester
            .route( "getCurrentEscort" )
            .data( uuid )
            .retrieveMono( EscortTuple.class ); }

    public Mono< TupleTotalData > getTupleTotalData( String uuid ) { return this.requester
            .route( "getTupleTotalData" )
            .data( uuid )
            .retrieveMono( TupleTotalData.class )
            .onErrorContinue( super::logging ); }

    public Flux< ApiResponseModel > addNewEscort ( EscortTuple escortTuple ) { return this.requester
            .route( "addNewEscort" )
            .data( escortTuple )
            .retrieveFlux( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< ApiResponseModel > updateEscort ( EscortTuple escortTuple ) { return this.requester
            .route( "updateEscort" )
            .data( escortTuple )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< ApiResponseModel > removeEscortCarFromEscort ( String uuid ) { return this.requester
            .route( "removeEscortCarFromEscort" )
            .data( uuid )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }
}
