package com.ssd.mvd.components;

import org.springframework.messaging.rsocket.RSocketRequester;
import org.springframework.stereotype.Component;

import com.ssd.mvd.inspectors.LogInspector;
import com.ssd.mvd.entity.ApiResponseModel;
import com.ssd.mvd.entity.Country;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Component
@lombok.RequiredArgsConstructor
public class CountryComponent extends LogInspector {
    private final RSocketRequester requester;

    public Flux< Country > getCountries () { return this.requester
            .route( "getAllCountries" )
            .retrieveFlux( Country.class )
            .onErrorContinue( super::logging ); }

    public Mono< ApiResponseModel > update ( Country country ) { return this.requester
            .route( "updateCountry" )
            .data( country )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< ApiResponseModel > delete ( String countryName ) { return this.requester
            .route( "deleteCountry" )
            .data( countryName )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< Country > getCurrentCountry ( String countryName ) { return this.requester
            .route( "getCurrentCountry" )
            .data( countryName )
            .retrieveMono( Country.class )
            .onErrorContinue( super::logging ); }

    public Mono< ApiResponseModel > addNewCountry ( Country country ) {
        return this.requester
                .route( "addNewCountry" )
                .data( country )
                .retrieveMono( ApiResponseModel.class )
                .onErrorContinue( super::logging )
                .onErrorReturn( super.getGetErrorResponse().get() ); }
}
