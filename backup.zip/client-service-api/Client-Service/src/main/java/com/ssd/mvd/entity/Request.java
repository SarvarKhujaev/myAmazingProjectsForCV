package com.ssd.mvd.entity;

@lombok.Data
@lombok.Builder
public class Request< T, V > {
    private T object;
    private V subject;
    private String data;
    private String additional;
}
