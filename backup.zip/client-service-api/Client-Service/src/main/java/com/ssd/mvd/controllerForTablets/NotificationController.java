package com.ssd.mvd.controllerForTablets;

import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.bind.annotation.*;

import com.ssd.mvd.components.NotificationComponent;
import com.ssd.mvd.configs.RSocketPingService;
import com.ssd.mvd.inspectors.LogInspector;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import java.util.Objects;

@CrossOrigin
@RestController
@lombok.RequiredArgsConstructor
@RequestMapping( value = "/clientService/api/v1/notification" )
public class NotificationController extends LogInspector {
    private final NotificationComponent component;

    @GetMapping ( value = "/" )
    public Flux< ? > getAllNotifications (
            @RequestParam( value = "page", defaultValue = "0" ) final Long page,
            @RequestParam( value = "size", defaultValue = "20" ) final Long size ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                        .requireNonNull( RequestContextHolder
                                .getRequestAttributes() ) )
                        .getRequest()
                        .getHeader( "Authorization" ) )
                ? this.component
                .getAllNotifications()
                .skip( size * page )
                .take( size )
                : Flux.just( super.getGet401Error().get() )
                : Flux.just( super.getGet503Error().get() );
        } catch ( Exception e ) { 
            super.logging( e );
            return Flux.just( super.getGet401Error().get() ); } }

    @GetMapping ( value = "/getUnreadNotifications" )
    public Flux< ? > getUnreadNotifications (
            @RequestParam( value = "page", defaultValue = "0" ) final Long page,
            @RequestParam( value = "size", defaultValue = "20" ) final Long size ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                ( (ServletRequestAttributes) Objects
                        .requireNonNull( RequestContextHolder
                                .getRequestAttributes() ) )
                        .getRequest()
                        .getHeader( "Authorization" ) )
                ? this.component
                .getUnreadNotifications()
                .skip( size * page )
                .take( size )
                : Flux.just( super.getGet401Error().get() )
                : Flux.just( super.getGet503Error().get() );
        } catch ( Exception e ) { 
            super.logging( e );
            return Flux.just( super.getGet401Error().get() ); } }

    @GetMapping ( value = "/{uuid}" )
    public Mono< ? > setAsRead ( @PathVariable ( value = "uuid" ) final String uuid ) {
        try { return super.checkUUID.test( uuid )
                ? RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                        .requireNonNull( RequestContextHolder
                                .getRequestAttributes() ) )
                        .getRequest()
                        .getHeader( "Authorization" ) )
                ? this.component.setAsRead( uuid )
                : super.getGet401Error().get()
                : super.getGet503Error().get()
                : super.getGet201Error().get();
        } catch ( Exception e ) { 
            super.logging( e );
            return super.getGet401Error().get(); } }

    @GetMapping ( value = "/getUnreadNotificationQuantity" )
    public Mono< ? > getUnreadNotificationQuantity () {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                ( (ServletRequestAttributes) Objects
                        .requireNonNull( RequestContextHolder
                                .getRequestAttributes() ) )
                        .getRequest()
                        .getHeader( "Authorization" ) )
                ? this.component.getUnreadNotificationQuantity()
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( Exception e ) { 
            super.logging( e );
            return super.getGet401Error().get(); } }
}
