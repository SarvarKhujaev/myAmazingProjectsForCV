package com.ssd.mvd.entity;

import java.util.List;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class PatrulActivityStatistics {
    private List< Long > dateList;
    private Patrul patrul;
}
