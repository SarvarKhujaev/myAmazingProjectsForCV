package com.ssd.mvd.entity;

import java.util.UUID;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class PolygonType {
    private String name;
    private UUID uuid;
}
