package com.ssd.mvd.controllerForEscort;

import java.util.UUID;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class Points {
    private Double lat;
    private Double lng;

    private UUID pointId;
    private String pointName;
}
