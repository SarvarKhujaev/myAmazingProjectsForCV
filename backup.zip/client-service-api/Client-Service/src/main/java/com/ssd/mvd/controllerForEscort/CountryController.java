package com.ssd.mvd.controllerForEscort;

import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.bind.annotation.*;

import com.ssd.mvd.components.CountryComponent;
import com.ssd.mvd.configs.RSocketPingService;
import com.ssd.mvd.inspectors.LogInspector;
import com.ssd.mvd.entity.Country;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import java.util.Objects;

@CrossOrigin
@RestController
@lombok.RequiredArgsConstructor
@RequestMapping( value = "/clientService/api/v1/country" )
public class CountryController extends LogInspector {
    private final CountryComponent countryComponent;

    @GetMapping ( value = "/" )
    public Flux< ? > getCountries () {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                            .requireNonNull( RequestContextHolder
                                    .getRequestAttributes() ) )
                            .getRequest()
                            .getHeader( "Authorization" ) )
                ? this.countryComponent.getCountries()
                : Flux.just( super.getGet401Error().get() )
                : Flux.just( super.getGet503Error().get() );
        } catch ( Exception e ) {
            super.logging( e );
            return Flux.just( super.getGet401Error().get() ); } }

    @PutMapping ( value = "/update" )
    public Mono< ? > update ( @RequestBody final Country country ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                            .requireNonNull( RequestContextHolder
                                    .getRequestAttributes() ) )
                            .getRequest()
                            .getHeader( "Authorization" ) )
                ? super.checkCountryGrammar.test( country )
                ? this.countryComponent.update( country )
                .map( apiResponseModel ->
                        apiResponseModel.getStatus().getCode() == 200
                        ? apiResponseModel
                        : super.getGet406Error().apply( "bunday malumot baza da mavjud emas" ) )
                : super.getGet406Error().apply( "malumot tuliq emas" )
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @PostMapping ( value = "/add" )
    public Mono< ? > addNewCountry ( @RequestBody final Country country ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                            .requireNonNull( RequestContextHolder
                                    .getRequestAttributes() ) )
                            .getRequest()
                            .getHeader( "Authorization" ) )
                ? super.checkCountryGrammar.test( country )
                ? this.countryComponent.addNewCountry( country )
                        .map( apiResponseModel ->
                                apiResponseModel
                                        .getStatus()
                                        .getCode() == 200
                                        ? apiResponseModel
                                        : super.getGet406Error().apply( "bunday malumot baza da bor" ) )
                : super.getGet406Error().apply( "malumot tuliq emas" )
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @DeleteMapping ( value = "/delete/{countryName}" )
    public Mono< ? > delete ( @PathVariable ( value = "countryName" ) final String countryName ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkUUID.test( countryName )
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                            .requireNonNull( RequestContextHolder
                                    .getRequestAttributes() ) )
                            .getRequest()
                            .getHeader( "Authorization" ) )
                ? this.countryComponent.delete( countryName )
                : super.getGet401Error().get()
                : super.getGet201Error().get()
                : super.getGet503Error().get();
        } catch ( Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @GetMapping ( value = "/{countryName}" )
    public Mono< ? > getCurrentCountry( @PathVariable ( value = "countryName" ) final String countryName ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkUUID.test( countryName )
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                            .requireNonNull( RequestContextHolder
                                    .getRequestAttributes() ) )
                            .getRequest()
                            .getHeader( "Authorization" ) )
                ? this.countryComponent.getCurrentCountry( countryName )
                : super.getGet401Error().get()
                : super.getGet201Error().get()
                : super.getGet503Error().get();
        } catch ( Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }
}
