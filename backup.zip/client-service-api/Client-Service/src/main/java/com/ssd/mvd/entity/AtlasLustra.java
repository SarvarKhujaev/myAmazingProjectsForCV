package com.ssd.mvd.entity;

import java.util.List;
import java.util.UUID;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class AtlasLustra { // SAM - 74
    private UUID uuid;
    private String lustraName;
    private String carGosNumber; // choosing from dictionary
    private List< CameraList > cameraLists; // Camera rtsp link with Pass&login
}
