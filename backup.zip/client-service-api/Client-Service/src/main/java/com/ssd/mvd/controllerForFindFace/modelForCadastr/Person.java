package com.ssd.mvd.controllerForFindFace.modelForCadastr;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class Person {
    private String pPsp;
    private String pPerson;
    private String pCitizen;
    private String pDateBirth;
    private String pRegistrationDate;
    private pStatus pStatus;
}
