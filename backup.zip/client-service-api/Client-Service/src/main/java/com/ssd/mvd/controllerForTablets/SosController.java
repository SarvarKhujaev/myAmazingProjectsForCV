package com.ssd.mvd.controllerForTablets;

import java.util.Objects;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import com.ssd.mvd.entity.SosRequest;
import com.ssd.mvd.task.card.PatrulSos;
import com.ssd.mvd.components.SosComponent;
import com.ssd.mvd.inspectors.LogInspector;
import com.ssd.mvd.components.PatrulComponent;
import com.ssd.mvd.configs.RSocketPingService;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

@CrossOrigin
@RestController
@lombok.RequiredArgsConstructor
@RequestMapping( value = "/clientService/api/v1/sos" )
public class SosController extends LogInspector {
    private final SosComponent sosComponent;
    private final PatrulComponent patrulComponent;

    @GetMapping ( value = "/" )
    public Flux< ? > getAllSosEntities () {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                ( (ServletRequestAttributes) Objects
                        .requireNonNull( RequestContextHolder
                                .getRequestAttributes() ) )
                        .getRequest()
                        .getHeader( "Authorization" ) )
                ? this.sosComponent.getAllSosEntities()
                : Flux.just( super.getGet401Error().get() )
                : Flux.just( super.getGet503Error().get() );
        } catch ( final Exception e ) {
            super.logging( e );
            return Flux.just( super.getGet401Error().get() ); } }

    // нужен чтобы планшет проверил не отправлял ли патрульный сигнал СОС
    @GetMapping ( value = "/checkSosStatus" )
    public Mono< ? > checkSosStatus () {
        try {
            final String token = ( (ServletRequestAttributes) Objects
                    .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                    .getRequest()
                    .getHeader( "Authorization" )
                    .split( " " )[ 1 ];
            return RSocketPingService
                .getInstance()
                .getFlag()
                    ? this.patrulComponent
                    .checkToken( token )
                    .flatMap( apiResponseModel -> super.checkToken( token, apiResponseModel )
                            ? this.sosComponent.checkSosStatus ( token )
                            : super.convert( super.getGet401Error().get() ) )
                    : super.convert( super.getGet503Error().get() ); }
        catch ( final Exception e ) {
            super.logging( e );
            return super.getGet503Error().get(); } }

    @GetMapping ( value = "/getAllSosForCurrentPatrul" )
    public Mono< ? > getAllSosForCurrentPatrul () {
        try {
            final String token = ( (ServletRequestAttributes) Objects
                    .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                    .getRequest()
                    .getHeader( "Authorization" )
                    .split( " " )[ 1 ];
            return RSocketPingService
                .getInstance()
                .getFlag()
                    ? this.patrulComponent
                    .checkToken( token )
                    .flatMap( apiResponseModel -> super.checkToken( token, apiResponseModel )
                            ? this.sosComponent.getAllSosForCurrentPatrul ( token )
                            : super.convert( super.getGet401Error().get() ) )
                    : super.convert( super.getGet503Error().get() ); }
        catch ( final Exception e ) {
            super.logging( e );
            return super.getGet503Error().get(); } }

    @PostMapping( value = "/saveSos" )
    public Mono< ? > saveSos( @RequestBody final PatrulSos patrulSos ) {
        try {
            final String token = ( (ServletRequestAttributes) Objects
                    .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                    .getRequest()
                    .getHeader( "Authorization" )
                    .split( " " )[ 1 ];
            return RSocketPingService
                    .getInstance()
                    .getFlag()
                    ? this.patrulComponent.checkToken( token )
                    .flatMap( apiResponseModel -> this.checkParam.test( apiResponseModel.getData() )
                            && super.checkToken( token, apiResponseModel, patrulSos )
                            ? this.sosComponent.saveSosFromPatrul( patrulSos )
                            : super.convert( super.getGet401Error().get() ) )
                    : super.convert( super.getGet503Error().get() );
        } catch ( final Exception e ) {
            super.logging( e );
            return super.getGet503Error().get(); } }

    @PostMapping ( value = "/updatePatrulStatusInSosTable" )
    public Mono< ? > updatePatrulStatusInSosTable ( @RequestBody final SosRequest sosRequest ) {
        try {
            final String token = ( (ServletRequestAttributes) Objects
                    .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                    .getRequest()
                    .getHeader( "Authorization" )
                    .split( " " )[ 1 ];
            return RSocketPingService
                    .getInstance()
                    .getFlag()
                    ? this.patrulComponent
                    .checkToken( token )
                    .flatMap( apiResponseModel -> super.checkToken( token, apiResponseModel, sosRequest )
                            ? this.sosComponent.updatePatrulStatusInSosTable ( sosRequest )
                            : super.convert( super.getGet401Error().get() ) )
                    : super.convert( super.getGet503Error().get() ); }
        catch ( final Exception e ) {
            super.logging( e );
            return super.convert( super.getGet503Error().get() ); } }
}
