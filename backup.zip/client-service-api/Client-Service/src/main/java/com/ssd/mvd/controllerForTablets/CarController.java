package com.ssd.mvd.controllerForTablets;

import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.bind.annotation.*;

import com.ssd.mvd.configs.RSocketPingService;
import com.ssd.mvd.inspectors.LogInspector;
import com.ssd.mvd.components.CarComponent;
import com.ssd.mvd.entity.ReqCar;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import lombok.RequiredArgsConstructor;
import java.util.Objects;
import java.util.Map;

@CrossOrigin
@RestController
@RequiredArgsConstructor
@RequestMapping( value = "/clientService/api/v1/car" )
public class CarController extends LogInspector {
    private final CarComponent carComponent;

    @GetMapping( value = "/list" )
    public Flux< ? > getAllCars () {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test( ( (ServletRequestAttributes) Objects
                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                .getRequest()
                .getHeader( "Authorization" ) )
                ? this.carComponent.getAllCars()
                : Flux.just( super.getGet401Error().get() )
                : Flux.just( super.getGet503Error().get() );
        } catch ( Exception e ) {
            super.logging( e );
            return Flux.just( super.getGet401Error() ); } }

    @PutMapping ( value = "/update" )
    public Mono< ? > update ( @RequestBody final ReqCar reqCar ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test( ( (ServletRequestAttributes) Objects
                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                .getRequest()
                .getHeader( "Authorization" ) )
                ? this.carComponent.updateCar( reqCar )
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @PostMapping( value = "/add" )
    public Mono< ? > addCar ( @RequestBody final ReqCar reqCar ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                            .requireNonNull( RequestContextHolder
                                    .getRequestAttributes() ) )
                            .getRequest()
                            .getHeader( "Authorization" ) )
                ? this.carComponent.addCar( reqCar )
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @GetMapping ( value = "/filter" )
    public Flux< ? > filterByOrgan ( @RequestParam Map< String, String > params ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                            .requireNonNull( RequestContextHolder
                                    .getRequestAttributes() ) )
                            .getRequest()
                            .getHeader( "Authorization" ) )
                ? ( params.containsKey( "gosno" )
                ^ params.containsKey( "trackerId" ) ) ?
                params.containsKey( "gosno" ) ? Flux.from( this.carComponent
                        .searchByGosno( params.get("gosno") ) ) : this.carComponent
                        .getAllCars()
                        .filter( reqCar -> reqCar.getTrackerId().equals( params.get( "trackerId" ) ) )
                : this.carComponent.filterCars( params )
                : Flux.just( super.getGet401Error().get() )
                : Flux.just( super.getGet503Error().get() );
        } catch ( Exception e ) {
            super.logging( e );
            return Flux.just( super.getGet401Error().get() ); } }

    @DeleteMapping ( value = "/delete/{gosNumber}" )
    public Mono< ? > deleteCar ( @PathVariable( "gosNumber" ) final String gosNumber ) {
        try { return super.checkUUID.test( gosNumber )
                ? RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                ( (ServletRequestAttributes) Objects
                        .requireNonNull( RequestContextHolder
                                .getRequestAttributes() ) )
                        .getRequest()
                        .getHeader( "Authorization" ) )
                ? this.carComponent.deleteCar( gosNumber )
                : super.getGet401Error().get()
                : super.getGet503Error().get()
                : super.getGet201Error().get();
        } catch ( Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @GetMapping ( value = "/searchCarOnMap/{gosnumber}" )
    public Flux< ? > searchCarOnMap ( @PathVariable ( value = "gosnumber" ) final String gosnumber ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                            .requireNonNull( RequestContextHolder
                                    .getRequestAttributes() ) )
                            .getRequest()
                            .getHeader( "Authorization" ) )
                ? this.carComponent.getAllCars()
                .filter( reqCar -> reqCar.getGosNumber().contains( gosnumber ) )
                : Flux.just( super.getGet401Error().get() )
                : Flux.just( super.getGet503Error().get() );
        } catch ( Exception e ) {
            super.logging( e );
            return Flux.just( super.getGet401Error().get() ); } }
}
