package com.ssd.mvd.controllerForFindFace.modelForPassport;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class Make {
	private String name;
	private Double confidence;
}