package com.ssd.mvd.controllerForFindFace.modelForCadastr;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class pStatus {
    private Integer Id;
    private String Value;
    private String IdValue;
}
