package com.ssd.mvd.controllerForFindFace.modelForPassport;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class DocumentType {
    private Integer Id;
    private String Value;
    private String IdValue;
}
