package com.ssd.mvd.task.card;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class PositionInfo {
    private Double lat;
    private Double lng;
}
