package com.ssd.mvd.entity;

import java.util.Date;
import java.util.UUID;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public final class TabletUsage {
    private Date startedToUse;
    private Date lastActiveDate;

    private UUID uuidOfPatrul;
    private String simCardNumber; // unique identifier of Tablet
    private Long totalActivityTime; // total time of usage in seconds
}