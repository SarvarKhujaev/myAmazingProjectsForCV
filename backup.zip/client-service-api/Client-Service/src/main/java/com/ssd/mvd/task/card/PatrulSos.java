package com.ssd.mvd.task.card;

import com.ssd.mvd.constants.Status;
import java.util.HashMap;
import java.util.UUID;
import java.util.Date;
import java.util.Map;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class PatrulSos {
    private UUID uuid;
    private UUID patrulUUID;

    private String address;

    private Date sosWasSendDate; // созраняет время когда запрос был отправлен
    private Date sosWasClosed; // время когда сос был отменен

    private Double latitude;
    private Double longitude;

    private Status status;
    private Map< UUID, String > patrulStatuses = new HashMap<>();
}
