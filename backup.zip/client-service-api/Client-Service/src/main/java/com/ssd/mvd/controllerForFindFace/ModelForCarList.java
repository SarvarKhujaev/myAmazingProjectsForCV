package com.ssd.mvd.controllerForFindFace;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.ssd.mvd.controllerForFindFace.modelForGai.ModelForCar;
import java.util.List;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class ModelForCarList {
    @JsonDeserialize
    private List< ModelForCar > modelForCarList;
}
