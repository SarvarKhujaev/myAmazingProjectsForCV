package com.ssd.mvd.components;

import org.springframework.messaging.rsocket.RSocketRequester;
import org.springframework.stereotype.Component;

import com.ssd.mvd.inspectors.LogInspector;
import com.ssd.mvd.entity.ApiResponseModel;
import com.ssd.mvd.entity.Patrul;
import com.ssd.mvd.entity.ReqCar;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import java.util.Map;

@Component
@lombok.RequiredArgsConstructor
public final class CarComponent extends LogInspector {
    private final RSocketRequester requester;

    public Flux< ReqCar > getAllCars() { return this.requester.route( "carList" ).retrieveFlux( ReqCar.class ); }

    public Flux< ReqCar > searchByGosno ( final String gosno ) { return this.requester
            .route( "searchByGosnoCar" )
            .data( gosno )
            .retrieveFlux( ReqCar.class )
            .onErrorContinue( super::logging ); }

    public Flux< ReqCar > filterCars ( final Map< String, String > params ) { return this.requester
            .route( "usersList" )
            .retrieveFlux( Patrul.class )
            .filter( patrul -> super.check( patrul, params ) )
            .flatMap( patrul -> this.requester.route( "getCurrentCar" )
                    .data( patrul.getCarNumber() )
                    .retrieveMono( ReqCar.class ) ); }

    public Mono< ApiResponseModel > addCar ( final ReqCar reqCar ) { return this.requester
            .route( "addCar" )
            .data( reqCar )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< ApiResponseModel > updateCar ( final ReqCar reqCar ) { return this.requester
            .route( "updateCar" )
            .data( reqCar )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< ApiResponseModel > deleteCar ( final String gosNumber ) { return this.requester
            .route( "deleteCar" )
            .data( gosNumber )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }
}
