package com.ssd.mvd.controllerForFindFace;

import com.ssd.mvd.controllerForFindFace.modelForAddress.ModelForAddress;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.extern.jackson.Jacksonized;
import java.util.List;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class PsychologyCard {
    private String personImage; // the image of the person
    @JsonDeserialize
    private Pinpp pinpp;
    @JsonDeserialize
    private List< PapilonData > papilonData;
    @JsonDeserialize
    private List< Violation > violationList;
    @JsonDeserialize
    private ModelForCarList modelForCarList; // the list of all cars which belongs to this person
    @JsonDeserialize
    private ModelForAddress modelForAddress;
    @JsonDeserialize
    private com.ssd.mvd.controllerForFindFace.modelForCadastr.Data modelForCadastr;
    @JsonDeserialize
    private com.ssd.mvd.controllerForFindFace.modelForPassport.Data modelForPasspor;
}
