package com.ssd.mvd.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class ReportForCard { // creates when some of Patrul from current Card has finished the work and has written the report about everything he has done
    private Double lan;
    private Double lat;

    private String title; // the name of Report
    private String description;
    private String passportSeries;

    private UUID uuidOfPatrul;
    private final Date date = new Date(); // the date when report was created
    private List< String > imagesIds = new ArrayList<>(); // contains all images Ids which was downloaded in advance
}
