package com.ssd.mvd.entity;

import java.util.UUID;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class Country {
	private UUID uuid;
	private String flag; // флаг страны
	private String symbol;
	private String countryNameEn;
	private String countryNameUz;
	private String countryNameRu;
}
