package com.ssd.mvd.entity;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class AndroidVersionUpdate {
    private String link;
    private String version;
    private Status status;
}
