package com.ssd.mvd.components;

import org.springframework.messaging.rsocket.RSocketRequester;
import org.springframework.stereotype.Component;

import com.ssd.mvd.task.selfEmploymentTask.ActiveTask;
import com.ssd.mvd.inspectors.LogInspector;
import com.ssd.mvd.entity.ApiResponseModel;
import com.ssd.mvd.task.card.*;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import java.util.UUID;

@Component
@lombok.RequiredArgsConstructor
public class CardComponent extends LogInspector {
    private final RSocketRequester requester;

    public Flux< ActiveTask > getListOfCards () { return this.requester
            .route( "getListOfCards" )
            .retrieveFlux( ActiveTask.class )
            .onErrorContinue( super::logging ); }

    public Mono< ApiResponseModel > removePatrulFromCard ( UUID uuid ) { return this.requester
            .route( "removePatrulFromTask" )
            .data( uuid )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Flux< ApiResponseModel > linkCardToPatrul ( CardRequest request ) { return this.requester
            .route( "linkCardToPatrul" )
            .data( request )
            .retrieveFlux( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< ApiResponseModel > addNewPatrulToCard ( CardRequest request ) { return this.requester
            .route( "addNewPatrulsToTask" )
            .data( request )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< ApiResponseModel > addNewPatrulsToTask ( CardRequest cardRequest ) { return this.requester
            .route( "addNewPatrulsToTask" )
            .data( cardRequest )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< TaskTimingStatisticsList > getTaskTimingStatistics( TaskTimingRequest request ) {
        return this.requester
                .route( "getTaskTimingStatistics" )
                .data( request )
                .retrieveMono( TaskTimingStatisticsList.class )
                .onErrorContinue( super::logging )
                .onErrorReturn( new TaskTimingStatisticsList() ); }

    public Mono< TaskDetails > getDetailsOfTask ( TaskDetailsRequest request ) {
        return this.requester
                .route( "getDetailsOfTask" )
                .data( request )
                .retrieveMono( TaskDetails.class )
                .onErrorContinue( super::logging ); }

    public Mono< ActiveTask > getActiveTaskForFront( TaskDetailsRequest taskDetailsRequest ) {
        return this.requester
                .route( "getActiveTaskForFront" )
                .data( taskDetailsRequest )
                .retrieveMono( ActiveTask.class )
                .onErrorContinue( super::logging ); }
}
