package com.ssd.mvd.entity;

import lombok.extern.jackson.Jacksonized;

@lombok.Data
@Jacksonized
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class PolygonEntity {
    private Double lat;
    private Double lng;
}
