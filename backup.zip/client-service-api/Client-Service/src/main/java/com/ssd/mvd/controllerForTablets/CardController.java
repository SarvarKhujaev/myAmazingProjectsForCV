package com.ssd.mvd.controllerForTablets;

import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.bind.annotation.*;

import com.ssd.mvd.task.card.TaskDetailsRequest;
import com.ssd.mvd.task.card.TaskTimingRequest;
import com.ssd.mvd.configs.RSocketPingService;
import com.ssd.mvd.components.CardComponent;
import com.ssd.mvd.inspectors.LogInspector;
import com.ssd.mvd.task.card.CardRequest;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import javax.ws.rs.QueryParam;
import java.util.Objects;
import java.util.UUID;

@CrossOrigin
@RestController
@lombok.RequiredArgsConstructor
@RequestMapping ( value = "/clientService/api/v1/card" )
public class CardController extends LogInspector {
    private final CardComponent cardComponent;

    @GetMapping ( value = "/" )
    public Flux< ? > getListOfCards () {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                ( (ServletRequestAttributes) Objects
                        .requireNonNull( RequestContextHolder
                                .getRequestAttributes() ) )
                        .getRequest()
                        .getHeader( "Authorization" ) )
                ? this.cardComponent.getListOfCards()
                : Flux.just( super.getGet401Error().get() )
                : Flux.just( super.getGet503Error().get() );
        } catch ( Exception e ) {
            super.logging( e );
            return Flux.just( super.getGet401Error().get() ); } }

    @PostMapping ( value = "/addNewPatrulToCard" )
    public Mono< ? > addNewPatrulToCard ( @RequestBody final CardRequest request ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                        .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                        .getRequest()
                        .getHeader( "Authorization" ) )
                ? this.cardComponent.addNewPatrulToCard ( request )
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @PostMapping ( value = "/card" )
    public Flux< ? > linkCardToPatrul ( @RequestBody final CardRequest cardRequest ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                        .requireNonNull( RequestContextHolder
                                .getRequestAttributes() ) )
                        .getRequest()
                        .getHeader( "Authorization" ) )
                ? this.cardComponent.linkCardToPatrul( cardRequest )
                : Flux.just( super.getGet401Error().get() )
                : Flux.just( super.getGet503Error().get() );
        } catch ( Exception e ) {
            super.logging( e );
            return Flux.just( super.getGet401Error().get() ); } }

    @PostMapping (  value = "/addNewPatrulsToTask" )
    public Mono< ? > addNewPatrulsToTask ( @RequestBody final CardRequest cardRequest ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                        .requireNonNull( RequestContextHolder
                                .getRequestAttributes() ) )
                        .getRequest()
                        .getHeader( "Authorization" ) )
                ? this.cardComponent.addNewPatrulsToTask( cardRequest )
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @PostMapping ( value = "/getDetailsOfTask" )
    public Mono< ? > getDetailsOfTask ( @RequestBody final TaskDetailsRequest request ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkParam.test( request )
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                        .requireNonNull( RequestContextHolder
                                .getRequestAttributes() ) )
                        .getRequest()
                        .getHeader( "Authorization" ) )
                ? this.cardComponent.getDetailsOfTask( request )
                : super.getGet401Error().get()
                : super.getGet201Error().get()
                : super.getGet503Error().get();
        } catch ( Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @PostMapping ( value = "/getTaskTimingStatistics" )
    public Mono< ? > getTaskTimingStatistics ( @RequestBody final TaskTimingRequest request ) {
        try { return super.checkParam.test( request )
                ? RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                        .requireNonNull( RequestContextHolder
                                .getRequestAttributes() ) )
                        .getRequest()
                        .getHeader( "Authorization" ) )
                ? this.cardComponent.getTaskTimingStatistics( request )
                : super.getGet401Error().get()
                : super.getGet503Error().get()
                : super.getGet201Error().get();
        } catch ( Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @GetMapping ( value = "/removePatrulFromTask/{uuid}" )
    public Mono< ? > removePatrulFromCard ( @PathVariable ( value = "uuid" ) final String uuid ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkUUID.test( uuid )
                ? super.checkToken.test(
                ( (ServletRequestAttributes) Objects
                        .requireNonNull( RequestContextHolder
                                .getRequestAttributes() ) )
                        .getRequest()
                        .getHeader( "Authorization" ) )
                ? this.cardComponent.removePatrulFromCard ( UUID.fromString( uuid ) )
                : super.getGet401Error().get()
                : super.getGet201Error().get()
                : super.getGet503Error().get();
        } catch ( Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @GetMapping ( value = "/filter/" )
    public Flux< ? > getListOfCards ( @QueryParam ( value = "taskType" ) final String taskType ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                        .requireNonNull( RequestContextHolder
                                .getRequestAttributes() ) )
                        .getRequest()
                        .getHeader( "Authorization" ) )
                ? this.cardComponent.getListOfCards()
                .filter( activeTask -> taskType.equals( activeTask.getType() ) )
                : Flux.just( super.getGet401Error().get() )
                : Flux.just( super.getGet503Error().get() );
        } catch ( Exception e ) {
            super.logging( e );
            return Flux.just( super.getGet401Error().get() ); } }

    @PostMapping ( value = "/getActiveTaskForFront" )
    public Mono< ? > getActiveTaskForFront ( @RequestBody final TaskDetailsRequest taskDetailsRequest ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                ( (ServletRequestAttributes) Objects
                        .requireNonNull( RequestContextHolder
                                .getRequestAttributes() ) )
                        .getRequest()
                        .getHeader( "Authorization" ) )
                ? this.cardComponent.getActiveTaskForFront( taskDetailsRequest )
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }
}
