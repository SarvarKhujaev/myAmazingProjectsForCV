package com.ssd.mvd.components;

import org.springframework.messaging.rsocket.RSocketRequester;
import org.springframework.stereotype.Component;

import com.ssd.mvd.inspectors.LogInspector;
import com.ssd.mvd.entity.ApiResponseModel;
import com.ssd.mvd.entity.Notification;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Component
@lombok.RequiredArgsConstructor
public class NotificationComponent extends LogInspector {
    private final RSocketRequester requester;

    public Flux< Notification > getAllNotifications() { return this.requester
            .route( "getAllNotifications" )
            .retrieveFlux( Notification.class )
            .onErrorContinue( super::logging ); }

    public Flux< Notification > getUnreadNotifications() { return this.requester
            .route(  "getUnreadNotifications" )
            .retrieveFlux( Notification.class )
            .onErrorContinue( super::logging ); }

    public Mono< ApiResponseModel > setAsRead( String uuid ) { return this.requester
            .route( "setAsRead" )
            .data( uuid )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< Long > getUnreadNotificationQuantity () { return this.requester
            .route( "getUnreadNotificationQuantity" )
            .retrieveMono( Long.class ); }
}
