package com.ssd.mvd.controllerForTablets;

import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import com.ssd.mvd.entity.AndroidVersionUpdate;
import com.ssd.mvd.components.VersionComponent;
import com.ssd.mvd.entity.ApiResponseModel;

@CrossOrigin
@RestController
@lombok.RequiredArgsConstructor
@RequestMapping( value = "/clientService/api/v1/version" )
public class VersionConrtoller {
    private final VersionComponent versionComponent;

    @GetMapping ( value = "/getLastAndroidVersion" )
    public Mono< ApiResponseModel > getLastAndroidVersion () { return this.versionComponent.getLastAndroidVersion(); }


    @PostMapping ( value = "/updateLastVersion" )
    public Mono< ApiResponseModel > updateLastVersion ( @RequestBody final AndroidVersionUpdate version ) {
        return this.versionComponent.updateLastVersion( version ); }

    @GetMapping ( value = "/{version}" )
    public Mono< ApiResponseModel > checkVersionForAndroid ( @PathVariable ( value = "version" ) final String version ) {
        return this.versionComponent.checkVersionForAndroid( version ); }
}
