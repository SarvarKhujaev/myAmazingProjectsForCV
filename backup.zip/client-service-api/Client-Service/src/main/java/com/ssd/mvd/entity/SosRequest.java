package com.ssd.mvd.entity;

import com.ssd.mvd.constants.Status;
import java.util.UUID;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
// используется патрульным для того чтобы подтвердить или отказаться от соса
public final class SosRequest {
    private UUID patrulUUID;
    private UUID sosUUID;
    private Status status; // might be Accepted or Cancel either
}
