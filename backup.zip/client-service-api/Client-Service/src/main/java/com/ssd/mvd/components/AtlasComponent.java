package com.ssd.mvd.components;

import org.springframework.messaging.rsocket.RSocketRequester;
import org.springframework.stereotype.Component;

import com.ssd.mvd.inspectors.LogInspector;
import com.ssd.mvd.entity.*;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Component
@lombok.RequiredArgsConstructor
public class AtlasComponent extends LogInspector {
    private final RSocketRequester requester;

    public Flux< AtlasLustra > getAllLustra () { return this.requester
            .route( "allLustra" )
            .retrieveFlux( AtlasLustra.class )
            .onErrorContinue( super::logging ); }

    public Mono< ApiResponseModel > delete ( String gosno ) { return this.requester
            .route( "deleteLustra" )
            .data( gosno )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Flux< AtlasLustra > searchByName ( String name ) { return this.requester
            .route( "searchByNameLustra" )
            .data( name )
            .retrieveFlux( AtlasLustra.class )
            .onErrorContinue( super::logging ); }

    public Mono< ApiResponseModel > add ( AtlasLustra atlasLustra ) { return this.requester
            .route( "addLustra" )
            .data( atlasLustra )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< ApiResponseModel > updateLustra ( AtlasLustra atlasLustra ) { return this.requester
            .route( "updateLustra" )
            .data( atlasLustra )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }
}
