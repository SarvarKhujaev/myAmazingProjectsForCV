package com.ssd.mvd.entity;

import java.util.Date;
import java.time.Month;
import java.util.SortedMap;

@lombok.Data
@lombok.AllArgsConstructor
public final class TabletUsageStatistics {
    // хранит данные о том, сколько часов патрульный использовал в каждом месяце
    private final SortedMap< Month, Long > tabletUsageStatisticsForYear;
    // хранит данные о том, сколько часов патрульный использовал каждый день в течении месяца
    private final SortedMap< Date, Long > tabletUsageStatisticsForEachDay;
}
