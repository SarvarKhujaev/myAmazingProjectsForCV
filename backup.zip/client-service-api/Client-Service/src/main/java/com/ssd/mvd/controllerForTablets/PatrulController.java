package com.ssd.mvd.controllerForTablets;

import java.util.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import com.ssd.mvd.entity.*;
import com.ssd.mvd.constants.TaskTypes;
import com.ssd.mvd.task.card.CardRequest;
import com.ssd.mvd.inspectors.LogInspector;
import com.ssd.mvd.token.PatrulLoginRequest;
import com.ssd.mvd.configs.RSocketPingService;
import com.ssd.mvd.components.PatrulComponent;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

@CrossOrigin
@RestController
@lombok.RequiredArgsConstructor
@RequestMapping( value = "/clientService/api/v1/user" )
public final class PatrulController extends LogInspector {
    private final PatrulComponent patrulComponent;

    @GetMapping ( value = "/getPatrulsWithoutCars" )
    public Flux< ? > getPatrulsWithoutCars () {
        return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test( ( (ServletRequestAttributes) Objects
                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                .getRequest()
                .getHeader( "Authorization" ) )
                ? this.patrulComponent.getUsersList()
                .filter( patrul -> patrul.getCarNumber().compareTo( "null" ) == 0 )
                : Flux.just( super.getGet401Error() )
                : Flux.just( super.getGet503Error() ); }

    @PostMapping( value = "/findTheClosestPatruls" )
    public Flux< ? > findTheClosestPatruls ( @RequestBody final Point point ) {
        return super.checkPoint.test( point )
                ? RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test( ( (ServletRequestAttributes) Objects
                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                .getRequest()
                .getHeader( "Authorization" ) )
                ? this.patrulComponent.findTheClosestPatruls( point )
                : Flux.just( super.getGet401Error().get() )
                : Flux.just( super.getGet503Error().get() )
                : Flux.just( super.getGet201Error().get() ); }

    @GetMapping ( value = "/getPatrulDataByToken/{token}" )
    public Mono< ? > getPatrulDataByToken ( @PathVariable ( value = "token" ) final String token ) {
        return super.checkParam.test( token )
                && super.checkUUID.test( super.checkSimCard.apply( token, 0 ) )
                ? this.patrulComponent.getPatrulDataByToken( token )
                : super.getGet201Error().get(); }

    @GetMapping ( value = "/getTaskDetails" )
    public Mono< ? > getTaskDetails () {
        if ( !RSocketPingService
                .getInstance()
                .getFlag() ) return super.getGet503Error().get();
        final String token = ( (ServletRequestAttributes) Objects.requireNonNull(
                RequestContextHolder.getRequestAttributes() ) )
                .getRequest()
                .getHeader( "Authorization" )
                .split( " " )[1];
        return this.patrulComponent.checkToken( token )
                .flatMap( apiResponseModel -> super.checkToken( token, apiResponseModel )
                        ? this.patrulComponent.getTaskDetails( apiResponseModel.getData() )
                        : super.getGet401Error().get() ); }

    @GetMapping ( value = "/getCurrentActiveTask" )
    public Mono< ? > getCurrentActiveTask () {
        final String token = ( (ServletRequestAttributes) Objects.requireNonNull(
                RequestContextHolder.getRequestAttributes() ) )
                .getRequest()
                .getHeader( "Authorization" )
                .split( " " )[1];
        return RSocketPingService
                .getInstance()
                .getFlag()
                ? this.patrulComponent.checkToken( token )
                .onErrorContinue( super::logging )
                .map( apiResponseModel -> super.checkToken( token, apiResponseModel )
                        ? this.patrulComponent.getCurrentActiveTask( token )
                        : super.getGet401Error().get() )
                : super.getGet503Error().get(); }

    @PostMapping ( value = "/login" )
    public Mono< ? > login ( @RequestBody final PatrulLoginRequest patrulLoginRequest ) {
        return super.checkLoginRequest.test( patrulLoginRequest )
                ? RSocketPingService
                .getInstance()
                .getFlag()
                ? this.patrulComponent.patrulLogin( patrulLoginRequest )
                .onErrorContinue( super::logging )
                : super.getGet503Error().get()
                : super.getGet201Error().get(); }

    @PostMapping ( value = "/changeStatus/{type}" )
    public Mono< ? > finishWork ( @PathVariable ( value = "type" ) final com.ssd.mvd.constants.Status type ) {
            if ( !RSocketPingService
                .getInstance()
                .getFlag() ) return super.getGet503Error().get();
            final String token = ( (ServletRequestAttributes) Objects.requireNonNull(
                    RequestContextHolder.getRequestAttributes() ) )
                    .getRequest()
                    .getHeader( "Authorization" )
                    .split( " " )[1];
            return switch ( type ) {
                case RETURNED_TO_WORK -> this.patrulComponent.checkToken( token )
                        .flatMap( apiResponseModel -> super.checkToken( token, apiResponseModel )
                                ? this.patrulComponent.backToWork( token )
                                : super.getGet401Error().get() );
                case ARRIVED -> this.patrulComponent.checkToken( token )
                        .flatMap( apiResponseModel -> super.checkToken( token, apiResponseModel )
                                ? this.patrulComponent.arrived( token )
                                : super.getGet401Error().get() );
                case ACCEPTED -> this.patrulComponent.checkToken( token )
                        .flatMap( apiResponseModel -> super.checkToken( token, apiResponseModel )
                                ? this.patrulComponent.accepted( token )
                                : super.getGet401Error().get() );
                case START_TO_WORK -> this.patrulComponent.checkToken( token )
                        .flatMap( apiResponseModel -> super.checkToken( token, apiResponseModel )
                                ? this.patrulComponent.startToWork( token )
                                : super.getGet401Error().get() );
                case STOP_TO_WORK -> this.patrulComponent.checkToken( token )
                        .flatMap( apiResponseModel -> super.checkToken( token, apiResponseModel )
                                ? this.patrulComponent.finishWork( token )
                                : super.getGet401Error().get() );
                case SET_IN_PAUSE -> this.patrulComponent.checkToken( token )
                        .flatMap( apiResponseModel -> super.checkToken( token, apiResponseModel )
                                ? this.patrulComponent.setInPause( token )
                                : super.getGet401Error().get() );
                default -> super.getGet201Error().get(); }; }

    @PostMapping ( value = "/logout" )
    public Mono< ? > logout () {
        final String token = ( (ServletRequestAttributes) Objects.requireNonNull(
                RequestContextHolder.getRequestAttributes() ) )
                .getRequest()
                .getHeader( "Authorization" )
                .split( " " )[1];
        return RSocketPingService
                .getInstance()
                .getFlag()
                ? this.patrulComponent.checkToken( token )
                .flatMap( apiResponseModel -> super.checkToken( token, apiResponseModel )
                        ? this.patrulComponent.logout( token )
                        : super.getGet401Error().get() )
                : super.getGet503Error().get(); }

    @PostMapping ( value = "/add" )
    public Mono< ? > addUser ( @RequestBody final Patrul patrul ) {
        patrul.setSpecialToken( ( (ServletRequestAttributes) Objects
                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                .getRequest()
                .getHeader( "Authorization" )
                .split( " " )[1] );
        return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test( ( (ServletRequestAttributes) Objects
                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                .getRequest()
                .getHeader( "Authorization" ) )
                ? this.patrulComponent.addUser( patrul )
                .onErrorContinue( super::logging )
                : super.getGet401Error().get()
                : super.getGet503Error().get(); }

    @PutMapping ( value = "/update" )
    public Mono< ? > updatePatrul ( @RequestBody final Patrul patrul ) {
        try { patrul.setSpecialToken( ( (ServletRequestAttributes) Objects
                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                .getRequest()
                .getHeader( "Authorization" )
                .split( " " )[1] );
            return RSocketPingService
                    .getInstance()
                    .getFlag()
                    ? super.checkToken.test( ( (ServletRequestAttributes) Objects
                    .requireNonNull( RequestContextHolder
                            .getRequestAttributes() ) )
                    .getRequest()
                    .getHeader( "Authorization" ) )
                    ? this.patrulComponent.updatePatrul( patrul )
                    .onErrorContinue( super::logging )
                    : super.getGet401Error().get()
                    : super.getGet503Error().get();
        } catch ( final Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @GetMapping ( value = "/filterByParams" )
    public Mono< ? > filterByParams ( @RequestParam final Map< String, String > params ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test( ( (ServletRequestAttributes) Objects
                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                .getRequest()
                .getHeader( "Authorization" ) )
                ? this.patrulComponent.getUsersList()
                .filter( patrul -> super.check( patrul, params ) )
                .collectList()
                .map( patruls -> new Pagination( patruls,
                        Long.valueOf( params.getOrDefault( "size", "20" ) ),
                        Long.valueOf( params.getOrDefault( "page", "0" ) ) ) )
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( final Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @GetMapping ( value = "/getFilteredActivePatrulsForRegion" )
    public Mono< ? > getFilteredActivePatrulsForRegion ( @RequestParam final Map< String, String > params ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test( ( (ServletRequestAttributes) Objects
                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                .getRequest()
                .getHeader( "Authorization" ) )
                ? this.patrulComponent.getFilteredActivePatrulsForRegion( params )
                .collectList()
                .map( patruls -> new Pagination( patruls,
                        Long.valueOf( params.getOrDefault( "size", "20" ) ),
                        Long.valueOf( params.getOrDefault( "page", "0" ) ) ) )
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( final Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @GetMapping ( value = "/getExelFile" )
    public Mono< ? > getExelFile ( @RequestParam final Map< String, String > params ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test( ( (ServletRequestAttributes) Objects
                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                .getRequest()
                .getHeader( "Authorization" ) )
                ? this.patrulComponent.getExelFile( params )
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( final Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @GetMapping ( value = "/list" )
    public Mono< ? > getUsersList ( @RequestParam final Map< String, String > params ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test( ( (ServletRequestAttributes) Objects
                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                .getRequest()
                .getHeader( "Authorization" ) )
                ? params.containsKey( "page" )
                ? this.patrulComponent
                .getUsersList()
                .collectList()
                .map( patruls -> new Pagination( patruls,
                        Long.valueOf( params.get( "size" ) ),
                        Long.valueOf( params.get( "page" ) ) ) )
                : params.containsKey( "filter" )
                && super.checkParam.test( params.get( "filter" ) )
                ? this.patrulComponent
                .getUsersList()
                .filter( patrul -> super.check( patrul, params.get( "filter" ) ) )
                .collectList()
                .map( Pagination::new )
                .onErrorContinue( super::logging )
                : this.patrulComponent
                .getUsersList()
                .collectList()
                .map( Pagination::new )
                .onErrorContinue( super::logging )
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( final Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @GetMapping ( value = "/getActivePatrulsForRegion")
    public Mono< ? > getActivePatrulsForRegion ( @RequestParam final Map< String, String > params ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test( ( (ServletRequestAttributes) Objects
                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                .getRequest()
                .getHeader( "Authorization" ) )
                ? this.patrulComponent.getActivePatrulsForRegion( params )
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( final Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @GetMapping ( value = "/{passportSeries}" ) // returns the current Patrul
    public Mono< ? > getPatrul ( @PathVariable ( value = "passportSeries" ) final String passportSeries ) {
        try { return super.checkUUID.test( passportSeries )
                ? RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test( ( (ServletRequestAttributes) Objects
                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                .getRequest()
                .getHeader( "Authorization" ) )
                ? this.patrulComponent.getCurrentUser( passportSeries )
                : super.getGet401Error().get()
                : super.getGet503Error().get()
                : super.getGet201Error().get();
        } catch ( final Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @DeleteMapping ( value = "/delete/{passportNumber}" )
    public Mono< ? > deletePatrul ( @PathVariable( "passportNumber" ) final String passportNumber )  {
        try { final String token = ( (ServletRequestAttributes)
                    Objects.requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                    .getRequest()
                    .getHeader( "Authorization" );
            return super.checkUUID.test( passportNumber.split( "@" )[0] ) // checks that given UUID is in valid form
                    ? RSocketPingService
                    .getInstance()
                    .getFlag()
                    ? super.checkToken.test( token ) // checking token validation
                    ? this.patrulComponent.deletePatrul( passportNumber + "@" + token.split( " " )[1] )
                    : super.getGet401Error().get()
                    : super.getGet503Error().get()
                    : super.getGet201Error().get();
        } catch ( final Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @GetMapping ( value = "/filter" )
    public Flux< ? > filterByPoliceType ( @RequestParam final Map< String, String > params ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test( ( (ServletRequestAttributes) Objects
                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                .getRequest()
                .getHeader( "Authorization" ) )
                ? ( params.containsKey( "phoneNumber" )
                ^ params.containsKey( "name" ) )
                ? ( params.containsKey( "name" )
                ? this.patrulComponent.search( "name", params.get( "name" ) )
                : this.patrulComponent.search( "phoneNumber", params.get( "phoneNumber" ) ) )
                : this.patrulComponent
                .getUsersList()
                .filter( patrul -> super.check( patrul, params.get( "onMap" ) ) )
                : Flux.just( super.getGet401Error().get() )
                : Flux.just( super.getGet503Error().get() );
        } catch ( final Exception e ) {
            super.logging( e );
            return Flux.just( super.getGet401Error().get() ); } }

    @GetMapping ( value = "/filterPatrulByCar/{car}" )
    public Flux< ? > filterPatrulByCar ( @PathVariable( value = "car" ) final String car ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test( ( (ServletRequestAttributes) Objects
                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                .getRequest()
                .getHeader( "Authorization" ) )
                ? car.equals( "on" )
                ? this.patrulComponent.getUsersList()
                .filter( patrul -> super.checkParam.test( patrul.getCarNumber() )
                        && super.checkParam.test( patrul.getCarType() ) )
                : this.patrulComponent.getUsersList()
                .filter( patrul -> !super.checkParam.test( patrul.getCarNumber() )
                        && !super.checkParam.test( patrul.getCarType() ) )
                : Flux.just( super.getGet401Error().get() )
                : Flux.just( super.getGet503Error().get() );
        } catch ( final Exception e ) {
            super.logging( e );
            return Flux.just( super.getGet401Error().get() ); } }

    @PostMapping ( value = "/getPatrulStatistics" )
    public Mono< ? > getPatrulStatistics ( @RequestBody final PatrulActivityRequest request ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test( ( (ServletRequestAttributes) Objects
                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                .getRequest()
                .getHeader( "Authorization" ) )
                ? this.patrulComponent.getPatrulStatistics( request )
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( final Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @PostMapping ( value = "/findPatrulInRadius" )
    public Flux< ? > findPatrulInRadius ( @RequestBody final Point point ) {
        try { return super.checkParam.test( point )
                ? RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test( ( (ServletRequestAttributes) Objects
                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                .getRequest()
                .getHeader( "Authorization" ) )
                ? this.patrulComponent.getUsersList()
                .filter( patrul -> ( super.checkParam.test( patrul.getLatitude() )
                        && super.checkParam.test( patrul.getLongitude() ) )
                        && super.check( point, patrul ) )
                : Flux.just( super.getGet401Error().get() )
                : Flux.just( super.getGet503Error().get() )
                : Flux.just( super.getGet201Error().get() );
        } catch ( final Exception e ) {
            super.logging( e );
            return Flux.just( super.getGet401Error().get() ); } }

    @GetMapping ( value = "/getPatrulsForEscort" )
    public Flux< ? > getPatrulsForEscort () {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test( ( (ServletRequestAttributes) Objects
                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                .getRequest()
                .getHeader( "Authorization" ) )
                ? this.patrulComponent.getUsersList()
                .filter( patrul -> patrul.getTaskTypes().compareTo( TaskTypes.FREE ) == 0
                        && patrul.getTuplePermission() )
                : Flux.just( super.getGet401Error().get() )
                : Flux.just( super.getGet503Error().get() );
        } catch ( final Exception e ) {
            super.logging( e );
            return Flux.just( super.getGet401Error().get() ); } }

    @GetMapping ( value = "/addAllPatrulsToChatService" )
    public Mono< ? > addAllPatrulsToChatService () {
        try { if ( RSocketPingService
                .getInstance()
                .getFlag() ) return super.getGet401Error().get();
            final ApiResponseModel apiResponseModel = super.userMe.apply( ( (ServletRequestAttributes) Objects
                    .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                    .getRequest()
                    .getHeader( "Authorization" ) );
            return apiResponseModel
                    .getStatus()
                    .getCode() == 200
                    ? this.patrulComponent.addAllPatrulsToChatService( apiResponseModel.getData().getType() )
                    : super.getGet401Error().get();
        } catch ( final Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @PostMapping ( value = "/getAllUsedTablets" )
    public Mono< ? > getAllUsedTablets ( @RequestBody final PatrulActivityRequest request ) {
        try { return super.checkParam.test( request )
                ? RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test( ( (ServletRequestAttributes) Objects
                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                .getRequest()
                .getHeader( "Authorization" ) )
                ? this.patrulComponent.getAllUsedTablets( request )
                : super.getGet401Error().get()
                : super.getGet503Error().get()
                : super.getGet201Error().get();
        } catch ( final Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @GetMapping ( value = "/getListOfPatrulTasks" )
    public Mono< ? > getListOfPatrulTasks (
            @RequestParam( value = "page", defaultValue = "0" ) final Long page,
            @RequestParam( value = "size", defaultValue = "20" ) final Long size ) {
        try { final String token = ( (ServletRequestAttributes) Objects
                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                .getRequest()
                .getHeader( "Authorization" )
                .split( " " )[ 1 ];
            return RSocketPingService
                    .getInstance()
                    .getFlag()
                    ? this.patrulComponent.checkToken( token )
                    .flatMap( apiResponseModel -> super.checkToken( token, apiResponseModel )
                            ? this.patrulComponent.getListOfPatrulTasks (
                            Request
                                    .builder()
                                    .data( token )
                                    .subject( size )
                                    .object( page )
                                    .build() )
                            : super.getGet401Error().get() )
                    : super.getGet503Error().get();
        } catch ( final Exception e ) { return super.getGet503Error().get(); } }

    @PostMapping ( value = "/" )
    public Mono< ? > getSortedPatruls ( @RequestBody final PatrulFilter filter ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test( ( (ServletRequestAttributes) Objects
                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                .getRequest()
                .getHeader( "Authorization" ) )
                ? !super.checkParam.test( filter.getParam() )
                && !super.checkParam.test( filter.getPoliceTypeList() )
                ? this.patrulComponent
                .getUsersList()
                .collectList()
                .map( patruls -> new Pagination( patruls, patruls.size() ) )
                : this.patrulComponent
                .getUsersList()
                .filter( patrul -> super.checkList.test( filter.getPoliceTypeList() )
                        && super.checkParam.test( filter.getParam() )
                        ? super.check( patrul, filter.getParam(), filter.getPoliceTypeList() )
                        : super.checkList.test( filter.getPoliceTypeList() )
                        ? filter.getPoliceTypeList().contains( patrul.getPoliceType() )
                        : super.check( patrul, filter.getParam() ) )
                .filter( patrul -> !super.checkParam.test( filter.getRegionId() )
                        ^ Objects.equals( patrul.getRegionId(), filter.getRegionId() ) )
                .collectList()
                .map( patruls -> new Pagination( patruls, patruls.size() ) )
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( final Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @PostMapping ( value = "/getListOfPatrulsByUUID" )
    public Mono< ? > getListOfPatrulsByUUID ( @RequestBody final CardRequest cardRequest ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test( ( (ServletRequestAttributes) Objects
                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                .getRequest()
                .getHeader( "Authorization" ) )
                ? super.checkList.test( cardRequest.getPatruls() )
                ? this.patrulComponent
                .getListOfPatrulsByUUID( cardRequest )
                .collectList()
                .flatMap( patruls -> super.convert(
                        ApiResponseModel
                                .builder()
                                .success( true )
                                .data( Data
                                        .builder()
                                        .data( patruls )
                                        .build() )
                                .status( Status
                                        .builder()
                                        .message( "Patruls data" )
                                        .code( 200 )
                                        .build() )
                                .build() ) ) :
                super.getGet201Error().get()
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( final Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @GetMapping ( value = "/getAllPatrulTasks/{uuid}" )
    public Mono< ? > getListOfPatrulTasks ( @PathVariable ( value = "uuid" ) final String uuid ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test( ( (ServletRequestAttributes) Objects
                        .requireNonNull( RequestContextHolder
                                .getRequestAttributes() ) )
                        .getRequest()
                        .getHeader( "Authorization" ) )
                ? this.patrulComponent.getAllPatrulTasks ( uuid )
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( final Exception e ) { return super.getGet503Error().get(); } }

    @PostMapping ( value = "/getPatrulInRadiusList" )
    public Mono< ? > getPatrulInRadiusList ( @RequestBody final Point point ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? this.patrulComponent.getPatrulInRadiusList( point )
                : super.getGet503Error().get();
        } catch ( final Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @PostMapping ( value = "/updatePatrulImage" )
    public Mono< ? > updatePatrulImage ( @RequestBody final PatrulImageRequest request ) {
        if ( !RSocketPingService
                .getInstance()
                .getFlag() ) return super.getGet503Error().get();
        final String token = ( (ServletRequestAttributes) Objects.requireNonNull(
                RequestContextHolder.getRequestAttributes() ) )
                .getRequest()
                .getHeader( "Authorization" )
                .split( " " )[1];
        return this.patrulComponent
                .checkToken( token )
                .flatMap( apiResponseModel -> super.checkToken( token, apiResponseModel, request )
                        ? this.patrulComponent.updatePatrulImage( request )
                        : super.getGet401Error().get() ); }

    @PostMapping ( value = "/updatePatrulPhoneNumber" )
    public Mono< ? > updatePatrulPhoneNumber ( @RequestBody final PatrulImageRequest request ) {
        if ( !RSocketPingService
                .getInstance()
                .getFlag() ) return super.getGet503Error().get();
        final String token = ( (ServletRequestAttributes) Objects.requireNonNull(
                RequestContextHolder.getRequestAttributes() ) )
                .getRequest()
                .getHeader( "Authorization" )
                .split( " " )[1];
        return this.patrulComponent
                .checkToken( token )
                .flatMap( apiResponseModel -> super.checkToken( token, apiResponseModel, request )
                        ? this.patrulComponent.updatePatrulPhoneNumber( request )
                        : super.getGet401Error().get() ); }

    @PostMapping ( value = "/getTabletUsageStatistics" )
    public Mono< ? > getTabletUsageStatistics ( @RequestBody final PatrulActivityRequest request ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test( ( (ServletRequestAttributes) Objects
                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                .getRequest()
                .getHeader( "Authorization" ) )
                ? this.patrulComponent.getTabletUsageStatistics( request )
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( final Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }
}
