package com.ssd.mvd.components;

import org.springframework.messaging.rsocket.RSocketRequester;
import org.springframework.stereotype.Component;

import com.ssd.mvd.controllerForFindFace.CarTotalData;
import com.ssd.mvd.inspectors.LogInspector;
import com.ssd.mvd.entity.ApiResponseModel;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;

@Component
@lombok.RequiredArgsConstructor
public class WarningCarComponent extends LogInspector {
    private final RSocketRequester requester;

    public Flux< CarTotalData > getAllCarTotalData () { return this.requester
            .route( "getAllCarTotalData" )
            .retrieveFlux( CarTotalData.class )
            .onErrorContinue( super::logging ); }

    public Mono< List > getViolationsInformationsList( String gosnumber ) { return this.requester
            .route( "getViolationsInformationList" )
            .data( gosnumber )
            .retrieveMono( List.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( new ArrayList() ); }

    public Mono< ApiResponseModel > getWarningCarDetails( String gosnumber ) { return this.requester
            .route( "getWarningCarDetails" )
            .data( gosnumber )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< ApiResponseModel > addNewWarningCar( CarTotalData carTotalData ) { return this.requester
            .route( "addNewWarningCar" )
            .data( carTotalData )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }
}
