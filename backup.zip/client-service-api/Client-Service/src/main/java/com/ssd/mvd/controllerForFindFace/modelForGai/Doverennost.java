package com.ssd.mvd.controllerForFindFace.modelForGai;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class Doverennost {
    private String DateBegin;
    private String DateValid;
    private String IssuedBy;
}
