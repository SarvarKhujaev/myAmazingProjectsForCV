package com.ssd.mvd.controllerForEscort;

import java.util.List;
import java.util.UUID;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class EscortTuple {
    private UUID uuid; // own of id of each escortTuple
    private UUID uuidOfPolygon; // id of polygon
    private String countries;

    private List< UUID > patrulList;
    private List< UUID > tupleOfCarsList;
}
