package com.ssd.mvd.components;

import org.springframework.messaging.rsocket.RSocketRequester;
import org.springframework.stereotype.Component;

import com.ssd.mvd.inspectors.LogInspector;
import com.ssd.mvd.entity.ApiResponseModel;
import com.ssd.mvd.entity.PoliceType;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Component
@lombok.RequiredArgsConstructor
public class PoliceTypeComponent extends LogInspector {
    private final RSocketRequester requester;

    public Flux< PoliceType > getPoliceTypeList () { return this.requester
            .route( "getPoliceTypeList" )
            .retrieveFlux( PoliceType.class )
            .onErrorContinue( super::logging ); }

    public Mono< ApiResponseModel > addPoliceType ( PoliceType policeType ) { return this.requester
            .route( "addPoliceType" )
            .data( policeType )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< ApiResponseModel > updatePoliceType( PoliceType policeType ) { return this.requester
            .route( "updatePoliceType" )
            .data( policeType )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< ApiResponseModel > deletePoliceType ( PoliceType policeType ) { return this.requester
            .route( "deletePoliceType" )
            .data( policeType )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }
}
