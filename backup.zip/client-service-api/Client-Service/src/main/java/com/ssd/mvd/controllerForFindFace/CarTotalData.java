package com.ssd.mvd.controllerForFindFace;

import com.ssd.mvd.controllerForFindFace.modelForGai.*;
import com.ssd.mvd.entity.ReportForCard;
import com.ssd.mvd.constants.Status;
import java.util.List;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class CarTotalData {
    private String gosNumber;
    private String cameraImage; // image which was made by camera

    private Tonirovka tonirovka;
    private Insurance insurance;
    private ModelForCar modelForCar;
    private PsychologyCard psychologyCard;
    private ViolationsList violationsList;
    private DoverennostList doverennostList;
    private ModelForCarList modelForCarList; // the list of all cars of each citizen

    private Status status;
    private List< String > patruls; // link to list of Patruls who is gonna deal with this Card
    private List< ReportForCard > reportForCards;
}
