package com.ssd.mvd.inspectors;

import org.springframework.http.ResponseEntity;
import com.ssd.mvd.entity.ApiResponseModel;
import org.springframework.http.HttpStatus;
import com.ssd.mvd.entity.Status;

import reactor.core.publisher.Mono;
import java.util.function.Function;
import java.util.function.Supplier;

@lombok.Data
public class ErrorController extends DataValidateInspector {
    private final Supplier< Mono< ResponseEntity< ApiResponseModel > > > get503Error = () -> super.convert(
            ResponseEntity
                    .status( HttpStatus.SERVICE_UNAVAILABLE )
                    .body( ApiResponseModel
                            .builder()
                            .success( false )
                            .status( Status
                                    .builder()
                                    .message( "OOops unfortunately the server is temporary unavailable" )
                                    .code( 503 )
                                    .build() )
                            .build() ) );

    private final Function< String, Mono< ResponseEntity< ApiResponseModel > > > get406Error = message -> super.convert(
            ResponseEntity
                    .status( HttpStatus.NOT_ACCEPTABLE )
                    .body( ApiResponseModel
                            .builder()
                            .success( false )
                            .status( Status
                                    .builder()
                                    .message( message )
                                    .code( 406 )
                                    .build() )
                            .build() ) );

    private final Supplier< Mono< ResponseEntity< ApiResponseModel > > > get201Error = () -> super.convert(
            ResponseEntity
                    .status( HttpStatus.NOT_ACCEPTABLE )
                    .body( ApiResponseModel
                            .builder()
                            .status( Status
                                    .builder()
                                    .message( "Wrong Params" )
                                    .code( 201 )
                                    .build() )
                            .build() ) );

    private final Supplier< Mono< ResponseEntity< ApiResponseModel > > > get401Error = () -> super.convert(
            ResponseEntity
                    .status( HttpStatus.UNAUTHORIZED )
                    .body( ApiResponseModel
                            .builder()
                            .success( false )
                            .status( Status
                                    .builder()
                                    .message( "Authorization failed" )
                                    .code( 401 )
                                    .build() )
                            .build() ) );

    private final Supplier< ApiResponseModel > getErrorResponse = () -> ApiResponseModel
            .builder()
            .success( false )
            .status( Status
                    .builder()
                    .message( "Error in service work" )
                    .code( 201 )
                    .build() )
            .build();
}
