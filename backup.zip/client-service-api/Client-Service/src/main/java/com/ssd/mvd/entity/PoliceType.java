package com.ssd.mvd.entity;

import java.util.UUID;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class PoliceType {
    private UUID uuid = UUID.randomUUID();
    private String icon;
    private String icon2;
    private String policeType;
}
