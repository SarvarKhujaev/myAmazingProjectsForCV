package com.ssd.mvd.controllerForFindFace.modelForAddress;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class PermanentRegistration {
    private pRegion pRegion;
    private String pAddress;
    private String pCadastre;
    private String pRegistrationDate;
}
