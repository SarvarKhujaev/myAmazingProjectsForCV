package com.ssd.mvd.inspectors;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;

import com.ssd.mvd.configs.RSocketPingService;
import com.ssd.mvd.token.PatrulLoginRequest;
import com.ssd.mvd.Authorization.Response;
import com.ssd.mvd.task.card.PatrulSos;
import com.ssd.mvd.Authorization.User;
import com.ssd.mvd.entity.*;

import org.springframework.http.HttpHeaders;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;
import reactor.core.publisher.Flux;

import java.util.function.BiFunction;
import java.util.function.Predicate;
import java.util.function.Function;
import java.util.regex.Pattern;
import java.util.*;

import static java.lang.Math.cos;
import static java.lang.Math.*;

public class DataValidateInspector {
    private String key;
    private Boolean flag = true;
    private Iterator< String > iterator;
    private final Gson gson = new Gson();
    private final List< String > permissions = List.of(
            "102",
            "YTX",
            "JINOYATLAR",
            "KUCH_VA_VOSITALAR",
            "JINOIY_ISHLAR_XISOBI",
            "QO’NG’IROQLAR_XIZMATI",
            "JINOIY_HUQUQIY_STATISTIKA",
            "АNIQLANGAN_QIDIRUVDAGILAR",
            "JINOIY_ISH_MILLIY_GVARDIYA",
            "SHANXAY_HAMKORLIK_TASHKILOTI",
            "YOʼL_TRANSPORT_XODISALRI''LLARI",
            "MAXSUS_AVTOTRANSPORT_VOSITALARI" );
    protected final ObjectMapper objectMapper = new ObjectMapper();

    private final Pattern UUID_REGEX = Pattern.compile("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$");

    protected <T> Mono< T > convert ( final T o ) { return Mono.just( o ); }

    protected final BiFunction< String, Integer, String > checkSimCard = ( token, index ) -> {
            try {
                final String[] tokens = new String( Base64
                        .getDecoder()
                        .decode( token ) )
                        .split( "@" );
                return tokens.length >= 4
                        ? tokens[ index ]
                        : null;
            } catch ( final IndexOutOfBoundsException e ) { return null; } };

    protected final Function< String, ApiResponseModel > userMe = token -> {
            final ApiResponseModel apiResponseModel = ApiResponseModel
                    .builder()
                    .status( Status.builder().build() )
                    .build();
            try { if ( token != null ) {
                final HttpResponse< JsonNode > response = Unirest
                        .get( RSocketPingService
                                .getInstance()
                                .getBasePath() + "/auth/me" )
                        .header( HttpHeaders.AUTHORIZATION, token )
                        .asJson();
                if ( response.getStatus() == 200 ) {
                    final Response response1 = this.gson
                            .fromJson( response
                                            .getBody()
                                            .toString(),
                                    Response.class );
                    if ( response1.getCode() == 200 ) {
                        final User user = response1.getData();
                        final List< String > users = Flux.fromStream( user.getPermissions().stream() )
                                .parallel( user.getPermissions().size() )
                                .runOn( Schedulers.parallel() )
                                .filter( this.permissions::contains )
                                .sequential()
                                .publishOn( Schedulers.single() )
                                .collectList()
                                .block();
                        if ( this.checkList.test( users ) ) {
                            apiResponseModel.getStatus().setCode( 200L );
                            apiResponseModel.getStatus().setMessage( "SUCCESS" );
                        } else {
                            apiResponseModel.getStatus().setCode( 403L );
                            apiResponseModel.getStatus().setMessage( "FORBIDDEN" ); } } }
                else {
                    apiResponseModel.getStatus().setCode( response.getStatus() );
                    apiResponseModel.getStatus().setMessage( "AUTH ERROR "+ response.getStatusText() ); }
            } else {
                apiResponseModel.getStatus().setCode( 401L );
                apiResponseModel.getStatus().setMessage( "UNAUTHORIZED" ); }
            } catch ( final Exception e ) { return apiResponseModel; }
            return apiResponseModel; };

    protected final Predicate< String > checkToken = s -> this.userMe
            .apply( s )
            .getStatus()
            .getCode() == 200;

    protected final Predicate< Object > checkParam = Objects::nonNull;

    protected final Predicate< List< ? > > checkList = list -> list != null && list.size() > 0;

    public final Predicate< String > checkUUID = uuid -> this.checkParam.test( uuid ) && this.UUID_REGEX.matcher( uuid ).matches();

    protected final Predicate< Point > checkPoint = point ->
            point != null
            && point.getLatitude() != null
            && point.getLongitude() != null
            && point.getLatitude() > 0
            && point.getLongitude() > 0;

    protected final Predicate< PatrulLoginRequest > checkLoginRequest = patrulLoginRequest ->
            patrulLoginRequest != null
            && patrulLoginRequest.getLogin() != null
            && !patrulLoginRequest.getLogin().isEmpty()
            && patrulLoginRequest.getPassword() != null
            && !patrulLoginRequest.getPassword().isEmpty()
            && patrulLoginRequest.getSimCardNumber() != null
            && !patrulLoginRequest.getSimCardNumber().isEmpty();

    // проверяет правильность написания названий страны на разных языках
    protected final Predicate< Country > checkCountryGrammar = country ->
            country.getCountryNameEn() != null
            && country.getCountryNameEn().length() > 0

            && country.getCountryNameUz() != null
            && country.getCountryNameUz().length() > 0

            && country.getCountryNameRu() != null
            && country.getCountryNameRu().length() > 0

            && country.getSymbol() != null
            && country.getSymbol().length() > 0;

    protected static final Double p = PI / 180;

    protected Boolean check ( final Point first, final Patrul second ) {
        return ( 12742 * asin( sqrt( 0.5 - cos( ( second.getLatitude() - first.getLatitude() ) * p ) / 2
            + cos( first.getLatitude() * p )
            * cos( second.getLatitude() * p )
            * ( 1 - cos( ( second.getLongitude() - first.getLongitude() ) * p ) ) / 2 ) ) * 1000 ) <= first.getRadius(); }

    protected Boolean check ( final Patrul patrul, final String params ) {
        return patrul.getSurnameNameFatherName()
                .toLowerCase()
                .contains( params.toLowerCase() )
                ^ patrul.getPoliceType()
                .toLowerCase()
                .contains( params.toLowerCase() )
                ^ ( this.checkParam.test( patrul.getDistrictName() )
                && patrul.getDistrictName()
                .toLowerCase()
                .contains( params.toLowerCase() ) )
                ^ patrul.getPassportNumber()
                .toLowerCase()
                .contains( params.toLowerCase() )
                ^ patrul.getStatus()
                .name()
                .toLowerCase()
                .contains( params.toLowerCase() )
                ^ patrul.getOrganName()
                .toLowerCase()
                .contains( params.toLowerCase() )
                ^ patrul.getPhoneNumber()
                .toLowerCase()
                .contains( params.toLowerCase() )
                ^ patrul.getRegionName()
                .toLowerCase()
                .contains( params.toLowerCase() )
                ^ patrul.getCarNumber()
                .toLowerCase()
                .contains( params.toLowerCase() ); }

    protected Boolean check ( final Patrul patrul, final Map< String, String > params ) {
        this.setFlag( true );
        this.iterator = params.keySet().iterator();
        while ( this.flag && this.iterator.hasNext() ) {
            switch ( ( this.key = this.iterator.next() ) ) {
                case "page", "size" -> this.setFlag( true );

                case "status" -> this.setFlag( patrul
                        .getStatus()
                        .name()
                        .compareTo( params.get( this.key ) ) == 0 );

                case "fio" -> this.setFlag( patrul
                        .getSurnameNameFatherName()
                        .toLowerCase()
                        .contains( params.get( this.key ).toLowerCase() ) );

                case "name" -> this.setFlag( patrul
                        .getName()
                        .toLowerCase()
                        .contains( params.get( this.key ).toLowerCase() ) );

                case "surname" -> this.setFlag( patrul
                        .getSurname()
                        .toLowerCase()
                        .contains( params.get( this.key ).toLowerCase() ) );

                case "fatherName" -> this.setFlag( patrul
                        .getFatherName()
                        .toLowerCase()
                        .contains( params.get( this.key ).toLowerCase() ) );

                case "passportNumber" -> this.setFlag( patrul
                        .getPassportNumber()
                        .toLowerCase()
                        .contains( params.get( this.key ).toLowerCase() ) );

                case "region" -> this.setFlag( patrul
                        .getRegionId()
                        .equals( Long.parseLong( params.get( this.key ) ) ) );

                case "mahalla" -> this.setFlag( patrul
                        .getMahallaId()
                        .equals( Long.parseLong( params.get( this.key ) ) ) );

                case "district" -> this.setFlag( patrul
                        .getDistrictId()
                        .equals( Long.parseLong( params.get( this.key ) ) ) );

                case "organ" -> this.setFlag( patrul
                        .getOrgan()
                        .compareTo( UUID.fromString( params.get( this.key ) ) ) == 0 );

                case "regionName" -> this.setFlag( patrul
                        .getRegionName()
                        .toLowerCase()
                        .contains( params.get( this.key ).toLowerCase() ) );

                case "districtName" -> this.setFlag(
                        this.checkParam.test( patrul.getDistrictName() )
                        && patrul
                        .getDistrictName()
                        .toLowerCase()
                        .contains( params.get( this.key ).toLowerCase() ) );

                default -> this.setFlag( patrul
                        .getPoliceType()
                        .toLowerCase()
                        .contains( params.get( this.key ).toLowerCase() ) ); } }
        return this.flag; }

    private void setFlag ( final boolean equals ) { this.flag = equals; }

    protected Boolean check ( final Polygon polygon, final Map< String, String > params ) {
        this.setFlag( true );
        this.iterator = params.keySet().iterator();
        while ( this.flag && this.iterator.hasNext() ) {
            switch ( ( this.key = this.iterator.next() ) ) {
                case "organ" -> flag = polygon
                        .getOrgan()
                        .compareTo( UUID.fromString( params.get( key ) ) ) == 0;
                case "region" -> {
                    assert polygon != null;
                    flag = polygon.getRegionId() == Long.parseLong( params.get( key ) ); }
                case "mahalla" -> {
                    assert polygon != null;
                    flag = polygon.getMahallaId() == Long.parseLong( params.get( key ) ); }
                case "district" -> {
                    assert polygon != null;
                    flag = polygon.getDistrictId() == Long.parseLong( params.get( key ) ); }
                default -> {
                    assert polygon != null;
                    flag = polygon.getPolygonType().getUuid().compareTo( UUID.fromString( params.get( key ) ) ) == 0; }
            } } return this.flag; }

    protected Boolean check ( final Patrul patrul, final String params, final List< String > policeType ) {
        return policeType.contains( patrul.getPoliceType() ) && ( patrul.getSurnameNameFatherName()
                .toLowerCase()
                .contains( params.toLowerCase() )
                ^ patrul.getPoliceType()
                .toLowerCase()
                .contains( params.toLowerCase() )
                ^ patrul.getPassportNumber()
                .toLowerCase()
                .contains( params.toLowerCase() )
                ^ patrul.getStatus()
                .name()
                .toLowerCase()
                .contains( params.toLowerCase() )
                ^ patrul.getCarNumber()
                .toLowerCase()
                .contains( params.toLowerCase() ) ); }

    protected Boolean checkToken ( final String token, final ApiResponseModel apiResponseModel ) {
        if ( apiResponseModel.getStatus().getCode() != 200 ) return false;
        final String simcardNumber = this.checkSimCard.apply( token, 3 );
        final Patrul patrul = this.objectMapper.convertValue( apiResponseModel.getData().getData(), new TypeReference<>() {} );
        return patrul.getSimCardNumber().equals( simcardNumber ); }

    protected Boolean checkToken ( final String token, final ApiResponseModel apiResponseModel, final PatrulSos patrulSos ) {
        final String simcardNumber = this.checkSimCard.apply( token, 3 );
        if ( this.checkParam.test( apiResponseModel.getData() ) && this.checkParam.test( apiResponseModel.getData().getData() ) ) {
            final Patrul patrul = this.objectMapper.convertValue( apiResponseModel.getData().getData(), new TypeReference<>() {} );
            patrulSos.setPatrulUUID( patrul != null ? patrul.getUuid() : null );
            return patrul != null && patrul.getSimCardNumber().equals( simcardNumber ); }
        return false; }

    protected Boolean checkToken ( final String token, final ApiResponseModel apiResponseModel, final SosRequest sosRequest ) {
        final String simcardNumber = this.checkSimCard.apply( token, 3 );
        if ( this.checkParam.test( apiResponseModel.getData() ) && this.checkParam.test( apiResponseModel.getData().getData() ) ) {
            final Patrul patrul = this.objectMapper.convertValue( apiResponseModel.getData().getData(), new TypeReference<>() {} );
            sosRequest.setPatrulUUID( patrul != null ? patrul.getUuid() : null );
            return patrul != null && patrul.getSimCardNumber().equals( simcardNumber ); }
        return false; }

    protected Boolean checkToken ( final String token, final ApiResponseModel apiResponseModel, final PatrulImageRequest request ) {
        final String simcardNumber = this.checkSimCard.apply( token, 3 );
        if ( this.checkParam.test( apiResponseModel.getData() ) && this.checkParam.test( apiResponseModel.getData().getData() ) ) {
            final Patrul patrul = this.objectMapper.convertValue( apiResponseModel.getData().getData(), new TypeReference<>() {} );
            request.setPatrulUUID( patrul.getUuid() );
            return patrul.getSimCardNumber().equals( simcardNumber ); }
        return false; }
}
