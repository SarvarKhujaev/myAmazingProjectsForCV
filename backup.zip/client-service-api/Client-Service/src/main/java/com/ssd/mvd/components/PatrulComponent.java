package com.ssd.mvd.components;

import com.ssd.mvd.task.selfEmploymentTask.SelfEmploymentTask;
import com.ssd.mvd.token.PatrulLoginRequest;
import com.ssd.mvd.inspectors.LogInspector;
import com.ssd.mvd.task.card.CardRequest;
import com.ssd.mvd.constants.Status;
import com.ssd.mvd.entity.*;

import org.springframework.messaging.rsocket.RSocketRequester;
import org.springframework.stereotype.Component;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Component
@lombok.RequiredArgsConstructor
public final class PatrulComponent extends LogInspector {
    private final RSocketRequester requester;

    public Mono< ApiResponseModel > logout ( final String token ) { return this.requester
            .route( Status.LOGOUT.name() )
            .data( token )
            .retrieveMono( ApiResponseModel.class )
            .defaultIfEmpty( super.getGetErrorResponse().get() )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< ApiResponseModel > arrived ( final String token ) { return this.requester
            .route( Status.ARRIVED.name() )
            .data( token )
            .retrieveMono( ApiResponseModel.class )
            .defaultIfEmpty( super.getGetErrorResponse().get() )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< ApiResponseModel > accepted ( final String token ) { return this.requester
            .route( Status.ACCEPTED.name() )
            .data( token )
            .retrieveMono( ApiResponseModel.class )
            .defaultIfEmpty( super.getGetErrorResponse().get() )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< ApiResponseModel > checkToken ( final String token ) { return this.requester
            .route( "checkToken" )
            .data( token )
            .retrieveMono( ApiResponseModel.class )
            .defaultIfEmpty( super.getGetErrorResponse().get() )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< ApiResponseModel > finishWork ( final String token ) { return this.requester
            .route( Status.STOP_TO_WORK.name() )
            .data( token )
            .retrieveMono( ApiResponseModel.class )
            .defaultIfEmpty( super.getGetErrorResponse().get() )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< ApiResponseModel > backToWork ( final String token ) { return this.requester
            .route( Status.RETURNED_TO_WORK.name() )
            .data( token )
            .retrieveMono( ApiResponseModel.class )
            .defaultIfEmpty( super.getGetErrorResponse().get() )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< ApiResponseModel > getTaskDetails ( final Data data ) { return this.requester
            .route( "getTaskDetails" )
            .data( data )
            .retrieveMono( ApiResponseModel.class )
            .defaultIfEmpty( super.getGetErrorResponse().get() )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< ApiResponseModel > setInPause ( final String  token ) { return this.requester
            .route( Status.SET_IN_PAUSE.name() )
            .data( token )
            .retrieveMono( ApiResponseModel.class )
            .defaultIfEmpty( super.getGetErrorResponse().get() )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< ApiResponseModel > startToWork ( final String token ) { return this.requester
            .route( Status.START_TO_WORK.name() )
            .data( token )
            .retrieveMono( ApiResponseModel.class )
            .defaultIfEmpty( super.getGetErrorResponse().get() )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< ApiResponseModel > getPatrulDataByToken ( final String token ) { return this.requester
            .route( "getPatrulDataByToken" )
            .data( token )
            .retrieveMono( com.ssd.mvd.entity.ApiResponseModel.class )
            .defaultIfEmpty( super.getGetErrorResponse().get() )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< ApiResponseModel > patrulLogin ( final PatrulLoginRequest patrulLoginRequest ) { return this.requester
            .route( Status.LOGIN.name() )
            .data( patrulLoginRequest )
            .retrieveMono( ApiResponseModel.class )
            .defaultIfEmpty( super.getGetErrorResponse().get() )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Flux< Patrul > getUsersList () { return this.requester
            .route( "getAllUsersList" )
            .retrieveFlux( Patrul.class )
            .onErrorContinue( super::logging ); }

    public Mono< ApiResponseModel > addUser ( final Patrul patrul ) { return this.requester
            .route( "addUser" )
            .data( patrul )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Flux< Patrul > findTheClosestPatruls ( final Point point ) { return this.requester
            .route("findTheClosestPatruls" )
            .data( point )
            .retrieveFlux( Patrul.class )
            .onErrorContinue( super::logging ); }

    public Mono< ApiResponseModel > updatePatrul ( final Patrul patrul ) { return this.requester
            .route( "updatePatrul" )
            .data( patrul )
            .retrieveMono( ApiResponseModel.class )
            .defaultIfEmpty( super.getGetErrorResponse().get() )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< Patrul > getCurrentUser ( final String passportSeries ) { return this.requester
            .route( "getCurrentUser" )
            .data( passportSeries )
            .retrieveMono( Patrul.class )
            .onErrorContinue( super::logging ); }

    public Flux< Patrul > search ( final String parameter, final String value ) { return this.getUsersList()
            .filter( patrul -> parameter.equals( "name" )
                    ? patrul.getName().toLowerCase().contains( value.toLowerCase() )
                    : patrul.getPhoneNumber().toLowerCase().contains( value.toLowerCase() ) ); }

    public Mono< ApiResponseModel > getCurrentActiveTask ( final String token ) { return this.requester
            .route( "getCurrentActiveTask" )
            .data( token )
            .retrieveMono( ApiResponseModel.class )
            .defaultIfEmpty( super.getGetErrorResponse().get() )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< ApiResponseModel > deletePatrul ( final String passportNumber ) { return this.requester
            .route( "deletePatrul" )
            .data( passportNumber )
            .retrieveMono( ApiResponseModel.class )
            .defaultIfEmpty( super.getGetErrorResponse().get() )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< List > getAllUsedTablets ( final PatrulActivityRequest request ) { return this.requester
            .route( "getAllUsedTablets" )
            .data( request )
            .retrieveMono( List.class )
            .defaultIfEmpty( new ArrayList() )
            .onErrorContinue( super::logging )
            .onErrorReturn( new ArrayList() ); }

    public Flux< Patrul > getListOfPatrulsByUUID ( final CardRequest cardRequest ) { return this.requester
            .route( "getListOfPatrulsByUUID" )
            .data( cardRequest )
            .retrieveFlux( Patrul.class ); }

    // For android request
    public Mono< ApiResponseModel > getListOfPatrulTasks ( final Request request ) { return this.requester
            .route( "getListOfPatrulTasks" )
            .data( request )
            .retrieveMono( ApiResponseModel.class )
            .defaultIfEmpty( super.getGetErrorResponse().get() )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    // for Front end request
    public Mono< ApiResponseModel > getAllPatrulTasks ( final String uuid ) { return this.requester
            .route( "getAllPatrulTasks" )
            .data( uuid )
            .retrieveMono( ApiResponseModel.class )
            .defaultIfEmpty( super.getGetErrorResponse().get() )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< SelfEmploymentTask > getSelfEmploymentTask ( final String uuid ) {
        return this.requester
                .route( "getSelfEmployment" )
                .data( uuid )
                .retrieveMono( SelfEmploymentTask.class )
                .onErrorContinue( super::logging ); }

    public Mono< ApiResponseModel > addAllPatrulsToChatService ( final String token ) { return this.requester
            .route( "addAllPatrulsToChatService" )
            .data( token )
            .retrieveMono( ApiResponseModel.class )
            .defaultIfEmpty( super.getGetErrorResponse().get() )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< ApiResponseModel > addReportForSelfEmployment ( final ReportForCard reportForCard ) { return this.requester
            .route( "addReportForSelfEmployment" )
            .data( reportForCard )
            .retrieveMono( ApiResponseModel.class )
            .defaultIfEmpty( super.getGetErrorResponse().get() )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< ApiResponseModel > addSelfEmployment ( final SelfEmploymentTask selfEmploymentTask ) {
        return this.requester
            .route( "addSelfEmployment" )
            .data( selfEmploymentTask )
            .retrieveMono( ApiResponseModel.class )
            .defaultIfEmpty( super.getGetErrorResponse().get() )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< PatrulActivityStatistics > getPatrulStatistics ( final PatrulActivityRequest request ) {
        return this.requester
                .route( "getPatrulStatistics" )
                .data( request )
                .retrieveMono( PatrulActivityStatistics.class )
                .onErrorContinue( super::logging ); }

    public Mono< PatrulInRadiusList > getPatrulInRadiusList ( final Point point ) { return this.requester
            .route( "getPatrulInRadiusList" )
            .data( point )
            .retrieveMono( PatrulInRadiusList.class )
            .onErrorContinue( super::logging ); }

    public Mono< ApiResponseModel > updatePatrulImage ( final PatrulImageRequest request ) { return this.requester
            .route( "updatePatrulImage" )
            .data( request )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< ApiResponseModel > updatePatrulPhoneNumber ( final PatrulImageRequest request ) { return this.requester
            .route( "UPDATE_PATRUL_PHONE_NUMBER" )
            .data( request )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Flux< Patrul > getFilteredActivePatrulsForRegion ( final Map< String, String > params ) {
        return this.requester
                .route( "GET_FILTERED_ACTIVE_PATRULS" )
                .data( params )
                .retrieveFlux( Patrul.class )
                .onErrorContinue( super::logging ); }

    public Mono< TabletUsageStatistics > getTabletUsageStatistics ( final PatrulActivityRequest request ) {
        return this.requester
                .route( "GET_TABLETS_USAGE_STATISTICS" )
                .data( request )
                .retrieveMono( TabletUsageStatistics.class )
                .onErrorContinue( super::logging ); }

    public Mono< PatrulActivityResponse > getActivePatrulsForRegion ( final Map< String, String > params ) { return this.requester
            .route( "GET_ACTIVE_PATRULS" )
            .data( params )
            .retrieveMono( PatrulActivityResponse.class )
            .onErrorContinue( super::logging ); }

    public Mono< ApiResponseModel > getExelFile ( final Map< String, String > params ) {
        return this.requester
                .route( "GET_EXEL_FILE" )
                .data( params )
                .retrieveMono( ApiResponseModel.class )
                .onErrorContinue( super::logging )
                .onErrorReturn( super.getGetErrorResponse().get() ); }
}
