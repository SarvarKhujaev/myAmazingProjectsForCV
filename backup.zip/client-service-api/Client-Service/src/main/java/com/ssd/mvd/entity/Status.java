package com.ssd.mvd.entity;

@lombok.Data
@lombok.Builder
public final class Status {
    private long code;
    private String message;
}
