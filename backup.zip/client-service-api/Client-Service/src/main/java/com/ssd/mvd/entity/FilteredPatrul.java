package com.ssd.mvd.entity;

import com.ssd.mvd.constants.Status;
import java.util.UUID;

@lombok.Data
public final class FilteredPatrul {
    private UUID uuid;
    private String carType; // модель машины
    private String carNumber;
    private String policeType; // choosing from dictionary
    private String patrulImageLink;
    private String surnameNameFatherName;

    private Status status;

    public FilteredPatrul ( final Patrul patrul ) {
        this.setSurnameNameFatherName( patrul.getSurnameNameFatherName() );
        this.setPatrulImageLink( patrul.getPatrulImageLink() );
        this.setPoliceType( patrul.getPoliceType() );
        this.setCarNumber( patrul.getCarNumber() );
        this.setCarType( patrul.getCarType() );
        this.setStatus( patrul.getStatus() );
        this.setUuid( patrul.getUuid() ); }
}
