package com.ssd.mvd.controllerForTablets;

import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.bind.annotation.*;

import com.ssd.mvd.components.PolygonForPatrulComponent;
import com.ssd.mvd.configs.RSocketPingService;
import com.ssd.mvd.inspectors.LogInspector;
import com.ssd.mvd.entity.*;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Objects;
import java.util.Map;

@CrossOrigin
@RestController
@lombok.RequiredArgsConstructor
@RequestMapping ( value = "/clientService/api/v1/polygonForPatrul" )
public class PolygonForPatrulController extends LogInspector {
    private final PolygonForPatrulComponent component;

    @GetMapping ( value = "/list" )
    public Flux< ? > list () {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                ( (ServletRequestAttributes) Objects
                        .requireNonNull( RequestContextHolder
                                .getRequestAttributes() ) )
                        .getRequest()
                        .getHeader( "Authorization" ) )
                ? this.component.listOfPoligonsForPatrul()
                : Flux.just( super.getGet401Error().get() )
                : Flux.just( super.getGet503Error().get() );
        } catch ( Exception e ) {
            super.logging( e );
            return Flux.just( super.getGet401Error().get() ); } }

    @PostMapping ( value = "/add" )
    public Mono< ? > add ( @RequestBody final Polygon polygon ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                            .requireNonNull( RequestContextHolder
                                    .getRequestAttributes() ) )
                            .getRequest()
                            .getHeader( "Authorization" ) )
                ? this.component.addPolygon( polygon )
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @GetMapping ( value = "/polygonPatrulList" )
    public Mono< Map< String, String > > polygonPatrulList () {
        return super.convert(
                Map.of( "533a330c-3e41-4e9e-81c9-89cc827d9f5f", "Mahalla",
                "0c9ae3b5-259a-4a8f-b2e5-08db697778c1", "Polygon",
                "c56d1c03-c804-4c3e-a351-05ecdfca0fa8", "Kocha" ) ); }

    @GetMapping ( value = "/filter" )
    public Flux< ? > filter ( @RequestParam final Map< String, String > params ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                            .requireNonNull( RequestContextHolder
                                    .getRequestAttributes() ) )
                            .getRequest()
                            .getHeader( "Authorization" ) )
                ? !params.containsKey( "name" )
                ? this.component.listOfPoligonsForPatrul()
                .filter( polygon -> super.check( polygon, params ) )
                : this.component.listOfPoligonsForPatrul()
                .filter( polygon -> polygon.getName().equals( params.get( "name" ) ) )
                : Flux.just( super.getGet401Error().get() )
                : Flux.just( super.getGet503Error().get() );
        } catch ( Exception e ) {
            super.logging( e );
            return Flux.just( super.getGet401Error().get() ); } }

    @PutMapping ( value = "/update" )
    public Mono< ? > updatePolygonForPatrul ( @RequestBody final Polygon polygon ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                ( (ServletRequestAttributes) Objects
                        .requireNonNull( RequestContextHolder
                                .getRequestAttributes() ) )
                        .getRequest()
                        .getHeader( "Authorization" ) )
                ? this.component.updatePolygonForPatrul( polygon )
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @GetMapping ( value = "/polygonPatruls/{uuid}" )
    public Mono< ? > polygonPatruls ( @PathVariable ( value = "uuid" ) final String uuid ) {
        try { return super.checkUUID.test( uuid )
                ? RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                            .requireNonNull( RequestContextHolder
                                    .getRequestAttributes() ) )
                            .getRequest()
                            .getHeader( "Authorization" ) ) ? this.component.getPatrulsForPolygon( uuid )
                : super.getGet401Error().get()
                : super.getGet503Error().get()
                : super.getGet201Error().get();
        } catch ( Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @DeleteMapping ( value = "/delete/{polygonName}" )
    public Mono< ? > delete ( @PathVariable ( value = "polygonName" ) final String polygonName ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                ( (ServletRequestAttributes) Objects
                        .requireNonNull( RequestContextHolder
                                .getRequestAttributes() ) )
                        .getRequest()
                        .getHeader( "Authorization" ) )
                ? this.component.delete( polygonName )
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @PostMapping ( value = "/addPatrulToPolygon" )
    public Mono< ? > addPatrulToPolygon ( @RequestBody final ScheduleForPolygonPatrul scheduleForPolygonPatrul ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                            .requireNonNull( RequestContextHolder
                                    .getRequestAttributes() ) )
                            .getRequest()
                            .getHeader( "Authorization" ) )
                ? this.component.addPatrulToPolygon( scheduleForPolygonPatrul )
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }
}
