package com.ssd.mvd.task.card;

import com.ssd.mvd.constants.TaskTypes;
import java.util.Date;
import java.util.List;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public final class TaskTimingRequest {
    private List< TaskTypes > taskType;
    private Date startDate;
    private Date endDate;
}
