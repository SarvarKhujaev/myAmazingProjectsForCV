package com.ssd.mvd.controllerForFindFace.modelForPassport;

@lombok.Data
public class RequestGuid {
}
