package com.ssd.mvd.controllerForFindFace.modelForAddress;

@lombok.Data
public class ModelForAddress {
    private Integer AnswereId;
    private String AnswereMessage;
    private String AnswereComment;
    private com.ssd.mvd.controllerForFindFace.modelForAddress.Data Data;
}
