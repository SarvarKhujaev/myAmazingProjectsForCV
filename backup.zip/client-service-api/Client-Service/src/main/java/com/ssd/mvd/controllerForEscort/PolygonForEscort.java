package com.ssd.mvd.controllerForEscort;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.ssd.mvd.entity.PolygonEntity;

import java.util.List;
import java.util.UUID;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class PolygonForEscort {
    private UUID uuid = UUID.randomUUID();
    private String name;
    private UUID uuidOfEscort;

    private Integer totalTime;
    private Integer routeIndex;
    private Integer totalDistance;

    @JsonDeserialize
    private List< Points > pointsList;
    @JsonDeserialize
    private List< PolygonEntity > latlngs;
}
