package com.ssd.mvd.token;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class PatrulLoginRequest {
    private String simCardNumber;
    private String password;
    private String login;
}
