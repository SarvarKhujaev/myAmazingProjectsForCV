package com.ssd.mvd.task.selfEmploymentTask;

import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import com.fasterxml.jackson.core.type.TypeReference;
import org.springframework.web.bind.annotation.*;

import com.ssd.mvd.components.PatrulComponent;
import com.ssd.mvd.configs.RSocketPingService;
import com.ssd.mvd.entity.ApiResponseModel;
import com.ssd.mvd.inspectors.LogInspector;
import com.ssd.mvd.entity.ReportForCard;
import com.ssd.mvd.entity.Patrul;
import com.ssd.mvd.entity.Status;

import reactor.core.publisher.Mono;
import java.util.Objects;

@CrossOrigin
@RestController
@lombok.RequiredArgsConstructor
@RequestMapping ( value = "/clientService/api/v1/selfEmploymentController" )
public class SelfEmploymentController extends LogInspector {
    private final PatrulComponent patrulComponent;

    @GetMapping ( value = "/{uuid}" )
    public Mono< ? > getSelfEmployment ( @PathVariable ( value = "uuid" ) final String uuid ) {
        try { return RSocketPingService
                    .getInstance()
                    .getFlag()
                    ? super.checkUUID.test( uuid )
                    ? this.patrulComponent.getSelfEmploymentTask( uuid )
                    : super.getGet201Error().get()
                    : super.getGet401Error().get(); }
        catch ( final Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @PostMapping ( value = "/addReport" ) // for android
    public Mono< ? > addReportForSelfEmployment ( @RequestBody final ReportForCard reportForCard ) {
        if ( !RSocketPingService
                .getInstance()
                .getFlag() ) return super.getGet503Error().get() ;
        final String token = ( (ServletRequestAttributes) Objects.requireNonNull(
                RequestContextHolder.getRequestAttributes() ) )
                .getRequest()
                .getHeader( "Authorization" )
                .split( " " )[1];
        return this.patrulComponent
            .checkToken( token )
            .flatMap( apiResponseModel -> {
                if ( apiResponseModel.getStatus().getCode() == 200
                        && super.checkToken( token, apiResponseModel ) ) {
                    final Patrul patrul = super.objectMapper.convertValue(
                            apiResponseModel.getData().getData(), new TypeReference<>() {} );
                    reportForCard.setUuidOfPatrul( patrul.getUuid() );
                    reportForCard.setPassportSeries( patrul.getPassportNumber() );
                    return this.patrulComponent.addReportForSelfEmployment( reportForCard ); }
                else return super.convert( apiResponseModel ); } ); }

    @PostMapping ( value = "/addSelfEmployment" ) // for android
    public Mono< ? > addSelfEmployment ( @RequestBody final SelfEmploymentTask selfEmploymentTask ) {
        if ( !RSocketPingService
                .getInstance()
                .getFlag() ) return super.getGet503Error().get();
        final String token = ( (ServletRequestAttributes) Objects.requireNonNull(
                RequestContextHolder.getRequestAttributes() ) )
                .getRequest()
                .getHeader( "Authorization" )
                .split( " " )[1];
        return this.patrulComponent
            .checkToken( token )
            .flatMap( apiResponseModel -> {
                if ( apiResponseModel.getStatus().getCode() == 200 ) {
                    final Patrul patrul = super.objectMapper.convertValue( apiResponseModel.getData().getData(), new TypeReference<>() {} );
                    if ( patrul.getStatus().equals( com.ssd.mvd.constants.Status.FREE )
                            && patrul.getTaskId().equals( "null" )
                            && super.checkToken( token, apiResponseModel ) ) {
                        selfEmploymentTask.getPatruls().put( patrul.getUuid(), patrul );
                        return this.patrulComponent.addSelfEmployment( selfEmploymentTask ); }
                    else return super.convert( ApiResponseModel
                            .builder()
                            .status( Status
                                    .builder()
                                    .code( 201 )
                                    .message( "Finish your current Task and then u can choose another one" )
                                    .build() )
                            .success( false )
                            .build() );
                    } else return super.convert( apiResponseModel ); } ); }
}
