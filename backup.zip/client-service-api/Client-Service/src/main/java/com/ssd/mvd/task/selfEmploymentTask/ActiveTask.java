package com.ssd.mvd.task.selfEmploymentTask;

import com.ssd.mvd.constants.Status;
import com.ssd.mvd.entity.Patrul;

import java.util.Date;
import java.util.UUID;
import java.util.Map;

@lombok.Data
public class ActiveTask {
    private Double latitude;
    private Double longitude;

    private Integer region;
    private Integer district;
    private Integer countryside;

    private String type;
    private String title;
    private String cardId; // id from Asomiddin
    private String taskId; // from service itself
    private String address;
    private String description;

    private Date createdDate;

    private Status status;
    private Status patrulStatus;

    private Map< UUID, Patrul > patrulList;
}
