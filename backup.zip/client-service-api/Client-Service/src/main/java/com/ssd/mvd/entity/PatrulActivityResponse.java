package com.ssd.mvd.entity;

import java.util.List;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public final class PatrulActivityResponse {
    private Long count; // общее количество патрульных
    private List< PatrulDivisionByRegions> regions;
}
