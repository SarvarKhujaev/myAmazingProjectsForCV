package com.ssd.mvd.configs;

import org.springframework.messaging.rsocket.RSocketRequester;
import com.ssd.mvd.ClientServiceApplication;
import org.springframework.http.MediaType;

import java.util.concurrent.TimeUnit;
import java.time.Duration;
import java.util.Objects;

import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;

@lombok.Data
public class RSocketPingService implements Runnable {
    private Boolean flag;
    private Thread thread;
    private final String basePath;
    private RSocketRequester rSocketRequester;
    private final Mono< RSocketRequester > requesterMono;
    private static RSocketPingService rSocketPingService = new RSocketPingService();

    public static RSocketPingService getInstance () { return rSocketPingService != null ? rSocketPingService : ( rSocketPingService = new RSocketPingService() ); }

    private RSocketPingService () {
        this.basePath = ClientServiceApplication
                .context
                .getEnvironment()
                .getProperty( "variables.AUTHORIZATION_API" );
        ( this.requesterMono = ClientServiceApplication
                .context
                .getBean( RSocketRequester.Builder.class )
                .rsocketConnector( connector -> connector
                        .reconnect( Retry.backoff( 1000, Duration.ofSeconds( 5 ) ) ) )
                .dataMimeType( MediaType.APPLICATION_CBOR )
                .connectTcp( Objects.requireNonNull(
                                ClientServiceApplication
                                        .context
                                        .getEnvironment()
                                        .getProperty( "variables.LOAD_BALANCER" ) ),

                        Integer.parseInt ( Objects.requireNonNull (
                                ClientServiceApplication
                                        .context
                                        .getEnvironment()
                                        .getProperty("variables.PRODUCER_PORT" ) ) ) ) )
                .subscribe( this::setRSocketRequester );
        this.setThread( new Thread( this, "pingService" ) );
        this.getThread().start(); }

    @Override
    public void run () {
        while ( this.getThread().isAlive() ) {
            this.setFlag( false );
            this.getRequesterMono()
                    .flatMap( rSocketRequester -> rSocketRequester
                            .route( "ping" )
                            .retrieveMono( Boolean.class )
                            .defaultIfEmpty( false )
                            .onErrorReturn( false ) )
                    .subscribe( this::setFlag );
            try { TimeUnit.SECONDS.sleep( 1 ); }
            catch ( Exception e ) {
                this.setFlag( false );
                this.getThread().stop();
                rSocketPingService = null;
                this.getRSocketRequester().dispose();
                RSocketPingService.getInstance(); } } }
}