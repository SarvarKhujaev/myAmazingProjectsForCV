package com.ssd.mvd.components;

import org.springframework.messaging.rsocket.RSocketRequester;
import org.springframework.web.bind.annotation.RestController;

import com.ssd.mvd.entity.ScheduleForPolygonPatrul;
import com.ssd.mvd.inspectors.LogInspector;
import com.ssd.mvd.entity.ApiResponseModel;
import com.ssd.mvd.entity.Polygon;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import java.util.List;

@RestController
@lombok.RequiredArgsConstructor
public class PolygonForPatrulComponent extends LogInspector {
    private final RSocketRequester requester;

    public Flux< Polygon > listOfPoligonsForPatrul () { return this.requester
            .route( "listOfPoligonsForPatrul" )
            .retrieveFlux( Polygon.class )
            .onErrorContinue( super::logging ); }

    public Mono< List > getPatrulsForPolygon ( String uuid ) { return this.requester
            .route( "getPatrulsForPolygon" )
            .data( uuid )
            .retrieveMono( List.class )
            .onErrorContinue( super::logging ); }

    public Mono< ApiResponseModel > delete ( String polygonName ) { return this.requester
            .route( "deletePolygonForPatrul" )
            .data( polygonName )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< ApiResponseModel > addPolygon ( Polygon polygon ) { return this.requester
            .route( "addPolygonForPatrul" )
            .data( polygon )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< ApiResponseModel > updatePolygonForPatrul ( Polygon polygon ) { return this.requester
            .route( "updatePolygonForPatrul" )
            .data( polygon )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< ApiResponseModel > addPatrulToPolygon ( ScheduleForPolygonPatrul scheduleForPolygonPatrul ) { return this.requester
            .route( "addPatrulToPolygon" )
            .data( scheduleForPolygonPatrul )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }
}
