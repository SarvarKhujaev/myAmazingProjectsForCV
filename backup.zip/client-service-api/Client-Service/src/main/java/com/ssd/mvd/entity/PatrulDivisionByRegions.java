package com.ssd.mvd.entity;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public final class PatrulDivisionByRegions {
    private Long activePatruls;
    private Long nonActivePatruls;
    private Long neverAuthorizedPatruls;

    private Long regionId;
    private String regionName;
}
