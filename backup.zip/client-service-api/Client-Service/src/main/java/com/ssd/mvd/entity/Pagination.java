package com.ssd.mvd.entity;

import com.ssd.mvd.constants.TaskTypes;
import com.ssd.mvd.constants.Status;

import java.time.Duration;
import java.time.Instant;
import java.util.*;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public final class Pagination {
    private Long count;
    private List< ? > patrulList;
    private List< FilteredPatrul > activePatrulList; // список всех авторизованных патрульных
    private Map< Status, List< FilteredPatrul > > ObjectData;

    public Pagination ( final List< Patrul > patrulList ) {
        this.setActivePatrulList( new ArrayList<>() );
        this.setCount( (long) ( this.patrulList = patrulList ).size() );
        patrulList
                .parallelStream()
                .filter( patrul -> patrul.getTokenForLogin() != null
                        && !patrul.getTokenForLogin().equals( "null" ) )
                .map( FilteredPatrul::new )
                .forEach( this.activePatrulList::add ); }

    public Pagination ( final List< Patrul > patrulList, final Integer count ) {
        this.setCount( (long) count );
        this.setObjectData( new HashMap<>() );
        this.setActivePatrulList( new ArrayList<>() );
        this.getObjectData().put( Status.FREE, new ArrayList<>() );
        this.getObjectData().put( Status.BUSY, new ArrayList<>() );
        this.getObjectData().put( Status.IN_GARAGE, new ArrayList<>() );
        this.getObjectData().put( Status.NOT_AVAILABLE, new ArrayList<>() );
        patrulList
                .stream()
                .filter( patrul -> patrul.getTokenForLogin() != null
                        && !patrul.getTokenForLogin().equals( "null" ) )
                .map( FilteredPatrul::new )
                .forEach( this.activePatrulList::add );
        patrulList.forEach( patrul -> {
            if ( Math.abs( Duration.between( Instant.now(), patrul.getLastActiveDate().toInstant() )
                    .toHours() ) >= 24 ) this.getObjectData()
                    .get( Status.NOT_AVAILABLE )
                    .add( new FilteredPatrul( patrul ) );
            else if ( patrul.getTaskTypes().compareTo( TaskTypes.ESCORT ) != 0 )
                switch ( patrul.getStatus() ) {
                    case FREE -> this.getObjectData()
                                .get( Status.FREE )
                                .add( new FilteredPatrul( patrul ) );
                    case IN_GARAGE -> this.getObjectData()
                            .get( Status.IN_GARAGE )
                            .add( new FilteredPatrul( patrul ) );
                    case NOT_AVAILABLE -> this.getObjectData()
                            .get( Status.NOT_AVAILABLE )
                            .add( new FilteredPatrul( patrul ) );
                    case ARRIVED, ACCEPTED, ATTACHED -> this.getObjectData()
                            .get( Status.BUSY )
                            .add( new FilteredPatrul( patrul ) ); } } ); }

    public Pagination ( final List< ? > patruls, final Long size, final Long page ) {
        if ( size * page < patruls.size() ) this.setPatrulList(
                patruls.subList( (int) ( page * size ),
                        (int) ( page * size + size < patruls.size()
                                ? page * size + size
                                : patruls.size() ) ) );
        this.setCount( (long) patruls.size() ); }
}