package com.ssd.mvd.controllerForFindFace.modelForPassport;

@lombok.Data
public class ModelForPassport {
    private com.ssd.mvd.controllerForFindFace.modelForPassport.Data Data;
}
