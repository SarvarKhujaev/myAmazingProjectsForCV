package com.ssd.mvd.entity;

import java.util.Date;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class PatrulActivityRequest {
    private String patrulUUID;
    private Date startDate;
    private Date endDate;
}
