package com.ssd.mvd.entity;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class CameraList {
    private String rtspLink;
    private String cameraName;
}
