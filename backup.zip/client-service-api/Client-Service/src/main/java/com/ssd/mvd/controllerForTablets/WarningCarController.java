package com.ssd.mvd.controllerForTablets;

import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.bind.annotation.*;

import com.ssd.mvd.controllerForFindFace.CarTotalData;
import com.ssd.mvd.components.WarningCarComponent;
import com.ssd.mvd.configs.RSocketPingService;
import com.ssd.mvd.components.PatrulComponent;
import com.ssd.mvd.inspectors.LogInspector;
import com.ssd.mvd.entity.ApiResponseModel;
import com.ssd.mvd.entity.Status;
import com.ssd.mvd.entity.Data;

import reactor.core.publisher.Mono;
import java.util.Objects;

@CrossOrigin
@RestController
@lombok.RequiredArgsConstructor
@RequestMapping( value = "/clientService/api/v1/warningCar" )
public class WarningCarController extends LogInspector {
    private final WarningCarComponent component;
    private final PatrulComponent patrulComponent;

    @GetMapping ( value = "/" )
    public Mono< ? > getAllCarTotalData (
            @RequestParam( value = "page", defaultValue = "0" ) final Long page,
            @RequestParam( value = "size", defaultValue = "20" ) final Long size ) {
        try { final String token = ( (ServletRequestAttributes) Objects.requireNonNull(
                RequestContextHolder.getRequestAttributes() ) )
                .getRequest()
                .getHeader( "Authorization" )
                .split( " " )[1];
            return RSocketPingService
                    .getInstance()
                    .getFlag()
                    ? this.patrulComponent
                    .checkToken( token )
                    .flatMap( apiResponseModel -> super.checkToken( token, apiResponseModel )
                        ? this.component.getAllCarTotalData()
                        .skip( page * size )
                        .take( size )
                        .collectList()
                        .flatMap( carTotalData1 -> super.convert(
                                ApiResponseModel
                                        .builder()
                                        .data( Data
                                                .builder()
                                                .data( carTotalData1 )
                                                .build() )
                                        .status( Status
                                                .builder()
                                                .message( "CarTotalDataList" )
                                                .code( 200 )
                                                .build() )
                                        .build() ) )
                            : super.getGet401Error().get() )
                    : super.getGet503Error().get();
        } catch ( Exception e ) {
            super.logging( e );
            return super.getGet503Error().get(); } }

    @PostMapping ( value = "/addNewWarningCar" )
    public Mono< ? > addNewWarningCar ( @RequestBody final CarTotalData carTotalData ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                ( (ServletRequestAttributes) Objects
                        .requireNonNull( RequestContextHolder
                                .getRequestAttributes() ) )
                        .getRequest()
                        .getHeader( "Authorization" ) )
                ? this.component.addNewWarningCar( carTotalData )
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @GetMapping ( value = "/getWarningCarDetails/{gosnumber}" )
    public Mono< ? > getWarningCarDetails ( @PathVariable( value = "gosnumber" ) final String gosnumber ) {
        try { final String token = ( (ServletRequestAttributes) Objects.requireNonNull(
                RequestContextHolder.getRequestAttributes() ) )
                .getRequest()
                .getHeader( "Authorization" )
                .split( " " )[1];
            return RSocketPingService
                    .getInstance()
                    .getFlag()
                    ? this.patrulComponent
                    .checkToken( token )
                    .flatMap( apiResponseModel -> super.checkToken( token, apiResponseModel )
                            ? this.component.getWarningCarDetails( gosnumber )
                            : super.getGet401Error().get() )
                    : super.getGet503Error().get();
        } catch ( Exception e ) {
            super.logging( e );
            return super.getGet503Error().get(); } }

    @GetMapping ( value = "/getViolationsInformationsList/{gosnumber}" )
    public Mono< ? > getViolationsInformationsList ( @PathVariable( value = "gosnumber" ) final String gosnumber ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                ( (ServletRequestAttributes) Objects
                        .requireNonNull( RequestContextHolder
                                .getRequestAttributes() ) )
                        .getRequest()
                        .getHeader( "Authorization" ) )
                ? this.component.getViolationsInformationsList( gosnumber )
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }
}
