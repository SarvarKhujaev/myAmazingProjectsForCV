package com.ssd.mvd.controllerForEscort;

import java.util.Objects;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import com.ssd.mvd.inspectors.LogInspector;
import com.ssd.mvd.configs.RSocketPingService;
import com.ssd.mvd.components.PolygonForEscortComponent;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

@CrossOrigin
@RestController
@lombok.RequiredArgsConstructor
@RequestMapping( value = "/clientService/api/v1/polygonForEscort" )
public class PolygonForEscortController extends LogInspector {
    private final PolygonForEscortComponent component;

    @PostMapping ( value = "/add" )
    public Mono< ? > addNewPolygonForEscort ( @RequestBody final PolygonForEscort polygonForEscort ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                            .requireNonNull( RequestContextHolder
                                    .getRequestAttributes() ) )
                            .getRequest()
                            .getHeader( "Authorization" ) )
                ? this.component.addNewPolygonForEscort( polygonForEscort )
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @GetMapping ( value = "/{uuid}" )
    public Mono< ? > getAllPolygonForEscort ( @PathVariable ( value = "uuid" ) final String uuid ) {
        try { return super.checkUUID.test( uuid )
                ? RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                            .requireNonNull( RequestContextHolder
                                    .getRequestAttributes() ) )
                            .getRequest()
                            .getHeader( "Authorization" ) )
                ? this.component.getCurrentPolygonForEscort( uuid )
                : super.getGet401Error().get()
                : super.getGet503Error().get()
                : super.getGet201Error().get();
        } catch ( Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @DeleteMapping ( value = "/delete/{uuid}" )
    public Mono< ? > delete ( @PathVariable ( value = "uuid" ) final String uuid ) {
        try { return super.checkUUID.test( uuid )
                ? RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                            .requireNonNull( RequestContextHolder
                                    .getRequestAttributes() ) )
                            .getRequest()
                            .getHeader( "Authorization" ) )
                ? this.component.delete( uuid )
                : super.getGet401Error().get()
                : super.getGet503Error().get()
                : super.getGet201Error().get();
        } catch ( Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @PutMapping ( value = "/update" )
    public Mono< ? > update ( @RequestBody final PolygonForEscort polygon ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                            .requireNonNull( RequestContextHolder
                                    .getRequestAttributes() ) )
                            .getRequest()
                            .getHeader( "Authorization" ) )
                ? this.component.update( polygon )
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @GetMapping ( value = "/" )
    public Flux< ? > getAllPolygonForEscort () {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                ( (ServletRequestAttributes) Objects
                        .requireNonNull( RequestContextHolder
                                .getRequestAttributes() ) )
                        .getRequest()
                        .getHeader( "Authorization" ) )
                ? this.component.getAllPolygonForEscort()
                : Flux.just( super.getGet401Error().get() )
                : Flux.just( super.getGet503Error().get() );
        } catch ( Exception e ) {
            super.logging( e );
            return Flux.just( super.getGet401Error().get() ); } }
}
