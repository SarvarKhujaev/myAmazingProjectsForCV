package com.ssd.mvd.entity;

import java.util.List;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
// используется когда нужно найти патрульных рядом с камерой
// максимум 5 не занятых патрульных
// SAM - 1011
public final class PatrulInRadiusList {
    private Double maxDistance;
    private List< Patrul > freePatrulList; // максимум 5 не занятых патрульных

    private List < Patrul > busyPatrulListInRadius;
    private List < Patrul > busyPatrulListOutOfRadius;

    private List < Patrul > freePatrulListOutOfRadius; // список патрульных которые не входят в радиус
}
