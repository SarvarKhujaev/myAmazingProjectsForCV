package com.ssd.mvd.components;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import com.ssd.mvd.entity.SosRequest;
import com.ssd.mvd.task.card.PatrulSos;
import com.ssd.mvd.entity.ApiResponseModel;
import com.ssd.mvd.inspectors.LogInspector;

import org.springframework.stereotype.Component;
import org.springframework.messaging.rsocket.RSocketRequester;

@Component
@lombok.RequiredArgsConstructor
public class SosComponent extends LogInspector {
    private final RSocketRequester requester;

    public Flux< PatrulSos > getAllSosEntities () { return requester
            .route( "getAllSosEntities" )
            .retrieveFlux( PatrulSos.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( new PatrulSos() ); }

    public Mono< ApiResponseModel > checkSosStatus ( String token ) { return requester
            .route( "checkSosStatus" )
            .data( token )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< ApiResponseModel > getAllSosForCurrentPatrul ( String token ) { return requester
            .route( "getAllSosForCurrentPatrul" )
            .data( token )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< ApiResponseModel > saveSosFromPatrul ( PatrulSos patrulSos ) { return requester
            .route( "saveSosFromPatrul" )
            .data( patrulSos )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< ApiResponseModel > updatePatrulStatusInSosTable ( SosRequest sosRequest ) {
        return requester
            .route( "updatePatrulStatusInSosTable" )
            .data( sosRequest )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }
}
