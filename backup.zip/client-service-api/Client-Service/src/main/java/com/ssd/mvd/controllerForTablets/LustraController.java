package com.ssd.mvd.controllerForTablets;

import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.bind.annotation.*;

import com.ssd.mvd.configs.RSocketPingService;
import com.ssd.mvd.components.AtlasComponent;
import com.ssd.mvd.inspectors.LogInspector;
import com.ssd.mvd.entity.AtlasLustra;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Objects;
import java.util.Map;

@CrossOrigin
@RestController
@lombok.RequiredArgsConstructor
@RequestMapping( value = "/clientService/api/v1/lustra" )
public class LustraController extends LogInspector {
    private final AtlasComponent atlasComponent;

    @GetMapping ( value = "/list" )
    public Flux< ? > getList () {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test( ( (ServletRequestAttributes) Objects
                            .requireNonNull( RequestContextHolder
                                    .getRequestAttributes() ) )
                            .getRequest()
                            .getHeader( "Authorization" ) )
                ? this.atlasComponent.getAllLustra()
                : Flux.just( super.getGet401Error().get() )
                : Flux.just( super.getGet503Error().get() );
        } catch ( Exception e ) { 
            super.logging( e );
            return Flux.just( super.getGet401Error().get() ); } }

    @PostMapping ( value = "/add" )
    public Mono< ? > addLustra ( @RequestBody final AtlasLustra atlasLustra ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test( ( (ServletRequestAttributes) Objects
                            .requireNonNull( RequestContextHolder
                                    .getRequestAttributes() ) )
                            .getRequest()
                            .getHeader( "Authorization" ) )
                ? this.atlasComponent.add( atlasLustra )
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( Exception e ) { 
            super.logging( e );
            return super.getGet401Error().get(); } }

    @GetMapping( value = "/filter" )
    public Flux< ? > filter ( @RequestParam final Map< String, String > params ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test( ( (ServletRequestAttributes) Objects
                            .requireNonNull( RequestContextHolder
                                    .getRequestAttributes() ) )
                            .getRequest()
                            .getHeader( "Authorization" ) )
                ? this.atlasComponent.searchByName( params.get( "name" ) )
                : Flux.just( super.getGet401Error().get() )
                : Flux.just( super.getGet503Error().get() );
        } catch ( Exception e ) { 
            super.logging( e );
            return Flux.just( super.getGet401Error().get() ); } }

    @PutMapping ( value = "/update" )
    public Mono< ? > updateLustra ( @RequestBody final AtlasLustra atlasLustra ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                            .requireNonNull( RequestContextHolder
                                    .getRequestAttributes() ) )
                            .getRequest()
                            .getHeader( "Authorization" ) )
                ? this.atlasComponent.updateLustra( atlasLustra )
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( Exception e ) { 
            super.logging( e );
            return super.getGet401Error().get(); } }

    @DeleteMapping ( value = "/delete/{gosno}" )
    public Mono< ? > delete ( @PathVariable ( value = "gosno" ) final String gosno ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkUUID.test( gosno )
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                                .requireNonNull( RequestContextHolder
                                        .getRequestAttributes() ) )
                                .getRequest()
                                .getHeader( "Authorization" ) )
                ? this.atlasComponent.delete( gosno )
                : super.getGet401Error().get()
                : super.getGet201Error().get()
                : super.getGet503Error().get();
        } catch ( Exception e ) { 
            super.logging( e );
            return super.getGet401Error().get(); } }
}
