package com.ssd.mvd.controllerForEscort;

import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.bind.annotation.*;

import com.ssd.mvd.components.EscortComponent;
import com.ssd.mvd.configs.RSocketPingService;
import com.ssd.mvd.inspectors.LogInspector;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import java.util.Objects;

@CrossOrigin
@RestController
@lombok.RequiredArgsConstructor
@RequestMapping( value = "/clientService/api/v1/escort" )
public class EscortController extends LogInspector {
    private final EscortComponent component;

    @GetMapping ( value = "/" )
    public Flux< ? > getAllEscort () {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                            .requireNonNull( RequestContextHolder
                                    .getRequestAttributes() ) )
                            .getRequest()
                            .getHeader( "Authorization" ) )
                ? this.component.getAllEscort()
                : Flux.just( super.getGet401Error().get() )
                : Flux.just( super.getGet503Error().get() );
        } catch ( Exception e ) {
            super.logging( e );
            return Flux.just( super.getGet401Error().get() ); } }

    @PostMapping ( value = "/add" )
    public Flux< ? > addNewEscort ( @RequestBody EscortTuple escortTuple ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                            .requireNonNull( RequestContextHolder
                                    .getRequestAttributes() ) )
                            .getRequest()
                            .getHeader( "Authorization" ) )
                ? this.component.addNewEscort( escortTuple )
                : Flux.just( super.getGet401Error().get() )
                : Flux.just( super.getGet503Error().get() );
        } catch ( Exception e ) {
            super.logging( e );
            return Flux.just( super.getGet401Error().get() ); } }

    @PutMapping ( value = "/update" )
    public Mono< ? > updateEscort ( @RequestBody EscortTuple escortTuple ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                            .requireNonNull( RequestContextHolder
                                    .getRequestAttributes() ) )
                            .getRequest()
                            .getHeader( "Authorization" ) )
                ? this.component.updateEscort( escortTuple )
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @DeleteMapping ( value = "/delete/{uuid}" )
    public Mono< ? > deleteEscort ( @PathVariable ( value = "uuid" ) String uuid ) {
        try { return super.checkUUID.test( uuid )
                ? RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                            .requireNonNull( RequestContextHolder
                                    .getRequestAttributes() ) )
                            .getRequest()
                            .getHeader( "Authorization" ) )
                ? this.component.deleteEscort( uuid )
                : super.getGet401Error().get()
                : super.getGet503Error().get()
                : super.getGet201Error().get();
        } catch ( Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @GetMapping ( value = "/{uuid}" )
    public Mono< ? > getCurrentEscort ( @PathVariable ( value = "uuid" ) String uuid ) {
        try { return super.checkUUID.test( uuid )
                ? RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                ( (ServletRequestAttributes) Objects
                        .requireNonNull( RequestContextHolder
                                .getRequestAttributes() ) )
                        .getRequest()
                        .getHeader( "Authorization" ) )
                ? this.component.getCurrentEscort( uuid )
                : super.getGet401Error().get()
                : super.getGet503Error().get()
                : super.getGet201Error().get();
        } catch ( Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @GetMapping ( value = "/getTupleTotalData/{uuid}" )
    public Mono< ? > getTupleTotalData ( @PathVariable ( value = "uuid" ) String uuid ) {
        try { return super.checkUUID.test( uuid )
                ? RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                            .requireNonNull( RequestContextHolder
                                    .getRequestAttributes() ) )
                            .getRequest()
                            .getHeader( "Authorization" ) )
                ? this.component.getTupleTotalData( uuid )
                : super.getGet401Error().get()
                : super.getGet503Error().get()
                : super.getGet201Error().get();
        } catch ( Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }

    @GetMapping ( value = "/removeEscortCarFromEscort/{uuid}" )
    public Mono< ? > removeEscortCarFromEscort ( @PathVariable ( value = "uuid" ) String uuid ) {
        try { return super.checkUUID.test( uuid )
                ? RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                            .requireNonNull( RequestContextHolder
                                    .getRequestAttributes() ) )
                            .getRequest()
                            .getHeader( "Authorization" ) )
                ? this.component.removeEscortCarFromEscort( uuid )
                : super.getGet401Error().get()
                : super.getGet503Error().get()
                : super.getGet201Error().get();
        } catch ( Exception e ) {
            super.logging( e );
            return super.getGet401Error().get(); } }
}
