package com.ssd.mvd.entity;

import java.util.UUID;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class ReqCar {
    private UUID uuid = UUID.randomUUID();
    private UUID lustraId;

    private String gosNumber;
    private String trackerId;
    private String vehicleType;
    private String carImageLink;
    private String patrulPassportSeries;

    private Integer sideNumber; // бортовой номер
    private Integer simCardNumber;

    private Double latitude;
    private Double longitude;
    private Double averageFuelSize; // средний расход топлива по документам
    private Double averageFuelConsumption; // средний расход топлива исходя из стиля вождения водителя
}