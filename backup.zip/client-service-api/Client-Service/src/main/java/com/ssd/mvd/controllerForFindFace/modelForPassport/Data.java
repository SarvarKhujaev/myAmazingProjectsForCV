package com.ssd.mvd.controllerForFindFace.modelForPassport;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class Data {
    @JsonDeserialize
    private Person Person;
    @JsonDeserialize
    private Document Document;
    private RequestGuid RequestGuid;
}
