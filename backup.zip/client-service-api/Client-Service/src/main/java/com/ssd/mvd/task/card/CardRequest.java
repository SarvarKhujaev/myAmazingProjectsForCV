package com.ssd.mvd.task.card;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.ssd.mvd.constants.TaskTypes;

import java.util.List;
import java.util.UUID;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class CardRequest< T > {
    private TaskTypes taskType;
    @JsonDeserialize
    private T card;
    @JsonDeserialize
    private List< UUID > patruls;
}
