package com.ssd.mvd.components;

import org.springframework.messaging.rsocket.RSocketRequester;
import org.springframework.stereotype.Component;

import com.ssd.mvd.inspectors.LogInspector;
import com.ssd.mvd.entity.ApiResponseModel;
import com.ssd.mvd.entity.Polygon;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Component
@lombok.RequiredArgsConstructor
public class PolygonComponent extends LogInspector {
    private final RSocketRequester requester;

    public Flux< Polygon > getPolygonList () { return this.requester
            .route( "getPolygonList" )
            .retrieveFlux( Polygon.class )
            .onErrorContinue( super::logging ); }

    public Mono< ApiResponseModel > addNewPolygon ( Polygon polygon ) { return this.requester
            .route( "addNewPolygon" )
            .data( polygon )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< ApiResponseModel > updatePolygon ( Polygon polygon ) { return this.requester
            .route( "updatePolygon" )
            .data( polygon )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< ApiResponseModel > deletePolygon ( String polygonName ) { return this.requester
            .route( "deletePolygon" )
            .data( polygonName )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }
}
