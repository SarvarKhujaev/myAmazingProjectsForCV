package com.ssd.mvd.entity;

import com.ssd.mvd.controllerForEscort.PolygonForEscort;
import com.ssd.mvd.controllerForEscort.TupleOfCar;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import java.util.List;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public final class TupleTotalData { // contains the total data about Escort
    @JsonDeserialize
    private PolygonForEscort polygonForEscort;
    @JsonDeserialize
    private List< TupleOfCar > tupleOfCarList;
    @JsonDeserialize
    private List< Patrul > patrulList;
}
