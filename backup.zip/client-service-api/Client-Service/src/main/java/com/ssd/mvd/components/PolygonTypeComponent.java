package com.ssd.mvd.components;

import org.springframework.messaging.rsocket.RSocketRequester;
import org.springframework.stereotype.Component;

import com.ssd.mvd.inspectors.LogInspector;
import com.ssd.mvd.entity.ApiResponseModel;
import com.ssd.mvd.entity.PolygonType;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import java.util.UUID;

@Component
@lombok.RequiredArgsConstructor
public class PolygonTypeComponent extends LogInspector {
    private final RSocketRequester requester;

    public Mono< ApiResponseModel > updatePolygonType ( PolygonType polygonType ) { return this.requester
            .route( "updatePolygonType" )
            .data( polygonType )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< ApiResponseModel > addPolygonType ( PolygonType polygonType ) { return this.requester
            .route( "addPolygonType" )
            .data( polygonType )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< ApiResponseModel > deletePolygonType ( UUID uuid ) { return this.requester
            .route( "deletePolygonType" )
            .data( uuid )
            .retrieveMono( ApiResponseModel.class )
            .onErrorContinue( super::logging )
            .onErrorReturn( super.getGetErrorResponse().get() ); }

    public Mono< PolygonType > getCurrentPolygonType ( UUID uuid ) { return this.requester
            .route( "getCurrentPolygonType" )
            .data( uuid )
            .retrieveMono( PolygonType.class )
            .onErrorContinue( super::logging ); }

    public Flux< PolygonType > getAllPolygonTypes () { return this.requester
            .route( "getAllPolygonTypes" )
            .retrieveFlux( PolygonType.class )
            .onErrorContinue( super::logging ); }
}
