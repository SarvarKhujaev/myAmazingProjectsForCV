package com.ssd.mvd.task.card;

import com.ssd.mvd.constants.TaskTypes;
import com.ssd.mvd.constants.Status;

import java.util.Date;
import java.util.List;
import java.util.UUID;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class TaskTimingStatistics { // показывает все таски со временем их выполнения и деталями
    private String carType; // модель машины
    private String organName;
    private String carNumber;
    private String fatherName;
    private String policeType; // choosing from dictionary
    private String phoneNumber;
    private String dateOfBirth;
    private String taskIdOfPatrul;
    private String passportNumber;
    private String patrulImageLink;
    private String surnameNameFatherName; // Ф.И.О

    private Double latitude; // the current location of the user
    private Double longitude; // the current location of the user
    private Double latitudeOfTask;
    private Double longitudeOfTask;

    private Status patrulStatus; // статус самого патрульного
    private Date lastActiveDate; // shows when user was online lastly
    private Integer batteryLevel;

    // параметры самого класса
    private Status status; // показывает пришел ли патрульный во время или нет
    private String taskId;
    private Boolean inTime;
    private UUID patrulUUID;
    private Date dateOfComing; // показывает время когда патрульный пришел в точку назначения
    private TaskTypes taskTypes;
    private Long totalTimeConsumption; // общее время которое патрульный потратил чтобы дойти до пункта назначения
    private List< PositionInfo > positionInfoList;
}
