package com.ssd.mvd.controllerForFindFace.modelForPassport;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class Person {
    private Sex Sex;
    private String Pinpp;
    private String pCitizen;
    private String NameLatin;
    private String DateBirth;
    private String BirthPlace;
    private String SurnameLatin;
    private String PatronymLatin;
}
