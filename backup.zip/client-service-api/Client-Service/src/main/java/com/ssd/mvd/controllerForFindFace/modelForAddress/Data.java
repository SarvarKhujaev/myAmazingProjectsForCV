package com.ssd.mvd.controllerForFindFace.modelForAddress;

import com.ssd.mvd.controllerForFindFace.modelForPassport.RequestGuid;

@lombok.Data
public class Data {
    private RequestGuid requestGuid;
    private PermanentRegistration PermanentRegistration;
    private com.ssd.mvd.controllerForFindFace.modelForCadastr.TemproaryRegistration TemproaryRegistration;
}
