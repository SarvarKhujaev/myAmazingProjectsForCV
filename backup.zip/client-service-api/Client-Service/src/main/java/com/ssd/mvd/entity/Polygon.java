package com.ssd.mvd.entity;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.extern.jackson.Jacksonized;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@lombok.Data
@Jacksonized
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class Polygon {
    public UUID uuid;
    public UUID organ;

    public Long regionId;
    public Long mahallaId;
    public Long districtId; // tuman

    public String name;
    public String color;

    private PolygonType polygonType;

    @JsonDeserialize
    public List< UUID > patrulList = new ArrayList<>(); // the list of all Patruls who works at this polygon
    @JsonDeserialize
    public List< PolygonEntity > latlngs;
}
