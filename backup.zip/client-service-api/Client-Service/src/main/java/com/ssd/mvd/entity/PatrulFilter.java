package com.ssd.mvd.entity;

import java.util.List;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public final class PatrulFilter {
    private String param;
    private Long regionId;
    private List< String > policeTypeList;
}
