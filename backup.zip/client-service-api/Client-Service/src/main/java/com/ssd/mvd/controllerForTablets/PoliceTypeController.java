package com.ssd.mvd.controllerForTablets;

import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.bind.annotation.*;

import com.ssd.mvd.components.PoliceTypeComponent;
import com.ssd.mvd.configs.RSocketPingService;
import com.ssd.mvd.inspectors.LogInspector;
import com.ssd.mvd.entity.PoliceType;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import java.util.Objects;

@CrossOrigin
@RestController
@lombok.RequiredArgsConstructor
@RequestMapping ( value = "/clientService/api/v1/policeType" )
public class PoliceTypeController extends LogInspector {
    private final PoliceTypeComponent policeTypeComponent;

    @GetMapping ( value = "/list" )
    public Flux< ? > getPoliceTypeList () {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                        .requireNonNull( RequestContextHolder
                                .getRequestAttributes() ) )
                        .getRequest()
                        .getHeader( "Authorization" ) )
                ? this.policeTypeComponent.getPoliceTypeList()
                : Flux.just( super.getGet401Error().get() )
                : Flux.just( super.getGet503Error().get() );
        } catch ( Exception e ) { 
            super.logging( e );
            return Flux.just( super.getGet401Error().get() ); } }

    @PostMapping( value = "/add" )
    public Mono< ? > addPoliceType ( @RequestBody final PoliceType policeType ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                        .requireNonNull( RequestContextHolder
                                .getRequestAttributes() ) )
                        .getRequest()
                        .getHeader( "Authorization" ) )
                ? this.policeTypeComponent.addPoliceType( policeType )
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( Exception e ) { 
            super.logging( e );
            return super.getGet401Error().get(); } }

    @PutMapping ( value = "/update" )
    public Mono< ? > updatePoliceType ( @RequestBody final PoliceType policeType ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                        .requireNonNull( RequestContextHolder
                                .getRequestAttributes() ) )
                        .getRequest()
                        .getHeader( "Authorization" ) )
                ? this.policeTypeComponent.updatePoliceType( policeType )
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( Exception e ) { 
            super.logging( e );
            return super.getGet401Error().get(); } }

    @PostMapping ( value = "/delete" )
    public Mono< ? > deletePoliceType ( @RequestBody final PoliceType policeType ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkToken.test(
                        ( (ServletRequestAttributes) Objects
                        .requireNonNull( RequestContextHolder
                                .getRequestAttributes() ) )
                        .getRequest()
                        .getHeader( "Authorization" ) )
                ? this.policeTypeComponent.deletePoliceType( policeType )
                : super.getGet401Error().get()
                : super.getGet503Error().get();
        } catch ( Exception e ) { 
            super.logging( e );
            return super.getGet401Error().get(); } }
}
