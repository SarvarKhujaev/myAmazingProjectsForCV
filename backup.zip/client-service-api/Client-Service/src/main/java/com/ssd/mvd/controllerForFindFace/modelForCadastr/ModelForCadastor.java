package com.ssd.mvd.controllerForFindFace.modelForCadastr;

@lombok.Data
public class ModelForCadastor {
    private com.ssd.mvd.controllerForFindFace.modelForCadastr.Data Data;
}
