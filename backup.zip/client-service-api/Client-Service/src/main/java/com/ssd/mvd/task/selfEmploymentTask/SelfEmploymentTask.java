package com.ssd.mvd.task.selfEmploymentTask;

import com.ssd.mvd.entity.ReportForCard;
import com.ssd.mvd.entity.Patrul;
import java.util.*;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class SelfEmploymentTask {
    private Double lanOfPatrul; // in case if the accident is at Patrul place. then lan lat will be the same
    private Double latOfPatrul;
    private Double lanOfAccident;
    private Double latOfAccident;

    private String title; // title of incident
    private String address; // the address of incident
    private String taskStatus; // might be just created, arrived or finished
    private String description; // info about incident

    private UUID uuid;

    private Date arrivedTime; // фиксировванное время когда он прибыл на дело
    private final Date incidentDate = new Date(); // the date when the task was created

    private List< String > images; // coming from Android
    private Map< UUID, Patrul > patruls = new HashMap<>();
    private final List< ReportForCard > reportForCards = new ArrayList<>();
}
