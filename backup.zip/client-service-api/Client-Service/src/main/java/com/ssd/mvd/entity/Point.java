package com.ssd.mvd.entity;

@lombok.Data
public class Point {
    private Double radius;
    private Double latitude;
    private Double longitude;
}
