package com.ssd.mvd.entity;

@lombok.Data
public final class pRegion {
    private Integer Id;
    private String Value;
    private String IdValue;
}
