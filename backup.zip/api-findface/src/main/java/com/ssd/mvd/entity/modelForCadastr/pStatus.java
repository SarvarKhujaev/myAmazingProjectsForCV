package com.ssd.mvd.entity.modelForCadastr;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public final class pStatus {
    private Integer Id;
    private String Value;
    private String IdValue;
}
