package com.ssd.mvd.entity.modelForCadastr;

@lombok.Data
public final class ModelForCadastor {
    private com.ssd.mvd.entity.modelForCadastr.Data Data;
}
