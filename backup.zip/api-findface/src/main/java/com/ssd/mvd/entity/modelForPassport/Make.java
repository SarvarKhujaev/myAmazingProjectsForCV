package com.ssd.mvd.entity.modelForPassport;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public final class Make {
	private String name;
	private Double confidence;
}