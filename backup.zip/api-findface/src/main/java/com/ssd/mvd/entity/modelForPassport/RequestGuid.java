package com.ssd.mvd.entity.modelForPassport;

@lombok.Data
public final class RequestGuid {}
