package com.ssd.mvd.request;

public final class RequestForCadaster {
    private final String Pcadastre;

    public RequestForCadaster ( final String pcadastre ) { this.Pcadastre = pcadastre; }
}
