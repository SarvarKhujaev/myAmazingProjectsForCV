package com.ssd.mvd.entity.modelForCadastr;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public final class Person {
    private String pPsp;
    private String pPerson;
    private pStatus pStatus;
    private String pCitizen;
    private String pDateBirth;
    private String pRegistrationDate;
}
