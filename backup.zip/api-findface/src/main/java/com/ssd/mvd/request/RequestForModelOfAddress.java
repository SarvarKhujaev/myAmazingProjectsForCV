package com.ssd.mvd.request;

public final class RequestForModelOfAddress {
    private final String Pcitizen;

    public RequestForModelOfAddress ( final String pcitizen ) { this.Pcitizen = pcitizen; }
}
