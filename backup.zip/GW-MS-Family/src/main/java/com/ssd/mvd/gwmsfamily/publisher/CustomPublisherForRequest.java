package com.ssd.mvd.gwmsfamily.publisher;

import com.ssd.mvd.gwmsfamily.controller.SerDes;
import com.ssd.mvd.gwmsfamily.inspectors.LogInspector;
import com.ssd.mvd.gwmsfamily.request.RequestForModelOfAddress;
import org.reactivestreams.Subscription;
import org.reactivestreams.Subscriber;
import org.reactivestreams.Publisher;

public final class CustomPublisherForRequest extends LogInspector implements Publisher< String > {
    private final String value;

    public CustomPublisherForRequest ( final String value ) {
        this.value = SerDes
            .getINSTANCE()
            .getGson()
            .toJson( new RequestForModelOfAddress( value ) ); }

    @Override
    public void subscribe( final Subscriber subscriber ) { subscriber.onSubscribe( new Subscription() {
        @Override
        public void request( final long l ) {
            subscriber.onNext( value );
            subscriber.onComplete(); }

        @Override
        public void cancel() { subscriber.onError( new Exception( "Message was not sent!!!" ) ); } } ); }
}
