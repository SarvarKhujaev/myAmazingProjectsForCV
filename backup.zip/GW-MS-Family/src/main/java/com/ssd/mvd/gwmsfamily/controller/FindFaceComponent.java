package com.ssd.mvd.gwmsfamily.controller;

import org.springframework.messaging.rsocket.RSocketRequester;
import java.util.function.BiFunction;
import reactor.core.publisher.Mono;

import com.ssd.mvd.gwmsfamily.GwMsFamilyApplication;
import com.ssd.mvd.gwmsfamily.family.FinalResponse;
import com.ssd.mvd.gwmsfamily.constants.Methods;

public final class FindFaceComponent {
    private final RSocketRequester requester = GwMsFamilyApplication.context.getBean( RSocketRequester.class );
    private static FindFaceComponent component = new FindFaceComponent();

    public static FindFaceComponent getInstance () { return component != null ? component : ( component = new FindFaceComponent() ); }

    // устанавливаем связь с сервисом papilon
    private FindFaceComponent() {}

    public final BiFunction< String, Methods, Mono< FinalResponse > > getFinalResponse = ( pinfl, methods ) ->
            this.requester
            .route( methods.name() )
            .data( pinfl )
            .retrieveMono( FinalResponse.class );
}
