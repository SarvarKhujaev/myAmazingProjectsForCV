package com.ssd.mvd.gwmsfamily.entity;

import com.ssd.mvd.gwmsfamily.entity.modelForAddress.ModelForAddress;
import com.ssd.mvd.gwmsfamily.constants.ErrorResponse;
import reactor.util.function.Tuple2;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public final class PsychologyCard {
    private Pinpp pinpp;
    private String image;
    private ModelForAddress modelForAddress;

    private ErrorResponse errorResponse;

    public PsychologyCard ( final Tuple2<
            Pinpp,
            String > tuple2,
            final ModelForAddress modelForAddress ) {
        this.setModelForAddress( modelForAddress );
        this.setPinpp( tuple2.getT1() );
        this.setImage( tuple2.getT2() ); }
}