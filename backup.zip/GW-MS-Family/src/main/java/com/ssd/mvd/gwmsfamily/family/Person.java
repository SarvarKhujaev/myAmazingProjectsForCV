package com.ssd.mvd.gwmsfamily.family;

import com.ssd.mvd.gwmsfamily.entity.PsychologyCard;

@lombok.Data
public final class Person {
    private String name; // ФИО
    private String photo;
    private String pinfl;
    private String dataOfBirth;

    private Relations sex; // пол человека
    private Address address;
    private Relations relations; // кем он является для тскомого человека ( брат, отец и т.д )

    public Person save ( final PsychologyCard psychologyCard ) {
        this.setAddress( new Address( psychologyCard ) );
        this.setPhoto( psychologyCard.getImage() );
        return this; }
}
