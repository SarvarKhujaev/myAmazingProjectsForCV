package com.ssd.mvd.gwmsfamily.family;

public enum Relations {
    SON,
    WIFE,
    FATHER,
    MOTHER,
    SISTER,
    HUSBAND,
    BROTHER,
    DAUGHTER,

    MALE,
    FEMALE,
}
