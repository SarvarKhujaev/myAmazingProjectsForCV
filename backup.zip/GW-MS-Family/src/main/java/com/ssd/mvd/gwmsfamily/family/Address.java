package com.ssd.mvd.gwmsfamily.family;

import com.ssd.mvd.gwmsfamily.entity.PsychologyCard;
import com.ssd.mvd.gwmsfamily.inspectors.DataValidateInspector;

@lombok.Data
public final class Address {
    private String actualAddress;
    private String registerAddress;

    public Address ( final PsychologyCard psychologyCard ) {
        if ( DataValidateInspector
                .getInstance()
                .checkData
                .test( 0, psychologyCard ) ) {
            this.setActualAddress( psychologyCard
                    .getModelForAddress()
                    .getPermanentRegistration()
                    .getPAddress() );
            this.setRegisterAddress( psychologyCard
                    .getModelForAddress()
                    .getPermanentRegistration()
                    .getPRegistrationDate() ); } }
}
