package com.ssd.mvd.gwmsfamily;

import com.ssd.mvd.gwmsfamily.controller.SerDes;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GwMsFamilyApplication {
    public static ApplicationContext context;

    public static void main( String[] args ) {
        context = SpringApplication.run( GwMsFamilyApplication.class, args );
        SerDes.getINSTANCE(); }

}
