package com.ssd.mvd.gwmsfamily.request;

@lombok.Data
public final class RequestForModelOfAddress {
    private final String Pcitizen;

    public RequestForModelOfAddress ( final String pcitizen ) { this.Pcitizen = pcitizen; }
}
