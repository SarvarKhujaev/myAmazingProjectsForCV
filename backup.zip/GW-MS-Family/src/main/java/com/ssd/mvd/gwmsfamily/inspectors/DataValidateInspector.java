package com.ssd.mvd.gwmsfamily.inspectors;

import com.ssd.mvd.gwmsfamily.entity.PsychologyCard;
import reactor.netty.http.client.HttpClientResponse;
import reactor.core.publisher.Mono;
import reactor.netty.ByteBufMono;

import java.util.function.BiPredicate;
import java.util.Optional;
import java.util.List;

public class DataValidateInspector {
    private static final DataValidateInspector INSPECTOR = new DataValidateInspector();

    public static DataValidateInspector getInstance () { return INSPECTOR; }

    protected <T> Mono< T > convert (final T o ) { return Optional.ofNullable( o ).isPresent() ? Mono.just( o ) : Mono.empty(); }

    public final BiPredicate< Integer, Object > checkData = ( integer, o ) -> switch ( integer ) {
        case 1 -> o != null && !( ( List< ? > ) o ).isEmpty();
        case 2 -> o != null && String.valueOf( o ).length() > 10;
        default -> ( (PsychologyCard) o ).getModelForAddress() != null
                && ( (PsychologyCard) o )
                .getModelForAddress()
                .getPermanentRegistration() != null
                && ( (PsychologyCard) o )
                .getModelForAddress()
                .getPermanentRegistration()
                .getPAddress() != null
                && ( (PsychologyCard) o )
                .getModelForAddress()
                .getPermanentRegistration()
                .getPAddress()
                .length() > 1
                && ( (PsychologyCard) o )
                .getModelForAddress()
                .getPermanentRegistration()
                .getPRegistrationDate() != null
                && ( (PsychologyCard) o )
                .getModelForAddress()
                .getPermanentRegistration()
                .getPRegistrationDate()
                .length() > 1; };

    protected final BiPredicate< HttpClientResponse, ByteBufMono > checkResponse =
            ( httpClientResponse, byteBufMono ) -> byteBufMono != null && httpClientResponse.status().code() == 200;
}
