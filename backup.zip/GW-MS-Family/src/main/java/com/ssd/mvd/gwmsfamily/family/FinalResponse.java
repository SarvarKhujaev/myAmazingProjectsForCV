package com.ssd.mvd.gwmsfamily.family;

import java.util.Collections;
import java.util.List;

@lombok.Data
public final class FinalResponse {
    private Integer count;
    private List< Person > persons;

    public FinalResponse () {
        this.setPersons( Collections.emptyList() );
        this.setCount( 0 ); }

    public FinalResponse save ( final List< Person > people ) {
        this.setCount( people.size() );
        this.getPersons().clear();
        this.setPersons( people );
        return this; }
}
