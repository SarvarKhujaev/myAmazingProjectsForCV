package com.ssd.mvd.gwmsfamily.inspectors;

import com.ssd.mvd.gwmsfamily.entity.modelForAddress.ModelForAddress;
import com.ssd.mvd.gwmsfamily.entityForLogging.IntegratedServiceApis;
import com.ssd.mvd.gwmsfamily.entityForLogging.ErrorLog;
import com.ssd.mvd.gwmsfamily.constants.ErrorResponse;
import com.ssd.mvd.gwmsfamily.kafka.KafkaDataControl;
import com.ssd.mvd.gwmsfamily.kafka.Notification;
import com.ssd.mvd.gwmsfamily.controller.SerDes;
import com.ssd.mvd.gwmsfamily.constants.Methods;
import com.ssd.mvd.gwmsfamily.constants.Errors;
import com.ssd.mvd.gwmsfamily.entity.Pinpp;

import java.util.function.BiFunction;
import reactor.core.publisher.Mono;
import java.util.function.Function;
import java.util.Date;

public class ErrorController extends DataValidateInspector {
    private final Notification notification = new Notification();

    private Notification getNotification() { return this.notification; }

    // используется когда внешние сервисы возвращают 500 ошибку
    protected final Function< String, ErrorResponse > getExternalServiceErrorResponse = error -> ErrorResponse
            .builder()
            .message( "Error in external service: " + error )
            .errors( Errors.EXTERNAL_SERVICE_500_ERROR )
            .build();

    // используется когда сам сервис ловит ошибку при выполнении
    protected final Function< Errors, ErrorResponse > getServiceErrorResponse = error -> ErrorResponse
            .builder()
            .message( "Service error: " + error )
            .errors( Errors.SERVICE_WORK_ERROR )
            .build();

    // используется когда сервис возвращает пустое тело при запросе
    protected final Function< String, ErrorResponse > getDataNotFoundErrorResponse = error -> ErrorResponse
            .builder()
            .message( "Data for: " + error + " was not found" )
            .errors( Errors.DATA_NOT_FOUND )
            .build();

    protected final Function< String, ErrorResponse > getConnectionError = error -> ErrorResponse
            .builder()
            .message( "Connection Error: " + error )
            .errors( Errors.RESPONSE_FROM_SERVICE_NOT_RECEIVED )
            .build();

    protected final Function< Methods, ErrorResponse > getTooManyRetriesError = methods -> ErrorResponse
            .builder()
            .message( "Service: " + methods + " does not return response!!!" )
            .errors( Errors.TOO_MANY_RETRIES_ERROR )
            .build();

    // логирует любые ошибки
    protected void saveErrorLog (
            final String methodName,
            final String params,
            final String reason ) {
        this.getNotification().setPinfl( params );
        this.getNotification().setReason( reason );
        this.getNotification().setMethodName( methodName );
        this.getNotification().setCallingTime( new Date() );
        KafkaDataControl
                .getInstance()
                .getWriteErrorLog()
                .accept( SerDes
                        .getINSTANCE()
                        .getGson()
                        .toJson( this.getNotification() ) ); }

    // отправляет ошибку на сервис Шамсиддина, в случае если какой - либо сервис не отвечает
    protected void saveErrorLog ( final String errorMessage ) {
        KafkaDataControl
                .getInstance()
                .getWriteToKafkaErrorLog()
                .accept( SerDes
                        .getINSTANCE()
                        .getGson()
                        .toJson( ErrorLog
                                .builder()
                                .errorMessage( errorMessage )
                                .createdAt( new Date().getTime() )
                                .integratedService( IntegratedServiceApis.OVIR.getName() )
                                .integratedServiceApiDescription( IntegratedServiceApis.OVIR.getDescription() )
                                .build() ) ); }

    // saves error from external service
    protected final BiFunction< String, Methods, Mono< ? > > saveErrorLog = ( errorMessage, methods ) -> {
            KafkaDataControl
                    .getInstance()
                    .getWriteToKafkaErrorLog()
                    .accept( SerDes
                            .getINSTANCE()
                            .getGson()
                            .toJson( ErrorLog
                                    .builder()
                                    .errorMessage( errorMessage )
                                    .createdAt( new Date().getTime() )
                                    .integratedService( IntegratedServiceApis.OVIR.getName() )
                                    .integratedServiceApiDescription( IntegratedServiceApis.OVIR.getDescription() )
                                    .build() ) );
            return super.convert( switch ( methods ) {
                case GET_MODEL_FOR_ADDRESS -> new ModelForAddress( this.getExternalServiceErrorResponse.apply( errorMessage ) );
                case GET_PINPP -> new Pinpp( this.getExternalServiceErrorResponse.apply( errorMessage ) );
                default -> Errors.EXTERNAL_SERVICE_500_ERROR.name(); } ); };
}
