package com.ssd.mvd.gwmsfamily.entity.modelForAddress;

@lombok.Data
public final class RequestGuid {}
