package com.ssd.mvd.gwmsfamily.controller;

import com.ssd.mvd.gwmsfamily.entity.modelForAddress.ModelForAddress;
import com.ssd.mvd.gwmsfamily.publisher.CustomPublisherForRequest;
import com.ssd.mvd.gwmsfamily.family.FinalResponse;
import com.ssd.mvd.gwmsfamily.constants.Methods;
import com.ssd.mvd.gwmsfamily.constants.Errors;
import com.ssd.mvd.gwmsfamily.config.Config;
import com.ssd.mvd.gwmsfamily.entity.*;

import com.mashape.unirest.http.exceptions.UnirestException;
import com.mashape.unirest.http.ObjectMapper;
import com.mashape.unirest.http.Unirest;

import com.fasterxml.jackson.core.JsonProcessingException;
import io.netty.handler.logging.LogLevel;
import com.google.gson.Gson;

import reactor.netty.transport.logging.AdvancedByteBufFormat;
import reactor.netty.http.client.HttpClient;
import reactor.netty.ByteBufFlux;
import reactor.util.retry.Retry;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.function.Supplier;
import java.time.Duration;

@lombok.Data
public final class SerDes extends Config implements Runnable {
    private Thread thread;
    private final Gson gson = new Gson();
    private static SerDes INSTANCE = new SerDes();
    private final HttpClient httpClient = HttpClient
            .create()
            .responseTimeout( Duration.ofMinutes( 1 ) )
            .headers( h -> h.add( "Content-Type", "application/json" ) )
            .wiretap( "reactor.netty.http.client.HttpClient", LogLevel.DEBUG, AdvancedByteBufFormat.TEXTUAL );

    public static SerDes getINSTANCE () { return INSTANCE != null ? INSTANCE : ( INSTANCE = new SerDes() ); }

    private SerDes () {
        Unirest.setObjectMapper( new ObjectMapper() {
            private final com.fasterxml.jackson.databind.ObjectMapper objectMapper = new com.fasterxml.jackson.databind.ObjectMapper();

            @Override
            public String writeValue( Object o ) {
                try { return this.objectMapper.writeValueAsString( o ); }
                catch ( JsonProcessingException e ) { throw new RuntimeException(e); } }

            @Override
            public <T> T readValue( String s, Class<T> aClass ) {
                try { return this.objectMapper.readValue( s, aClass ); }
                catch ( JsonProcessingException e ) { throw new RuntimeException(e); } } } );
        this.getHeaders().put( "accept", "application/json" );
        this.setThread( new Thread( this, this.getClass().getName() ) );
        this.getThread().start(); }

    private final Supplier< SerDes > updateTokens = () -> {
        super.logging( "Updating tokens..." );
        this.getFields().put( "Login", super.getLOGIN_FOR_GAI_TOKEN() );
        this.getFields().put( "Password" , super.getPASSWORD_FOR_GAI_TOKEN() );
        this.getFields().put( "CurrentSystem", super.getCURRENT_SYSTEM_FOR_GAI() );
        try { super.setTokenForGai( String.valueOf( Unirest.post( super.getAPI_FOR_GAI_TOKEN() )
                .fields( super.getFields() )
                .asJson()
                .getBody()
                .getObject()
                .get( "access_token" ) ) );
            super.setTokenForPassport( this.getTokenForGai() );
            super.setWaitingMins( 180 );
            super.setFlag( true );
            return this; }
        catch ( final UnirestException e ) {
            super.setFlag( false );
            super.setWaitingMins( 3 );
            super.saveErrorLog( e.getMessage() );
            super.saveErrorLog( Methods.UPDATE_TOKENS.name(),
                    "access_token",
                    "Error: " + e.getMessage() );
            this.getUpdateTokens().get(); }
        return this; };

    private final Function< String, Mono< String > > getImageByPinfl = pinfl -> this.getHttpClient()
            .headers( h -> h.add( "Authorization", "Bearer " + this.getTokenForGai() ) )
            .get()
            .uri( super.getAPI_FOR_PERSON_IMAGE() + pinfl )
            .responseSingle( ( res, content ) -> switch ( res.status().code() ) {
                case 401 -> this.getUpdateTokens().get().getGetImageByPinfl().apply( pinfl );
                case 501 | 502 | 503 -> ( Mono< String > ) super.saveErrorLog.apply( res.status().toString(), Methods.GET_IMAGE_BY_PINFL );
                default -> super.checkResponse.test( res, content )
                        ? content
                        .asString()
                        .map( s -> s.substring( s.indexOf( "Data" ) + 7, s.indexOf( ",\"AnswereId" ) - 1 ) )
                        : super.convert( Errors.DATA_NOT_FOUND.name() ); } )
            .retryWhen( Retry.backoff( 2, Duration.ofSeconds( 2 ) )
                    .doBeforeRetry( retrySignal -> super.logging( retrySignal, Methods.GET_IMAGE_BY_PINFL ) )
                    .doAfterRetry( retrySignal -> super.logging( Methods.GET_IMAGE_BY_PINFL, retrySignal ) )
                    .onRetryExhaustedThrow( ( retryBackoffSpec, retrySignal ) -> new IllegalArgumentException() ) )
            .onErrorResume( io.netty.channel.ConnectTimeoutException.class,
                    throwable -> super.convert( Errors.RESPONSE_FROM_SERVICE_NOT_RECEIVED + " : " + throwable.getMessage() ) )
            .onErrorResume( IllegalArgumentException.class,
                    throwable -> super.convert( Errors.TOO_MANY_RETRIES_ERROR + " : " + throwable.getMessage() ) )
            .doOnError( e -> super.logging( e, Methods.GET_IMAGE_BY_PINFL, pinfl ) )
            .doOnSubscribe( value -> super.logging( super.getAPI_FOR_PERSON_IMAGE() ) )
            .onErrorReturn( Errors.DATA_NOT_FOUND.name() );

    private final Function< String, Mono< Pinpp > > getPinpp = pinfl -> this.getHttpClient()
            .headers( h -> h.add( "Authorization", "Bearer " + this.getTokenForPassport() ) )
            .get()
            .uri( super.getAPI_FOR_PINPP() + pinfl )
            .responseSingle( ( res, content ) -> switch ( res.status().code() ) {
                case 401 -> this.getUpdateTokens().get().getGetPinpp().apply( pinfl );
                case 500 | 501 | 502 | 503 -> ( Mono< Pinpp > ) super.saveErrorLog.apply( res.status().toString(), Methods.GET_PINPP );
                default -> super.checkResponse.test( res, content )
                        ? content
                        .asString()
                        .map( s -> this.getGson().fromJson( s, Pinpp.class ) )
                        : super.convert( new Pinpp( super.getDataNotFoundErrorResponse.apply( pinfl ) ) ); } )
            .retryWhen( Retry.backoff( 2, Duration.ofSeconds( 3 ) )
                    .doBeforeRetry( retrySignal -> super.logging( retrySignal, Methods.GET_PINPP ) )
                    .doAfterRetry( retrySignal -> super.logging( Methods.GET_PINPP, retrySignal ) )
                    .onRetryExhaustedThrow( ( retryBackoffSpec, retrySignal ) -> new IllegalArgumentException() ) )
            .onErrorResume( io.netty.channel.ConnectTimeoutException.class,
                    throwable -> super.convert( new Pinpp( super.getConnectionError.apply( throwable.getMessage() ) ) ) )
            .onErrorResume( IllegalArgumentException.class,
                    throwable -> super.convert( new Pinpp( super.getTooManyRetriesError.apply( Methods.GET_PINPP ) ) ) )
            .doOnError( throwable -> super.logging( throwable, Methods.GET_PINPP, pinfl ) )
            .doOnSuccess( value -> super.logging( Methods.GET_PINPP, value ) )
            .doOnSubscribe( value -> super.logging( super.getAPI_FOR_PINPP() ) );

    private final Function< String, Mono< ModelForAddress > > getModelForAddress = pinfl -> this.getHttpClient()
            .headers( h -> h.add( "Authorization", "Bearer " + this.getTokenForGai() ) )
            .post()
            .uri( super.getAPI_FOR_MODEL_FOR_ADDRESS() )
            .send( ByteBufFlux.fromString( new CustomPublisherForRequest( pinfl ) ) )
            .responseSingle( ( res, content ) -> switch ( res.status().code() ) {
                case 401 -> this.getUpdateTokens().get().getGetModelForAddress().apply( pinfl );
                case 501 | 502 | 503 -> ( Mono< ModelForAddress > ) super.saveErrorLog
                        .apply( res.status().toString(), Methods.GET_MODEL_FOR_ADDRESS );
                default -> super.checkResponse.test( res, content )
                        ? content
                        .asString()
                        .map( s -> this.getGson().fromJson(
                                s.substring( s.indexOf( "Data" ) + 6, s.indexOf( ",\"AnswereId" ) ),
                                ModelForAddress.class ) )
                        : super.convert( new ModelForAddress( super.getDataNotFoundErrorResponse.apply( pinfl ) ) ); } )
            .retryWhen( Retry.backoff( 2, Duration.ofSeconds( 3 ) )
                    .doBeforeRetry( retrySignal -> super.logging( retrySignal, Methods.GET_MODEL_FOR_ADDRESS ) )
                    .doAfterRetry( retrySignal -> super.logging( Methods.GET_MODEL_FOR_ADDRESS, retrySignal ) )
                    .onRetryExhaustedThrow( ( retryBackoffSpec, retrySignal ) -> new IllegalArgumentException() ) )
            .onErrorResume( io.netty.channel.ConnectTimeoutException.class,
                    throwable -> super.convert( new ModelForAddress( super.getConnectionError.apply( throwable.getMessage() ) ) ) )
            .onErrorResume( IllegalArgumentException.class,
                    throwable -> super.convert( new ModelForAddress( super.getTooManyRetriesError.apply( Methods.GET_MODEL_FOR_ADDRESS ) ) ) )
            .doOnError( e -> super.logging( e, Methods.GET_MODEL_FOR_ADDRESS, pinfl ) )
            .doOnSuccess( value -> super.logging( Methods.GET_MODEL_FOR_ADDRESS, value ) )
            .doOnSubscribe( value -> super.logging( super.getAPI_FOR_MODEL_FOR_ADDRESS() ) )
            .onErrorReturn( new ModelForAddress( super.getServiceErrorResponse.apply( Errors.SERVICE_WORK_ERROR ) ) );

    private final Function< FinalResponse, Mono< FinalResponse > > getPsychologyCard =
            finalResponse -> super.checkData.test( 1, finalResponse.getPersons() )
                    ? Flux.fromStream( finalResponse
                            .getPersons()
                            .stream() )
                    .filter( person -> super.checkData.test( 2, person.getPinfl() ) )
                    .flatMap( person -> Mono.zip(
                                this.getGetPinpp().apply( person.getPinfl() ),
                                this.getGetImageByPinfl().apply( person.getPinfl() ) )
                                .flatMap( tuple2 -> this.getGetModelForAddress().apply( tuple2.getT1().getPCitizen() )
                                        .map( modelForAddress -> person.save( new PsychologyCard( tuple2, modelForAddress ) ) ) ) )
                    .collectList()
                    .map( finalResponse::save )
                    : super.convert( finalResponse );

    @Override
    public void run () {
        while ( this.getThread().isAlive() ) {
            this.getUpdateTokens().get();
            try { TimeUnit.MINUTES.sleep( super.getWaitingMins() ); }
            catch ( final InterruptedException e ) {
                INSTANCE = null;
                this.setFlag( false );
                super.logging( e, Methods.UPDATE_TOKENS, "" );
                SerDes.getINSTANCE(); } }
        SerDes.getINSTANCE(); }
}