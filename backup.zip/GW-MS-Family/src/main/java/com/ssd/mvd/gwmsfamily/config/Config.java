package com.ssd.mvd.gwmsfamily.config;

import com.ssd.mvd.gwmsfamily.inspectors.LogInspector;
import com.ssd.mvd.gwmsfamily.GwMsFamilyApplication;

import java.util.HashMap;
import java.util.Map;

public class Config extends LogInspector {
    private Boolean flag = true;
    private String tokenForGai;
    private String tokenForPassport;

    // how many minutes to wait for Thread in SerDes class
    // 180 mins by default
    private Integer waitingMins = 180;

    public Boolean getFlag() { return this.flag; }

    protected void setFlag ( final Boolean flag ) { this.flag = flag; }

    protected String getTokenForGai() { return this.tokenForGai; }

    protected void setTokenForGai ( final String tokenForGai ) { this.tokenForGai = tokenForGai; }

    protected String getTokenForPassport() { return this.tokenForPassport; }

    protected void setTokenForPassport ( final String tokenForPassport ) { this.tokenForPassport = tokenForPassport; }

    protected Integer getWaitingMins() { return this.waitingMins; }

    protected void setWaitingMins ( final Integer waitingMins ) { this.waitingMins = waitingMins; }

    protected Map< String, Object > getFields() { return this.fields; }

    protected Map< String, String > getHeaders() { return this.headers; }

    protected String getLOGIN_FOR_GAI_TOKEN() { return this.LOGIN_FOR_GAI_TOKEN; }

    protected String getCURRENT_SYSTEM_FOR_GAI() { return this.CURRENT_SYSTEM_FOR_GAI; }

    protected String getPASSWORD_FOR_GAI_TOKEN() { return this.PASSWORD_FOR_GAI_TOKEN; }

    protected String getAPI_FOR_GAI_TOKEN() { return this.API_FOR_GAI_TOKEN; }

    protected String getAPI_FOR_PINPP() { return this.API_FOR_PINPP; }

    protected String getAPI_FOR_PERSON_IMAGE() { return this.API_FOR_PERSON_IMAGE; }

    protected String getAPI_FOR_MODEL_FOR_ADDRESS() { return this.API_FOR_MODEL_FOR_ADDRESS; }

    protected String getERROR_LOGS() { return this.ERROR_LOGS; }

    protected String getADMIN_PANEL() { return this.ADMIN_PANEL; }

    protected String getADMIN_PANEL_ERROR_LOG() { return this.ADMIN_PANEL_ERROR_LOG; }

    private final Map< String, Object > fields = new HashMap<>();
    private final Map< String, String > headers = new HashMap<>();

    private final String LOGIN_FOR_GAI_TOKEN = GwMsFamilyApplication
            .context
            .getEnvironment()
            .getProperty( "variables.GAI_VARIABLES.LOGIN_FOR_GAI_TOKEN" );

    private final String CURRENT_SYSTEM_FOR_GAI = GwMsFamilyApplication
            .context
            .getEnvironment()
            .getProperty( "variables.GAI_VARIABLES.CURRENT_SYSTEM_FOR_GAI" );

    private final String PASSWORD_FOR_GAI_TOKEN = GwMsFamilyApplication
            .context
            .getEnvironment()
            .getProperty( "variables.GAI_VARIABLES.PASSWORD_FOR_GAI_TOKEN" );

    private final String API_FOR_GAI_TOKEN = GwMsFamilyApplication
            .context
            .getEnvironment()
            .getProperty( "variables.GAI_VARIABLES.API_FOR_GAI_TOKEN" );

    private final String API_FOR_PINPP = GwMsFamilyApplication
            .context
            .getEnvironment()
            .getProperty( "variables.OVIR_VARIABLES.API_FOR_PINPP" );

    private final String API_FOR_PERSON_IMAGE = GwMsFamilyApplication
            .context
            .getEnvironment()
            .getProperty( "variables.OVIR_VARIABLES.API_FOR_PERSON_IMAGE" );

    private final String API_FOR_MODEL_FOR_ADDRESS = GwMsFamilyApplication
            .context
            .getEnvironment()
            .getProperty( "variables.OVIR_VARIABLES.API_FOR_MODEL_FOR_ADDRESS" );

    private final String ERROR_LOGS = GwMsFamilyApplication
            .context
            .getEnvironment()
            .getProperty( "variables.KAFKA_VARIABLES.KAFKA_TOPICS.ERROR_LOGS" );

    private final String ADMIN_PANEL = GwMsFamilyApplication
            .context
            .getEnvironment()
            .getProperty( "variables.KAFKA_VARIABLES.KAFKA_TOPICS.ADMIN_PANEL" );

    private final String ADMIN_PANEL_ERROR_LOG = GwMsFamilyApplication
            .context
            .getEnvironment()
            .getProperty( "variables.KAFKA_VARIABLES.KAFKA_TOPICS.ADMIN_PANEL_ERROR_LOG" );
}
