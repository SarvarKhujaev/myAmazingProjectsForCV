package com.ssd.mvd.gwmsfamily.constants;

public enum Methods {
    CADASTER,
    GET_PINPP,
    UPDATE_TOKENS,
    GET_IMAGE_BY_PINFL,
    GET_MODEL_FOR_ADDRESS,

    // methods from FindFaceComponent
    GET_PARENTS_DATA,
    GET_PARTNER_DATA,
    GET_SIBLINGS_DATA,
    GET_CHILDREN_DATA,
}
