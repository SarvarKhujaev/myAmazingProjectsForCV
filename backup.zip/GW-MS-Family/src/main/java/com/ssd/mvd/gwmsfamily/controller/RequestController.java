package com.ssd.mvd.gwmsfamily.controller;

import com.googlecode.jsonrpc4j.spring.AutoJsonRpcServiceImpl;
import com.googlecode.jsonrpc4j.JsonRpcService;
import com.googlecode.jsonrpc4j.JsonRpcMethod;
import com.ssd.mvd.gwmsfamily.inspectors.LogInspector;
import org.springframework.stereotype.Service;
import com.googlecode.jsonrpc4j.JsonRpcParam;

import com.ssd.mvd.gwmsfamily.family.FinalResponse;
import com.ssd.mvd.gwmsfamily.constants.Methods;
import com.ssd.mvd.gwmsfamily.config.Config;

@Service
@AutoJsonRpcServiceImpl
@JsonRpcService( value = "/api/v1/family" )
public final class RequestController extends LogInspector {
    // принимает пинфл и возвращает данные родителей
    @JsonRpcMethod( value = "parents.by.pinfl" )
    public FinalResponse getParentsData ( @JsonRpcParam( value = "pinfl" ) final String pinfl ) {
        super.logging( Methods.GET_PARENTS_DATA, pinfl );
        if ( !SerDes.getINSTANCE().getFlag() ) SerDes.getINSTANCE().getUpdateTokens().get();
        return SerDes.getINSTANCE().getFlag()
                ? super.checkData.test( 2, pinfl )
                ? FindFaceComponent
                .getInstance()
                .getFinalResponse
                .apply( pinfl, Methods.GET_PARENTS_DATA )
                .flatMap( finalResponse -> SerDes
                        .getINSTANCE()
                        .getGetPsychologyCard()
                        .apply( finalResponse ) )
                .block()
                : new FinalResponse()
                : new FinalResponse(); }

    // принимает пинфл и возвращает данные детей
    @JsonRpcMethod( value = "children.by.pinfl" )
    public FinalResponse getChildrenData ( @JsonRpcParam( value = "pinfl" ) final String pinfl ) {
        super.logging( Methods.GET_CHILDREN_DATA, pinfl );
        if ( !SerDes.getINSTANCE().getFlag() ) SerDes.getINSTANCE().getUpdateTokens().get();
        return SerDes.getINSTANCE().getFlag()
                ? super.checkData.test( 2, pinfl )
                ? FindFaceComponent
                .getInstance()
                .getFinalResponse
                .apply( pinfl, Methods.GET_CHILDREN_DATA )
                .flatMap( finalResponse -> SerDes
                        .getINSTANCE()
                        .getGetPsychologyCard()
                        .apply( finalResponse ) )
                .block()
                : new FinalResponse()
                : new FinalResponse(); }

    // принимает пинфл и возвращает данные братьев т сестрр
    @JsonRpcMethod( value = "siblings.by.pinfl" )
    public FinalResponse getSiblingsData ( @JsonRpcParam( value = "pinfl" ) final String pinfl ) {
        super.logging( Methods.GET_SIBLINGS_DATA, pinfl );
        if ( !SerDes.getINSTANCE().getFlag() ) SerDes.getINSTANCE().getUpdateTokens().get();
        return SerDes.getINSTANCE().getFlag()
                ? super.checkData.test( 2, pinfl )
                ? FindFaceComponent
                .getInstance()
                .getFinalResponse
                .apply( pinfl, Methods.GET_SIBLINGS_DATA )
                .flatMap( finalResponse -> SerDes
                        .getINSTANCE()
                        .getGetPsychologyCard()
                        .apply( finalResponse ) )
                .block()
                : new FinalResponse()
                : new FinalResponse(); }

    // принимает пинфл и возвращает данные супруга
    @JsonRpcMethod( value = "partner.by.pinfl" )
    public FinalResponse getPartnerData ( @JsonRpcParam( value = "pinfl" ) final String pinfl ) {
        super.logging( Methods.GET_PARTNER_DATA, pinfl );
        if ( !SerDes.getINSTANCE().getFlag() ) SerDes.getINSTANCE().getUpdateTokens().get();
        return SerDes.getINSTANCE().getFlag()
                ? super.checkData.test( 2, pinfl )
                ? FindFaceComponent
                .getInstance()
                .getFinalResponse
                .apply( pinfl, Methods.GET_PARTNER_DATA )
                .flatMap( finalResponse -> SerDes
                        .getINSTANCE()
                        .getGetPsychologyCard()
                        .apply( finalResponse ) )
                .block()
                : new FinalResponse()
                : new FinalResponse(); }
}