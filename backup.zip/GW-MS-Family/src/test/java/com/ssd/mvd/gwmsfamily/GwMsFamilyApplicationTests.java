package com.ssd.mvd.gwmsfamily;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GwMsFamilyApplicationTests {

    @Test
    void contextLoads() {
    }

}
