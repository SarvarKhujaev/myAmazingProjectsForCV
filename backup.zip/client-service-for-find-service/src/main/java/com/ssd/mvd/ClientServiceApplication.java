package com.ssd.mvd;

import com.ssd.mvd.configs.RSocketPingService;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClientServiceApplication {
    public final static ApplicationContext context = SpringApplication.run( ClientServiceApplication.class );

    public static void main( final String[] args ) { RSocketPingService.getInstance(); }
}
