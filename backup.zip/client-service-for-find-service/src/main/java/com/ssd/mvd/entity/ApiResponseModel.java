package com.ssd.mvd.entity;

import com.ssd.mvd.Authorization.User;

@lombok.Data
@lombok.Builder
public class ApiResponseModel {
    private Boolean success;
    private Status status;
    private User user;
}
