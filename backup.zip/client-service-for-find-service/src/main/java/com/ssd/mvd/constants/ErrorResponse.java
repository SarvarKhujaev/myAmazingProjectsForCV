package com.ssd.mvd.constants;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class ErrorResponse {
    private String message;
    private Errors errors;

    public ErrorResponse ( final Throwable throwable ) {
        this.setErrors( Errors.SERVICE_WORK_ERROR );
        this.setMessage( throwable.getMessage() ); }
}
