package com.ssd.mvd.controllers;

import com.ssd.mvd.controllerForFindFace.modelForFioOfPerson.PersonTotalDataByFIO;
import com.ssd.mvd.controllerForFindFace.modelForAddress.ModelForAddress;
import com.ssd.mvd.controllerForFindFace.modelForGai.Tonirovka;
import com.ssd.mvd.controllerForFindFace.modelForGai.ViolationsList;
import com.ssd.mvd.controllerForFindFace.modelForFioOfPerson.FIO;
import com.ssd.mvd.controllerForFindFace.ModelForCarList;
import com.ssd.mvd.controllerForFindFace.PsychologyCard;
import com.ssd.mvd.entity.boardCrossing.CrossBoardInfo;
import com.ssd.mvd.controllerForFindFace.CarTotalData;
import com.ssd.mvd.controllerForFindFace.Pinpp;
import com.ssd.mvd.entity.ApiResponseModel;
import com.ssd.mvd.inspectors.LogInspector;
import com.ssd.mvd.constants.Methods;

import org.springframework.messaging.rsocket.RSocketRequester;
import org.springframework.stereotype.Component;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import java.util.List;

@Component
@lombok.RequiredArgsConstructor
public class FindFaceRequester extends LogInspector {
    private final RSocketRequester requester;

    // данные по авто
    public Mono< Tonirovka > getCarTonirovka ( final ApiResponseModel apiResponseModel ) {
        return this.requester
                .route( Methods.GET_CAR_TONIROVKA.name() )
                .data( apiResponseModel )
                .retrieveMono( Tonirovka.class ); }

    public Mono< ModelForCarList > getModelForCarList ( final ApiResponseModel apiResponseModel ) {
        return this.requester
                .route( Methods.GET_MODEL_FOR_CAR_LIST_INITIAL.name() )
                .data( apiResponseModel )
                .retrieveMono( ModelForCarList.class ); }

    public Mono< ViolationsList > getPersonFinesForDriving ( final ApiResponseModel apiResponseModel ) {
        return this.requester
                .route( Methods.GET_PERSON_FINES_FOR_DRIVING.name() )
                .data( apiResponseModel )
                .retrieveMono( ViolationsList.class )
                .onErrorResume( throwable -> super.logging( throwable, Methods.GET_PERSON_FINES_FOR_DRIVING, new ViolationsList( throwable ) ) ); }

    public Mono< CarTotalData > getCarTotalData ( final Methods methods, final ApiResponseModel apiResponseModel ) { return this.requester
            .route( methods.name() )
            .data( apiResponseModel )
            .retrieveMono( CarTotalData.class )
            .onErrorResume( throwable -> super.logging( throwable, methods, new CarTotalData( throwable ) ) ); }

    // ---------------------------------------------------------------- данные для человека

    public Mono< PersonTotalDataByFIO > getPersonTotalDataByFIO ( final FIO fio ) { return this.requester
            .route( Methods.GET_PERSON_TOTAL_DATA_BY_FIO.name() )
            .data( fio )
            .retrieveMono( PersonTotalDataByFIO.class )
            .onErrorResume( throwable -> super.logging( throwable, Methods.GET_PERSON_TOTAL_DATA_BY_FIO, new PersonTotalDataByFIO( throwable ) ) ); }

    public Mono< List > getViolationListByPinfl ( final ApiResponseModel apiResponseModel ) {
        return this.requester
                .route( Methods.GET_VIOLATION_LIST_BY_PINFL.name() )
                .data( apiResponseModel )
                .retrieveMono( List.class ); }

    public Mono< ModelForAddress > get_temporary_or_permanent_registration (final ApiResponseModel apiResponseModel ) { return this.requester
            .route( Methods.GET_TEMPORARY_OR_PERMANENT_REGISTRATION.name() )
            .data( apiResponseModel )
            .retrieveMono( ModelForAddress.class )
            .onErrorResume( throwable -> super.logging( throwable, Methods.GET_TEMPORARY_OR_PERMANENT_REGISTRATION, new ModelForAddress( throwable ) ) ); }

    public Mono< PsychologyCard > getPsychologyCard ( final Methods methods, final ApiResponseModel apiResponseModel ) {
        return this.requester
            .route( methods.name() )
            .data( apiResponseModel )
            .retrieveMono( PsychologyCard.class )
            .onErrorResume( throwable -> super.logging( throwable, methods, new PsychologyCard( throwable ) ) ); }

    public Flux< PsychologyCard > getPersonalCadastor ( final ApiResponseModel apiResponseModel, final Methods methods ) { return this.requester
            .route( methods.name() )
            .data( apiResponseModel )
            .retrieveFlux( PsychologyCard.class )
            .onErrorResume( throwable -> super.logging( throwable, Methods.GET_PERSONAL_CADASTOR, new PsychologyCard( throwable ) ) ); }

    public Mono< CrossBoardInfo > getBoardCrossing ( final ApiResponseModel apiResponseModel ) {
        return this.requester
                .route( Methods.GET_CROSS_BOARDING.name() )
                .data( apiResponseModel )
                .retrieveMono( CrossBoardInfo.class )
                .onErrorResume( throwable -> super.logging( throwable, Methods.GET_CROSS_BOARDING, new CrossBoardInfo( throwable ) ) ); }

    public Mono< Pinpp > getPinpp ( final ApiResponseModel apiResponseModel ) {
        return this.requester
                .route( Methods.GET_PINPP.name() )
                .data( apiResponseModel )
                .retrieveMono( Pinpp.class ); }
}
