package com.ssd.mvd.controllerForFindFace.modelForAddress;

@lombok.Data
public class pRegion {
    private Integer Id;
    private String Value;
    private String IdValue;
}
