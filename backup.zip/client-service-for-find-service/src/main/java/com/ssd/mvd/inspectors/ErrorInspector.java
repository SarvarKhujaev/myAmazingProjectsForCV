package com.ssd.mvd.inspectors;

import com.ssd.mvd.entity.ApiResponseModel;
import com.ssd.mvd.entity.Status;

import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import reactor.core.publisher.Mono;
import java.util.function.Supplier;

public class ErrorInspector extends DataValidateInspector {
    protected final Supplier< Mono< ResponseEntity< ApiResponseModel > > > get503Error = () -> super.convert(
            ResponseEntity
                    .status( HttpStatus.SERVICE_UNAVAILABLE )
                    .body( ApiResponseModel
                            .builder()
                            .success( false )
                            .status( Status
                                    .builder()
                                    .message( "Ooops unfortunately the server is temporary unavailable" )
                                    .code( 503 )
                                    .build() )
                            .build() ) );

    protected final Supplier< Mono< ResponseEntity< ApiResponseModel > > > get201Error = () -> super.convert(
            ResponseEntity
                    .status( HttpStatus.NOT_ACCEPTABLE )
                    .body( ApiResponseModel
                            .builder()
                            .status( Status
                                    .builder()
                                    .message( "Wrong Params" )
                                    .code( 201 )
                                    .build() )
                            .build() ) );

    protected final Supplier< Mono< ResponseEntity< ApiResponseModel > > > get401Error = () -> super.convert(
            ResponseEntity
                    .status( HttpStatus.UNAUTHORIZED )
                    .body( ApiResponseModel
                            .builder()
                            .success( false )
                            .status( Status
                                    .builder()
                                    .message( "Authorization failed" )
                                    .code( 401 )
                                    .build() )
                            .build() ) );
}
