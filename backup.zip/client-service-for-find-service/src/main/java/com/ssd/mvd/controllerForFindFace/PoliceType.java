package com.ssd.mvd.controllerForFindFace;

import lombok.extern.jackson.Jacksonized;

@lombok.Data
@Jacksonized
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class PoliceType {
    private String policeType;
}
