package com.ssd.mvd.controllerForFindFace.modelForFioOfPerson;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.ssd.mvd.Authorization.User;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
@JsonIgnoreProperties( ignoreUnknown = true )
public class FIO {
    private User user;
    private String name;
    private String surname;
    private String patronym;
}
