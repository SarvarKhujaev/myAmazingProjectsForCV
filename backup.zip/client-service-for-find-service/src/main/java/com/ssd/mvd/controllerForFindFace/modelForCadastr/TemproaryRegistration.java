package com.ssd.mvd.controllerForFindFace.modelForCadastr;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class TemproaryRegistration {
    private String pPsp;
    private String pPerson;
    private pStatus pStatus;
    private String pCitizen;
    private String pDateBirth;
    private String pRegistrationDate;
}