package com.ssd.mvd.controllerForFindFace.modelForPassport;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class Model{
	private String name;
	private Double confidence;
}