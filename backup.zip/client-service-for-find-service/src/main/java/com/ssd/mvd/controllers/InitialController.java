package com.ssd.mvd.controllers;

import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.bind.annotation.*;

import com.ssd.mvd.controllerForFindFace.PsychologyCard;
import com.ssd.mvd.controllerForFindFace.PoliceType;
import com.ssd.mvd.configs.RSocketPingService;
import com.ssd.mvd.inspectors.LogInspector;
import com.ssd.mvd.entity.ApiResponseModel;
import com.ssd.mvd.constants.Methods;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import java.util.Objects;

@CrossOrigin
@RestController
@lombok.RequiredArgsConstructor
@RequestMapping( value = "/personal-data-collector/api/v1/psychologyCard" )
public class InitialController extends LogInspector {
    private final FindFaceRequester requester;

    // данные по авто
    @GetMapping ( value = "/getCarTonirovka/{carNumber}" )
    public Mono< ? > getCarTonirovka ( @PathVariable ( value = "carNumber" ) final String carNumber ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.convert( super.userMe.apply(
                        ( (ServletRequestAttributes) Objects
                                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                                .getRequest()
                                .getHeader( "Authorization" ) ) )
                .map( apiResponseModel -> {
                    if ( !super.checkAuthResponse.test( apiResponseModel ) ) return super.get401Error.get();
                    apiResponseModel
                            .getStatus()
                            .setMessage( carNumber );
                    return this.requester.getCarTonirovka( apiResponseModel ); } )
                : super.get503Error.get();
        } catch ( final Exception e ) {
            super.logging.accept( e );
            return super.get401Error.get(); }
    }

    @GetMapping ( value = "/{data}" ) // принимает номер машины и возвращает данные о машине и его владельце
    public Mono< ? > getCarTotalData ( @PathVariable ( value = "data" ) final String carNumber ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.convert( super.userMe.apply(
                        ( (ServletRequestAttributes) Objects
                                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                                .getRequest()
                                .getHeader( "Authorization" ) ) )
                .map( apiResponseModel -> {
                    if ( !super.checkAuthResponse.test( apiResponseModel ) ) return super.get401Error.get();
                    apiResponseModel
                            .getStatus()
                            .setMessage( carNumber );
                    return this.requester.getCarTotalData( Methods.GET_CAR_DATA_BY_GOS_NUMBER_INITIAL, apiResponseModel ); } )
                : super.get503Error.get();
        } catch ( final Exception e ) {
            super.logging.accept( e );
            return super.get401Error.get(); } }

    @GetMapping ( value = "/getModelForCarList/{pinfl}" ) // возвращает список машин для человека и подробную инфу о каждой машине
    public Mono< ? > getModelForCarList ( @PathVariable ( value = "pinfl" ) final String pinfl ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.convert( super.userMe.apply(
                        ( (ServletRequestAttributes) Objects
                                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                                .getRequest()
                                .getHeader( "Authorization" ) ) )
                .map( apiResponseModel -> {
                    if ( !super.checkAuthResponse.test( apiResponseModel ) ) return super.get401Error.get();
                    apiResponseModel.getStatus().setMessage( pinfl );
                    return this.requester.getModelForCarList( apiResponseModel ); } )
                : super.get503Error.get();
        } catch ( final Exception e ) {
            super.logging.accept( e );
            return super.get401Error.get(); } }

    @GetMapping ( value = "/getPersonFinesForDriving/{pinfl}" ) // возвращает список штрафов за вождение
    public Mono< ? > getPersonFinesForDriving ( @PathVariable ( value = "pinfl" ) final String pinfl ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.convert( super.userMe.apply(
                        ( (ServletRequestAttributes) Objects
                                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                                .getRequest()
                                .getHeader( "Authorization" ) ) )
                .map( apiResponseModel -> {
                    if ( !super.checkAuthResponse.test( apiResponseModel ) ) return super.get401Error.get();
                    apiResponseModel
                            .getStatus()
                            .setMessage( pinfl );
                    return this.requester.getPersonFinesForDriving( apiResponseModel ); } )
                : super.get503Error.get();
        } catch ( final Exception e ) {
            super.logging.accept( e );
            return super.get401Error.get(); } }

    // ---------------------------------------------------------------- дааные для человека

    @PostMapping ( value = "/" ) // возвращает данные о человеке по фото
    public Mono< ? > getPersonTotalData ( @RequestBody final PoliceType policeType ) {
        try {
            final String token = ( (ServletRequestAttributes)
                    Objects.requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                    .getRequest()
                    .getHeader( "Authorization" );
            policeType.setPoliceType( policeType.getPoliceType() + "@" + token );
            if ( !RSocketPingService
                    .getInstance()
                    .getFlag() ) return super.get503Error.get();
            final ApiResponseModel apiResponseModel = super.userMe.apply(
                        ( (ServletRequestAttributes) Objects
                                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                                .getRequest()
                                .getHeader( "Authorization" ) );
            if ( !super.checkAuthResponse.test( apiResponseModel ) ) return super.get401Error.get();
            apiResponseModel.getStatus().setMessage( policeType.getPoliceType() );
            return this.requester.getPsychologyCard( Methods.GET_PERSON_TOTAL_DATA_INITIAL, apiResponseModel );
        } catch ( final Exception e ) {
            super.logging.accept( e );
            return super.get201Error.get(); } }

    @GetMapping ( value = "/getPinpp/{pinfl}" )
    public Mono< ? > getPinpp ( @PathVariable ( value = "pinfl" ) final String pinfl ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.convert( super.userMe.apply(
                        ( (ServletRequestAttributes) Objects
                                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                                .getRequest()
                                .getHeader( "Authorization" ) ) )
                .map( apiResponseModel -> {
                    if ( !super.checkAuthResponse.test( apiResponseModel ) ) return super.get401Error.get();
                    apiResponseModel.getStatus().setMessage( pinfl );
                    return this.requester.getPinpp( apiResponseModel ); } )
                : super.get503Error.get();
        } catch ( final Exception e ) {
            super.logging.accept( e );
            return super.get401Error.get(); } }

    @GetMapping ( value = "/getBoardCrossing/{data}" )
    public Mono< ? > getBoardCrossing ( @PathVariable ( value = "data" ) final String data ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.checkPassportSeries.test( data )
                ? super.convert( super.userMe.apply(
                        ( (ServletRequestAttributes) Objects
                                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                                .getRequest()
                                .getHeader( "Authorization" ) ) )
                .map( apiResponseModel -> {
                    if ( !super.checkAuthResponse.test( apiResponseModel ) ) return super.get401Error.get();
                    final String[] temp = data.split( "_" );
                    final String[] passport = temp.length == 2 ? temp[1].split( "[.]" ) : new String[ 0 ];
                    if ( passport.length != 3 ) return super.get201Error.get();
                    apiResponseModel.getStatus().setMessage( String.join( "_", temp[0], String.join( "-", passport[2], passport[1], passport[0] ) ) );
                    return this.requester.getBoardCrossing( apiResponseModel ); } )
                : super.get201Error.get()
                : super.get503Error.get();
        } catch ( final Exception e ) {
            super.logging.accept( e );
            return super.get401Error.get(); } }

    @GetMapping ( value = "/getViolationList/{pinfl}" ) // возвращает список правонарушений человека по пинфл
    public Mono< ? > getViolationList ( @PathVariable( value = "pinfl" ) final String pinfl ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.convert( super.userMe.apply(
                        ( (ServletRequestAttributes) Objects
                                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                                .getRequest()
                                .getHeader( "Authorization" ) ) )
                .map( apiResponseModel -> {
                    if ( !super.checkAuthResponse.test( apiResponseModel ) ) return super.get401Error.get();
                    apiResponseModel.getStatus().setMessage( pinfl );
                    return this.requester.getViolationListByPinfl( apiResponseModel ); } )
                : super.get503Error.get();
        } catch ( final Exception e ) {
            super.logging.accept( e );
            return super.get401Error.get(); } }

    @GetMapping ( value = "/getPersonalCadastor/{id}" ) // возвращает данные о человеке по номеру кадастра
    public Flux< ? > getPersonalCadastor ( @PathVariable( value = "id" ) final String cadastr ) {
        try { if ( !RSocketPingService
                    .getInstance()
                    .getFlag() ) return Flux.just( super.get503Error.get() );
            final ApiResponseModel apiResponseModel = super.userMe.apply(
                        ( (ServletRequestAttributes) Objects
                                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                                .getRequest()
                                .getHeader( "Authorization" ) );
            if ( super.checkAuthResponse.test( apiResponseModel ) ) {
                apiResponseModel.getStatus().setMessage( cadastr );
                return this.requester.getPersonalCadastor( apiResponseModel, Methods.GET_PERSONAL_CADASTOR_INITIAL ); }

            else return Flux.just( super.get401Error.get() );
        } catch ( final Exception e ) {
            super.logging.accept( e );
            return Flux.just( super.get401Error.get() ); } }

    @GetMapping ( value = "/getPersonalDataByPinfl/{pinfl}" ) // возвращает данные о человеке по пинфл
    public Mono< ? > getPersonTotalDataByPinfl ( @PathVariable( value = "pinfl" ) final String pinfl ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.convert( super.userMe.apply(
                        ( (ServletRequestAttributes) Objects
                                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                                .getRequest()
                                .getHeader( "Authorization" ) ) )
                .map( apiResponseModel -> {
                    if ( !super.checkAuthResponse.test( apiResponseModel ) ) return super.get401Error.get();
                    apiResponseModel.getStatus().setMessage( pinfl );
                    return this.requester.getPsychologyCard( Methods.GET_PERSON_TOTAL_DATA_BY_PINFL_INITIAL, apiResponseModel )
                            .onErrorResume( throwable -> super.logging( throwable, Methods.GET_PERSON_TOTAL_DATA_BY_PINFL, new PsychologyCard( throwable ) ) ); } )
                : super.get503Error.get();
        } catch ( final Exception e ) {
            super.logging.accept( e );
            return super.get401Error.get(); } }

    @GetMapping ( value = "/getPersonDataByPassport/{data}" ) // возвращает данные о человеке по номеру паспорта и дате рождения
    public Mono< ? > getPersonDataByPassportSeriesAndBirthdate ( @PathVariable ( value = "data" ) final String data ) {
        try { return super.checkPassportSeries.test( data )
                ? RSocketPingService
                .getInstance()
                .getFlag()
                ? super.convert( super.userMe.apply(
                        ( (ServletRequestAttributes) Objects
                                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                                .getRequest()
                                .getHeader( "Authorization" ) ) )
                .map( apiResponseModel -> {
                    if ( !super.checkAuthResponse.test( apiResponseModel ) ) return super.get401Error.get();
                    apiResponseModel
                            .getStatus()
                            .setMessage( data );
                    return this.requester.getPsychologyCard( Methods.GET_PERSON_DATA_BY_PASSPORT_AND_BIRTHDATE_INITIAL, apiResponseModel )
                            .onErrorResume( throwable -> super.logging( throwable, Methods.GET_PERSON_TOTAL_DATA_BY_PINFL, new PsychologyCard( throwable ) ) ); } )
                : super.get503Error.get()
                : super.get201Error.get();
        } catch ( final Exception e ) {
            super.logging.accept( e );
            return super.get401Error.get(); } }

    @GetMapping ( value = "/get_person_registration/{data}" ) // возвращает данные о прописке человека по кадастру
    public Mono< ? > get_temporary_or_permanent_registration ( @PathVariable ( value = "data" ) final String cadastr ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.convert( super.userMe.apply(
                        ( (ServletRequestAttributes) Objects
                                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                                .getRequest()
                                .getHeader( "Authorization" ) ) )
                .map( apiResponseModel -> {
                    if ( !super.checkAuthResponse.test( apiResponseModel ) ) return super.get401Error.get();
                    apiResponseModel.getStatus().setMessage( cadastr );
                    return this.requester.get_temporary_or_permanent_registration( apiResponseModel ); } )
                : super.get503Error.get();
        } catch ( final Exception e ) {
            super.logging.accept( e );
            return super.get401Error.get(); } }
}
