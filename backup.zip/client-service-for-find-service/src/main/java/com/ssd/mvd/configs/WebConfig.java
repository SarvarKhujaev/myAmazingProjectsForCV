package com.ssd.mvd.configs;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.config.annotation.AsyncSupportConfigurer;

@Configuration
@EnableWebMvc
public class WebConfig implements WebMvcConfigurer {
    @Override
    public void addCorsMappings( CorsRegistry registry ) {
        registry.addMapping("/**");
    }

    @Override
    public void configureAsyncSupport( AsyncSupportConfigurer configurer ) {
        WebMvcConfigurer.super.configureAsyncSupport( configurer );
        configurer.setDefaultTimeout( 5 * 60 * 1000 ); }

}
