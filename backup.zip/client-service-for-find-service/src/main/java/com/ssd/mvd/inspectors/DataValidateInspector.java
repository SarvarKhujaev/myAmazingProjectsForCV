package com.ssd.mvd.inspectors;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;

import com.ssd.mvd.configs.RSocketPingService;
import com.ssd.mvd.entity.ApiResponseModel;
import com.ssd.mvd.Authorization.Response;
import com.ssd.mvd.Authorization.User;
import com.ssd.mvd.entity.Status;

import org.springframework.http.HttpHeaders;
import org.apache.commons.io.FileUtils;

import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;
import reactor.core.publisher.Flux;

import javax.imageio.ImageIO;
import com.google.gson.Gson;

import java.util.function.Predicate;
import java.util.function.Function;
import java.util.Base64;
import java.util.List;
import java.io.File;

public class DataValidateInspector {
    private final Gson gson = new Gson();
    private final File file = new File( "/var/opt/clientServiceImage.jpg" );

    private final List< String > permissions = List.of(
            "imitatsiya",
            "TANIB_OLISH",
            "АVTOMOBIL_QIDIRUVI",
            "АVTO_IDENTIFIKATSIYA",
            "SHAXS_IDENTIFIKATSIYASI" );

    protected   <T> Mono< T > convert ( final T o ) { return Mono.just( o ); }

    protected final Function< String, ApiResponseModel > userMe = token -> {
            final ApiResponseModel apiResponseModel = ApiResponseModel
                    .builder()
                    .status( Status.builder().build() )
                    .build();
            try { if ( token != null ) {
                final HttpResponse< JsonNode > response = Unirest
                        .get( RSocketPingService
                                .getInstance()
                                .getBasePath() + "/auth/me" )
                        .header( HttpHeaders.AUTHORIZATION, token )
                        .asJson();
                if ( response.getStatus() == 200 ) {
                    final Response response1 = this.gson
                            .fromJson( response
                                            .getBody()
                                            .toString(),
                                    Response.class );
                    if ( response1.getCode() == 200 ) {
                        final User user = response1.getData();
                        apiResponseModel.setUser( user );
                        final List< String > users = Flux.fromStream( user.getPermissions().stream() )
                                .parallel( user
                                        .getPermissions()
                                        .size() )
                                .runOn( Schedulers.parallel() )
                                .filter( this.permissions::contains )
                                .sequential()
                                .publishOn( Schedulers.single() )
                                .collectList()
                                .block();
                        if ( users.size() > 0 ) {
                            apiResponseModel.getStatus().setCode( 200L );
                            apiResponseModel.getStatus().setMessage( "SUCCESS" );
                        } else {
                            apiResponseModel.getStatus().setCode( 403L );
                            apiResponseModel.getStatus().setMessage( "FORBIDDEN" ); } }
                }
                else {
                    apiResponseModel.getStatus().setCode( response.getStatus() );
                    apiResponseModel.getStatus().setMessage( "AUTH ERROR "+ response.getStatusText() ); }
            } else {
                apiResponseModel.getStatus().setCode( 401L );
                apiResponseModel.getStatus().setMessage( "UNAUTHORIZED" ); }
            } catch ( final Exception e ) { return apiResponseModel; }
            return apiResponseModel; };

    protected Function< String, String > getImage = link -> {
            try {
                ImageIO.write( ImageIO.read( Unirest.get( link ).asBinary().getBody() ), "jpg", this.file );
                return Base64.getEncoder().encodeToString( FileUtils.readFileToByteArray( this.file ) );
            } catch ( final Exception e ) { e.printStackTrace(); }
            return null; };

    protected final Predicate< String > checkPassportSeries = data -> data != null && data.length() > 2 && data.contains( "_" );

    protected final Predicate< ApiResponseModel > checkAuthResponse = apiResponseModel -> apiResponseModel.getStatus().getCode() == 200;

    protected final Predicate< ApiResponseModel > checkRole = apiResponseModel -> apiResponseModel
            .getUser()
            .getRole()
            .compareTo( this.permissions.get( 0 ) ) == 0;
}
