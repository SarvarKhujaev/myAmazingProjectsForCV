package com.ssd.mvd.entity.boardCrossing;

@lombok.Data
public final class Purpose {
    private String periods;
    private String countries;
    private String tripPurpose;
    private String documentType;
    private String nationalities;
    private String transportCategory;
}
