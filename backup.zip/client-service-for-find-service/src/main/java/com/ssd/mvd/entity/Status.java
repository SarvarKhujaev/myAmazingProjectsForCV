package com.ssd.mvd.entity;

@lombok.Data
@lombok.Builder
public class Status {
    private long code;
    private String message;
}
