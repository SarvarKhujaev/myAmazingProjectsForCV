package com.ssd.mvd.controllerForFindFace.modelForAddress;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class pDistrict {
    private Integer Id;
    private String value;
    private String IdValue;
}
