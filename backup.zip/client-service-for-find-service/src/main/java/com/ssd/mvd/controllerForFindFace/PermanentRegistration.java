package com.ssd.mvd.controllerForFindFace;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class PermanentRegistration {
    private com.ssd.mvd.controllerForFindFace.modelForAddress.pRegion pRegion;
    private String pAddress;
    private String pCadastre;
    private String pRegistrationDate;
}
