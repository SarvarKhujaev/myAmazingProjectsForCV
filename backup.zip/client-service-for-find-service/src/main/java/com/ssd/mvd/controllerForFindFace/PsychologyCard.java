package com.ssd.mvd.controllerForFindFace;

import com.ssd.mvd.controllerForFindFace.modelForAddress.ModelForAddress;
import com.ssd.mvd.controllerForFindFace.foreigner.Foreigner;
import com.ssd.mvd.constants.ErrorResponse;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import java.util.List;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class PsychologyCard {
    private Pinpp pinpp;
    private String personImage; // the image of the person

    @JsonDeserialize
    private List< PapilonData > papilonData;
    @JsonDeserialize
    private List< Violation > violationList;
    @JsonDeserialize
    private List< Foreigner > foreignerList;

    @JsonDeserialize
    private ModelForCarList modelForCarList; // the list of all cars which belongs to this person
    @JsonDeserialize
    private ModelForAddress modelForAddress;

    private com.ssd.mvd.controllerForFindFace.modelForCadastr.Data modelForCadastr;
    private com.ssd.mvd.controllerForFindFace.modelForPassport.ModelForPassport modelForPassport;

    private ErrorResponse errorResponse;

    public PsychologyCard ( final Throwable throwable ) { this.setErrorResponse( new ErrorResponse( throwable ) ); }
}
