package com.ssd.mvd.controllerForFindFace.modelForPassport;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.ssd.mvd.constants.ErrorResponse;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@lombok.Data
@NoArgsConstructor
@AllArgsConstructor
public class Data {
    @JsonDeserialize
    private Person Person;
    @JsonDeserialize
    private Document Document;
    @JsonDeserialize
    private RequestGuid RequestGuid;

    private ErrorResponse errorResponse;
}
