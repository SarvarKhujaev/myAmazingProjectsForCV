package com.ssd.mvd.controllerForFindFace.foreigner;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.extern.jackson.Jacksonized;
import java.util.List;

@lombok.Data
@Jacksonized
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class ForeignerList {
    @JsonDeserialize
    private List< Foreigner > data;
}
