package com.ssd.mvd.controllers;

import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.bind.annotation.*;

import com.ssd.mvd.controllerForFindFace.modelForFioOfPerson.FIO;
import com.ssd.mvd.controllerForFindFace.PsychologyCard;
import com.ssd.mvd.controllerForFindFace.PoliceType;
import com.ssd.mvd.configs.RSocketPingService;
import com.ssd.mvd.inspectors.LogInspector;
import com.ssd.mvd.entity.ApiResponseModel;
import com.ssd.mvd.constants.Methods;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import java.util.Objects;

@CrossOrigin
@RestController
@lombok.RequiredArgsConstructor
@RequestMapping( value = "/findFaceService/api/v1/psychologyCard" )
public class PsychologyCardController extends LogInspector {
    private final FindFaceRequester requester;

    @PostMapping ( value = "/getPersonTotalDataByFIO" )
    public Mono< ? > getPersonTotalDataByFIO ( @RequestBody final FIO fio ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.convert( super.userMe.apply(
                        ( (ServletRequestAttributes) Objects
                                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                                .getRequest()
                                .getHeader( "Authorization" ) ) )
                .map( apiResponseModel -> {
                    fio.setUser( apiResponseModel.getUser() );
                    return super.checkAuthResponse.test( apiResponseModel )
                            ? this.requester.getPersonTotalDataByFIO( fio )
                            : super.get401Error.get(); } )
                : super.get503Error.get();
        } catch ( final Exception e ) {
            super.logging.accept( e );
            return super.get401Error.get(); } }

    @PostMapping ( value = "/" )
    public Mono< ? > getPersonTotalData ( @RequestBody final PoliceType policeType ) {
        try {
            final String token = ( (ServletRequestAttributes)
                    Objects.requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                    .getRequest()
                    .getHeader( "Authorization" );
            policeType.setPoliceType( policeType.getPoliceType() + "@" + token );
            if ( !RSocketPingService
                    .getInstance()
                    .getFlag() ) return super.get503Error.get();
            final ApiResponseModel apiResponseModel = super.userMe.apply(
                        ( (ServletRequestAttributes) Objects
                                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                                .getRequest()
                                .getHeader( "Authorization" ) );
            if ( !super.checkAuthResponse.test( apiResponseModel ) ) return super.get401Error.get();
            apiResponseModel
                    .getStatus()
                    .setMessage( super.checkRole.test( apiResponseModel )
                            ? super.getImage.apply(
                                    apiResponseModel
                                    .getUser()
                                    .getUserPhotoUrl() ) + "@" + token
                            : policeType.getPoliceType() );
            return this.requester.getPsychologyCard( Methods.GET_PERSON_TOTAL_DATA, apiResponseModel );
        } catch ( final Exception e ) {
            super.logging.accept( e );
            return super.get201Error.get(); } }

    @GetMapping ( value = "/getPersonalCadastor/{id}" )
    public Flux< ? > getPersonalCadastor ( @PathVariable( value = "id" ) final String id ) {
        try {
            if ( !RSocketPingService
                    .getInstance()
                    .getFlag() ) return Flux.just( super.get503Error.get() );
            final ApiResponseModel apiResponseModel = super.userMe.apply(
                        ( (ServletRequestAttributes) Objects
                                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                                .getRequest()
                                .getHeader( "Authorization" ) );
            if ( super.checkAuthResponse.test( apiResponseModel ) ) {
                apiResponseModel
                        .getStatus()
                        .setMessage( super.checkRole.test( apiResponseModel )
                                ? apiResponseModel
                                .getUser()
                                .getPinfl()
                                : id );
                return super.checkRole.test( apiResponseModel )
                        ? Flux.from( this.requester.getPsychologyCard( Methods.GET_PERSON_TOTAL_DATA_BY_PINFL, apiResponseModel ) )
                        : this.requester.getPersonalCadastor( apiResponseModel, Methods.GET_PERSONAL_CADASTOR ); }

            else return Flux.just( super.get401Error.get() );
        } catch ( final Exception e ) {
            super.logging.accept( e );
            return Flux.just( super.get401Error.get() ); } }

    @GetMapping ( value = "/{data}" )
    public Mono< ? > getCarTotalData ( @PathVariable ( value = "data" ) final String data ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.convert( super.userMe.apply(
                        ( (ServletRequestAttributes) Objects
                                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                                .getRequest()
                                .getHeader( "Authorization" ) ) )
                .map( apiResponseModel -> {
                    if ( !super.checkAuthResponse.test( apiResponseModel ) ) return super.get401Error.get();
                    apiResponseModel
                            .getStatus()
                            .setMessage( super.checkRole.test( apiResponseModel )
                                    ? apiResponseModel
                                    .getUser()
                                    .getPinfl()
                                    : data );
                    return super.checkRole.test( apiResponseModel )
                            ? this.requester.getCarTotalData( Methods.GET_CAR_TOTAL_DATA_BY_PINFL, apiResponseModel )
                            : this.requester.getCarTotalData( Methods.GET_CAR_TOTAL_DATA, apiResponseModel ); } )
                : super.get503Error.get();
        } catch ( final Exception e ) {
            super.logging.accept( e );
            return super.get401Error.get(); } }

    @GetMapping ( value = "/getPersonalDataByPinfl/{pinfl}" )
    public Mono< ? > getPersonTotalDataByPinfl ( @PathVariable( value = "pinfl" ) final String pinfl ) {
        try { return RSocketPingService
                .getInstance()
                .getFlag()
                ? super.convert( super.userMe.apply(
                        ( (ServletRequestAttributes) Objects
                                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                                .getRequest()
                                .getHeader( "Authorization" ) ) )
                .map( apiResponseModel -> {
                    if ( !super.checkAuthResponse.test( apiResponseModel ) ) return super.get401Error.get();
                    apiResponseModel
                            .getStatus()
                            .setMessage( super.checkRole.test( apiResponseModel )
                                    ? apiResponseModel
                                    .getUser()
                                    .getPinfl()
                                    : pinfl );
                    return this.requester.getPsychologyCard( Methods.GET_PERSON_TOTAL_DATA_BY_PINFL, apiResponseModel )
                            .onErrorResume( throwable ->
                                    super.logging( throwable, Methods.GET_PERSON_TOTAL_DATA_BY_PINFL, new PsychologyCard( throwable ) ) ); } )
                : super.get503Error.get();
        } catch ( final Exception e ) {
            super.logging.accept( e );
            return super.get401Error.get(); } }

    @GetMapping ( value = "/getPersonDataByPassport/{data}" )
    public Mono< ? > getPersonDataByPassportSeriesAndBirthdate ( @PathVariable ( value = "data" ) final String data ) {
        try { return super.checkPassportSeries.test( data )
                ? RSocketPingService
                .getInstance()
                .getFlag()
                ? super.convert( super.userMe.apply(
                        ( (ServletRequestAttributes) Objects
                                .requireNonNull( RequestContextHolder.getRequestAttributes() ) )
                                .getRequest()
                                .getHeader( "Authorization" ) ) )
                .map( apiResponseModel -> {
                    if ( !super.checkAuthResponse.test( apiResponseModel ) ) return super.get401Error.get();
                    apiResponseModel
                            .getStatus()
                            .setMessage( super.checkRole.test( apiResponseModel )
                                    ? apiResponseModel
                                    .getUser()
                                    .getPinfl()
                                    : data );
                    return super.checkRole.test( apiResponseModel )
                            ? this.requester.getPsychologyCard( Methods.GET_PERSON_TOTAL_DATA_BY_PINFL, apiResponseModel )
                            : this.requester.getPsychologyCard( Methods.GET_PERSON_TOTAL_DATA_BY_PASSPORT_AND_BIRTHDATE, apiResponseModel )
                            .onErrorResume( throwable ->
                                    super.logging( throwable, Methods.GET_PERSON_TOTAL_DATA_BY_PINFL, new PsychologyCard( throwable ) ) ); } )
                : super.get503Error.get()
                : super.get201Error.get();
        } catch ( final Exception e ) {
            super.logging.accept( e );
            return super.get401Error.get(); } }
}