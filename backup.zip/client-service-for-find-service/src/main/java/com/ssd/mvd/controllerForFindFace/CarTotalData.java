package com.ssd.mvd.controllerForFindFace;

import com.ssd.mvd.controllerForFindFace.modelForGai.*;
import com.ssd.mvd.constants.ErrorResponse;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class CarTotalData {
    private String gosNumber;
    private String cameraImage; // image which was made by camera

    private Tonirovka tonirovka;
    private Insurance insurance;
    private ModelForCar modelForCar;
    private PsychologyCard psychologyCard;
    private ViolationsList violationsList;
    private DoverennostList doverennostList;
    private ModelForCarList modelForCarList; // the list of all cars of each citizen

    private ErrorResponse errorResponse;

    public CarTotalData( final Throwable throwable ) { this.setErrorResponse( new ErrorResponse( throwable ) ); }
}
