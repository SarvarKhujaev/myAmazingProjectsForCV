package com.ssd.mvd.controllerForFindFace.modelForGai;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import java.util.List;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class DoverennostList {
    @JsonDeserialize
    private List< Doverennost > doverennostsList;
}
