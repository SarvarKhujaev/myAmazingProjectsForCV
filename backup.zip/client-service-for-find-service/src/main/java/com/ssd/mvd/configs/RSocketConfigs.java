package com.ssd.mvd.configs;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Lazy;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.rsocket.RSocketRequester;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class RSocketConfigs {
    @Lazy
    @Bean
    public WebClient webClient ( WebClient.Builder builder ) { return builder.build(); }

    @Value( "${variables.LOAD_BALANCER}" )
    private String host;
    @Value( "${variables.PRODUCER_PORT}" )
    private Integer port;

    @Bean
    RSocketRequester findFaceService ( RSocketRequester.Builder builder ) { return builder.tcp( this.host, this.port ); }
}
