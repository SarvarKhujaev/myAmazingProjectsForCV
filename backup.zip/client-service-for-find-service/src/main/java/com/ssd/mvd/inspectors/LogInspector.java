package com.ssd.mvd.inspectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.ssd.mvd.constants.Methods;

import reactor.core.publisher.Mono;
import java.util.function.Consumer;

public class LogInspector extends ErrorInspector {
    private final Logger LOGGER = LogManager.getLogger( "LOGGER_WITH_JSON_LAYOUT" );

    private Logger getLOGGER() { return this.LOGGER; }

    protected final Consumer< Throwable > logging = throwable -> this.getLOGGER().error( "Error occured: " + throwable );

    protected <T> Mono< T > logging ( final Throwable error, final Methods methods, final T clazz ) {
        this.getLOGGER().error( "Error in: {} and reason: {}", methods, error );
        return Mono.just( clazz ); }
}
