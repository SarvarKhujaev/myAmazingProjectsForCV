package com.ssd.mvd.entity.boardCrossing;

import com.ssd.mvd.constants.ErrorResponse;
import java.util.List;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public final class CrossBoardInfo {
    private String Result;
    private List< Data > Data;
    private ErrorResponse errorResponse;

    public CrossBoardInfo ( final Throwable throwable ) { this.setErrorResponse( new ErrorResponse( throwable ) ); }
}
