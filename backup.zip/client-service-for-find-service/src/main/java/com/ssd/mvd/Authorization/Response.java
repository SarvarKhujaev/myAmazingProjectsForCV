package com.ssd.mvd.Authorization;

import lombok.Data;

@Data
public class Response {
    private String message;
    private Integer code;
    private User data;
}
