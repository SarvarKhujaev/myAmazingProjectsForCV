package com.ssd.mvd.controllerForFindFace.modelForAddress;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.ssd.mvd.constants.ErrorResponse;
import java.util.List;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class ModelForAddress {
    private ErrorResponse errorResponse;
    private PermanentRegistration PermanentRegistration;
    private com.ssd.mvd.controllerForFindFace.modelForPassport.RequestGuid RequestGuid;
    @JsonDeserialize
    private List< com.ssd.mvd.controllerForFindFace.modelForAddress.TemproaryRegistration > TemproaryRegistration;

    public ModelForAddress( final Throwable throwable ) { this.setErrorResponse( new ErrorResponse( throwable ) ); }
}