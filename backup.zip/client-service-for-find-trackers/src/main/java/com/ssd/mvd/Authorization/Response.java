package com.ssd.mvd.Authorization;

@lombok.Data
public final class Response {
    private String message;
    private Integer code;
    private User data;
}
