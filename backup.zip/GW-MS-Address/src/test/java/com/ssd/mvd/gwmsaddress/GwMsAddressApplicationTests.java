package com.ssd.mvd.gwmsaddress;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GwMsAddressApplicationTests {

    @Test
    void contextLoads() {
    }

}
