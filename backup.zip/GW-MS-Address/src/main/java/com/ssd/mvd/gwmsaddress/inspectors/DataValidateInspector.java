package com.ssd.mvd.gwmsaddress.inspectors;

import com.ssd.mvd.gwmsaddress.entity.modelForAddress.PermanentRegistration;
import com.ssd.mvd.gwmsaddress.entity.modelForPassport.ModelForPassport;
import com.ssd.mvd.gwmsaddress.entity.modelForPassport.Person;

import reactor.netty.http.client.HttpClientResponse;
import reactor.core.publisher.Mono;
import reactor.netty.ByteBufMono;

import java.util.function.BiPredicate;
import java.util.function.Function;
import java.util.Optional;
import java.util.List;

public class DataValidateInspector {
    private final static DataValidateInspector instance = new DataValidateInspector();

    public static DataValidateInspector getInstance () { return instance; }

    protected <T> Mono< T > convert ( final T o ) { return Optional.ofNullable( o ).isPresent() ? Mono.just( o ) : Mono.empty(); }

    public final BiPredicate< Integer, Object > checkData = ( integer, o ) -> switch ( integer ) {
            case 5 -> o != null;
            case 1 -> o != null && String.valueOf( o ).length() > 1;
            case 2 -> o != null && !( ( List< ? > ) o ).isEmpty();
            case 3 -> o != null
                    && ( (ModelForPassport) o ).getData() != null
                    && ( (ModelForPassport) o ).getData().getPerson() != null
                    && ( (ModelForPassport) o ).getData().getPerson().getSex() != null;

            case 4 -> o != null
                    && ( (ModelForPassport) o ).getData() != null
                    && ( (ModelForPassport) o ).getData().getDocument() != null
                    && ( (ModelForPassport) o ).getData().getDocument().getSerialNumber() != null;

            default -> o != null
                    && ( (PermanentRegistration) o ).getPAddress() != null
                    && !( (PermanentRegistration) o ).getPAddress().isEmpty(); };

    public final Function< Person, String > getFullName = person ->
            String.join( " ",
                    person.getNameLatin(),
                    person.getSurnameLatin(),
                    person.getPatronymLatin() );

    protected final BiPredicate< HttpClientResponse, ByteBufMono > checkResponse =
            ( httpClientResponse, byteBufMono ) -> byteBufMono != null && httpClientResponse.status().code() == 200;
}
