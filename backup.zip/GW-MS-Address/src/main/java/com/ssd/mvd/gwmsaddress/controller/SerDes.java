package com.ssd.mvd.gwmsaddress.controller;

import com.ssd.mvd.gwmsaddress.entity.modelForPassport.ModelForPassport;
import com.ssd.mvd.gwmsaddress.entity.modelForAddress.ModelForAddress;
import com.ssd.mvd.gwmsaddress.publisher.CustomPublisherForRequest;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.ssd.mvd.gwmsaddress.constants.Methods;
import com.ssd.mvd.gwmsaddress.constants.Errors;
import com.ssd.mvd.gwmsaddress.config.Config;
import com.ssd.mvd.gwmsaddress.entity.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.gson.Gson;

import reactor.netty.transport.logging.AdvancedByteBufFormat;
import reactor.netty.http.client.HttpClient;
import io.netty.handler.logging.LogLevel;
import reactor.netty.ByteBufFlux;

import com.mashape.unirest.http.ObjectMapper;
import com.mashape.unirest.http.Unirest;

import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;

import java.util.concurrent.TimeUnit;
import java.util.function.BiFunction;
import java.util.function.Supplier;
import java.util.function.Function;
import java.time.Duration;
import java.util.Optional;

@lombok.Data
public final class SerDes extends Config implements Runnable {
    private Thread thread;
    private final Gson gson = new Gson();
    private static SerDes serDes = new SerDes();
    private final HttpClient httpClient = HttpClient
            .create()
            .responseTimeout( Duration.ofSeconds( 30 ) )
            .headers( h -> h.add( "Content-Type", "application/json" ) )
            .wiretap( "reactor.netty.http.client.HttpClient", LogLevel.DEBUG, AdvancedByteBufFormat.TEXTUAL );

    public static SerDes getSerDes () { return serDes != null ? serDes : ( serDes = new SerDes() ); }

    private SerDes () {
        Unirest.setObjectMapper( new ObjectMapper() {
            private final com.fasterxml.jackson.databind.ObjectMapper objectMapper = new com.fasterxml.jackson.databind.ObjectMapper();

            @Override
            public String writeValue( Object o ) {
                try { return this.objectMapper.writeValueAsString( o ); }
                catch ( JsonProcessingException e ) { throw new RuntimeException(e); } }

            @Override
            public <T> T readValue( String s, Class<T> aClass ) {
                try { return this.objectMapper.readValue( s, aClass ); }
                catch ( JsonProcessingException e ) { throw new RuntimeException(e); } } } );
        this.getHeaders().put( "accept", "application/json" );
        this.setThread( new Thread( this, this.getClass().getName() ) );
        this.getThread().start(); }

    private final Supplier< SerDes > updateTokens = () -> {
            super.logging( "Updating tokens..." );
            super.getFields().put( "Login", super.LOGIN_FOR_GAI_TOKEN );
            super.getFields().put( "Password" , super.PASSWORD_FOR_GAI_TOKEN );
            super.getFields().put( "CurrentSystem", super.CURRENT_SYSTEM_FOR_GAI );
            try { super.setTokenForGai( String.valueOf( Unirest.post( super.API_FOR_GAI_TOKEN )
                    .fields( super.getFields() )
                    .asJson()
                    .getBody()
                    .getObject()
                    .get( "access_token" ) ) );
                super.setTokenForPassport( super.getTokenForGai() );
                super.setWaitingMins( 180 );
                super.setFlag( true );
                return this; }
            catch ( final UnirestException e ) {
                super.setFlag( false );
                super.setWaitingMins( 3 );
                super.saveErrorLog( e.getMessage() );
                super.saveErrorLog( Methods.UPDATE_TOKENS.name(),
                        "access_token",
                        "Error: " + e.getMessage() );
                this.getUpdateTokens().get(); }
            return this; };

    private final Function< String, String > base64ToLink = base64 -> {
            super.getFields().clear();
            super.getFields().put( "photo", base64 );
            super.getFields().put( "serviceName", "psychologyCard" );
            try { super.logging( "Converting image to Link in: " + Methods.CONVERT_BASE64_TO_LINK );
                return Optional.ofNullable( Unirest.post( super.BASE64_IMAGE_TO_LINK_CONVERTER_API )
                        .header("Content-Type", "application/json")
                        .body( "{\r\n    \"serviceName\" : \"psychologyCard\",\r\n    \"photo\" : \"" + base64 + "\"\r\n}" )
                        .asJson() )
                        .filter( jsonNodeHttpResponse -> jsonNodeHttpResponse.getStatus() == 200 )
                        .map( jsonNodeHttpResponse -> jsonNodeHttpResponse
                                .getBody()
                                .getObject()
                                .get( "data" )
                                .toString() )
                        .orElse( Errors.DATA_NOT_FOUND.name() ); }
            catch ( final UnirestException e ) {
                super.logging( e, Methods.BASE64_TO_LINK, base64 );
                super.saveErrorLog( super.BASE64_IMAGE_TO_LINK_CONVERTER_API,
                        Methods.CONVERT_BASE64_TO_LINK.name(),
                        "Error: " + e.getMessage() );
                return Errors.SERVICE_WORK_ERROR.name(); } };

    private final Function< String, Mono< Pinpp > > getPinpp = pinfl -> this.getHttpClient()
            .headers( h -> h.add( "Authorization", "Bearer " + super.getTokenForPassport() ) )
            .get()
            .uri( super.API_FOR_PINPP + pinfl )
            .responseSingle( ( res, content ) -> switch ( res.status().code() ) {
                case 401 -> this.getUpdateTokens().get().getGetPinpp().apply( pinfl );
                case 500 | 501 | 502 | 503 -> ( Mono< Pinpp > ) super.saveErrorLog.apply( res.status().toString(), Methods.GET_PINPP );
                default -> super.checkResponse.test( res, content )
                        ? content
                        .asString()
                        .map( s -> this.getGson().fromJson( s, Pinpp.class ) )
                        : super.convert( new Pinpp( super.getDataNotFoundErrorResponse.apply( pinfl ) ) ); } )
            .retryWhen( Retry.backoff( 2, Duration.ofSeconds( 3 ) )
                    .doBeforeRetry( retrySignal -> super.logging( retrySignal, Methods.GET_PINPP ) )
                    .doAfterRetry( retrySignal -> super.logging( Methods.GET_PINPP, retrySignal ) )
                    .onRetryExhaustedThrow( ( retryBackoffSpec, retrySignal ) -> new IllegalArgumentException() ) )
            .onErrorResume( io.netty.channel.ConnectTimeoutException.class,
                    throwable -> super.convert( new Pinpp( super.getConnectionError.apply( throwable.getMessage() ) ) ) )
            .onErrorResume( IllegalArgumentException.class,
                    throwable -> super.convert( new Pinpp( super.getTooManyRetriesError.apply( Methods.GET_PINPP ) ) ) )
            .doOnError( throwable -> super.logging( throwable, Methods.GET_PINPP, pinfl ) )
            .doOnSuccess( value -> super.logging( Methods.GET_PINPP, value ) )
            .doOnSubscribe( value -> super.logging( super.API_FOR_PINPP ) );

    private final Function< String, Mono< ModelForAddress > > getModelForAddress = pinfl -> this.getHttpClient()
            .headers( h -> h.add( "Authorization", "Bearer " + super.getTokenForGai() ) )
            .post()
            .uri( super.API_FOR_MODEL_FOR_ADDRESS )
            .send( ByteBufFlux.fromString( new CustomPublisherForRequest( 1, pinfl ) ) )
            .responseSingle( ( res, content ) -> switch ( res.status().code() ) {
                case 401 -> this.getUpdateTokens().get().getGetModelForAddress().apply( pinfl );
                case 501 | 502 | 503 -> ( Mono< ModelForAddress > ) super.saveErrorLog.apply( res.status().toString(), Methods.GET_MODEL_FOR_ADDRESS );
                default -> super.checkResponse.test( res, content )
                        ? content
                        .asString()
                        .map( s -> this.getGson().fromJson(
                                s.substring( s.indexOf( "Data" ) + 6, s.indexOf( ",\"AnswereId" ) ),
                                ModelForAddress.class ) )
                        : super.convert( new ModelForAddress( super.getDataNotFoundErrorResponse.apply( pinfl ) ) ); } )
            .retryWhen( Retry.backoff( 2, Duration.ofSeconds( 3 ) )
                    .doBeforeRetry( retrySignal -> super.logging( retrySignal, Methods.GET_MODEL_FOR_ADDRESS ) )
                    .doAfterRetry( retrySignal -> super.logging( Methods.GET_MODEL_FOR_ADDRESS, retrySignal ) )
                    .onRetryExhaustedThrow( ( retryBackoffSpec, retrySignal ) -> new IllegalArgumentException() ) )
            .onErrorResume( io.netty.channel.ConnectTimeoutException.class,
                    throwable -> super.convert( new ModelForAddress( super.getConnectionError.apply( throwable.getMessage() ) ) ) )
            .onErrorResume( IllegalArgumentException.class,
                    throwable -> super.convert( new ModelForAddress( super.getTooManyRetriesError.apply( Methods.GET_MODEL_FOR_ADDRESS ) ) ) )
            .doOnError( e -> super.logging( e, Methods.GET_MODEL_FOR_ADDRESS, pinfl ) )
            .doOnSuccess( value -> super.logging( Methods.GET_MODEL_FOR_ADDRESS, value ) )
            .doOnSubscribe( value -> super.logging( super.API_FOR_MODEL_FOR_ADDRESS ) )
            .onErrorReturn( new ModelForAddress( super.getServiceErrorResponse.apply( Errors.SERVICE_WORK_ERROR.name() ) ) );

    private final BiFunction< String, String, Mono< ModelForPassport > > getModelForPassport =
            ( SerialNumber, BirthDate ) -> this.getHttpClient()
                    .headers( h -> h.add( "Authorization", "Bearer " + super.getTokenForPassport() ) )
                    .post()
                    .uri( super.API_FOR_PASSPORT_MODEL )
                    .send( ByteBufFlux.fromString( new CustomPublisherForRequest( 0, SerialNumber + " " + BirthDate ) ) )
                    .responseSingle( ( res, content ) -> switch ( res.status().code() ) {
                        case 401 -> this.getUpdateTokens().get().getGetModelForPassport().apply( SerialNumber, BirthDate );
                        case 501 | 502 | 503 -> ( Mono< ModelForPassport > ) super.saveErrorLog.apply( res.status().toString(), Methods.GET_MODEL_FOR_PASSPORT );
                        default -> super.checkResponse.test( res, content )
                                ? content
                                .asString()
                                .map( s -> this.getGson().fromJson( s, ModelForPassport.class ) )
                                : super.convert( new ModelForPassport(
                                        super.getDataNotFoundErrorResponse.apply( SerialNumber + " : " + SerialNumber ) ) ); } )
                    .retryWhen( Retry.backoff( 2, Duration.ofSeconds( 3 ) )
                            .doBeforeRetry( retrySignal -> super.logging( retrySignal, Methods.GET_MODEL_FOR_PASSPORT ) )
                            .doAfterRetry( retrySignal -> super.logging( Methods.GET_MODEL_FOR_PASSPORT, retrySignal ) )
                            .onRetryExhaustedThrow( ( retryBackoffSpec, retrySignal ) -> new IllegalArgumentException() ) )
                    .onErrorResume( io.netty.channel.ConnectTimeoutException.class,
                            throwable -> super.convert( new ModelForPassport( super.getConnectionError.apply( throwable.getMessage() ) ) ) )
                    .onErrorResume( IllegalArgumentException.class,
                            throwable -> super.convert( new ModelForPassport( super.getTooManyRetriesError.apply( Methods.GET_MODEL_FOR_PASSPORT ) ) ) )
                    .doOnError( e -> super.logging( e, Methods.GET_MODEL_FOR_PASSPORT, SerialNumber + "_" + BirthDate ) )
                    .doOnSuccess( value -> super.logging( Methods.GET_MODEL_FOR_PASSPORT, value ) )
                    .doOnSubscribe( value -> super.logging( super.API_FOR_PASSPORT_MODEL ) )
                    .onErrorReturn( new ModelForPassport( super.getServiceErrorResponse.apply( Errors.SERVICE_WORK_ERROR.name() ) ) );

    private final Function< String, Mono< PsychologyCard > > getPsychologyCardByPinfl = pinfl -> super.checkData.test( 1, pinfl )
            ? this.getGetPinpp().apply( pinfl )
            .flatMap( pinpp -> Mono.zip(
                    this.getGetModelForAddress().apply( pinpp.getPCitizen() ),
                    this.getGetModelForPassport().apply( pinpp.getPassport(), pinpp.getBirthDate() ) )
                    .map( objects -> new PsychologyCard( pinpp, objects ) ) )
            : super.convert( new PsychologyCard( super.getServiceErrorResponse.apply( Errors.WRONG_PARAMS.name() ) ) );

    @Override
    public void run () {
        while ( this.getThread().isAlive() ) {
            this.getUpdateTokens().get();
            try { TimeUnit.MINUTES.sleep( super.getWaitingMins() ); }
            catch ( final InterruptedException e ) {
                serDes = null;
                super.setFlag( false );
                super.logging( e, Methods.UPDATE_TOKENS, "" );
                SerDes.getSerDes(); } }
        SerDes.getSerDes(); }
}