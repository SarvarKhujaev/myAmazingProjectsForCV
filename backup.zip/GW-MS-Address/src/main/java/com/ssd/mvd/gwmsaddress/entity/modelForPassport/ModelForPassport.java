package com.ssd.mvd.gwmsaddress.entity.modelForPassport;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.ssd.mvd.gwmsaddress.constants.ErrorResponse;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public final class ModelForPassport {
    private Integer AnswereId;
    private String AnswereMessage;
    private String AnswereComment;
    @JsonDeserialize
    private com.ssd.mvd.gwmsaddress.entity.modelForPassport.Data Data;

    private ErrorResponse errorResponse;

    public ModelForPassport ( final ErrorResponse errorResponse ) { this.setErrorResponse( errorResponse ); }
}
