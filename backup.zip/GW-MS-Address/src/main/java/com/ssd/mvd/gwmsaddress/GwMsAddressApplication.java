package com.ssd.mvd.gwmsaddress;

import com.ssd.mvd.gwmsaddress.controller.SerDes;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GwMsAddressApplication {
    public static ApplicationContext context;

    public static void main( final String[] args ) {
        context = SpringApplication.run( GwMsAddressApplication.class, args );
        SerDes.getSerDes(); }
}
