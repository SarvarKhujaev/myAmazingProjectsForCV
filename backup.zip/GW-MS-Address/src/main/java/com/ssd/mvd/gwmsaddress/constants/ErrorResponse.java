package com.ssd.mvd.gwmsaddress.constants;

@lombok.Data
@lombok.Builder
public class ErrorResponse {
    private String message;
    private Errors errors;
}
