package com.ssd.mvd.gwmsaddress.entity;

import com.ssd.mvd.gwmsaddress.entity.modelForPassport.ModelForPassport;
import com.ssd.mvd.gwmsaddress.inspectors.DataValidateInspector;
import com.ssd.mvd.gwmsaddress.constants.Errors;

@lombok.Data
public final class Liver {
    private String name;
    private String pinfl;
    private String passport;

    public Liver ( final ModelForPassport modelForPassport, final DataValidateInspector dataValidateInspector ) {
        this.setName( dataValidateInspector
                .checkData
                .test( 3, modelForPassport )
                ? dataValidateInspector
                .getFullName
                .apply( modelForPassport.getData().getPerson() )
                : Errors.DATA_NOT_FOUND.name() );

        this.setPinfl( dataValidateInspector
                .checkData
                .test( 3, modelForPassport )
                ? modelForPassport
                .getData()
                .getPerson()
                .getPinpp()
                : Errors.DATA_NOT_FOUND.name() );

        this.setPassport( dataValidateInspector
                .checkData
                .test( 4, modelForPassport )
                ? modelForPassport
                .getData()
                .getDocument()
                .getSerialNumber()
                : Errors.DATA_NOT_FOUND.name() ); }
}
