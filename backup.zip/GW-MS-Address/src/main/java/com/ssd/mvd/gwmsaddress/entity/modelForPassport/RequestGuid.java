package com.ssd.mvd.gwmsaddress.entity.modelForPassport;

@lombok.Data
public final class RequestGuid {}
