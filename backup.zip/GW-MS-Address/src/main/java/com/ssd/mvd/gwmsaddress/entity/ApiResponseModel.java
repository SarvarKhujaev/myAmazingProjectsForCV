package com.ssd.mvd.gwmsaddress.entity;

import com.ssd.mvd.gwmsaddress.entity.modelForAddress.Address;
import com.ssd.mvd.gwmsaddress.inspectors.DataValidateInspector;

@lombok.Data
@lombok.NoArgsConstructor
public final class ApiResponseModel {
    private Address address;
    private Liver liver;

    public ApiResponseModel ( final PsychologyCard psychologyCard,
                              final Integer value,
                              final DataValidateInspector dataValidateInspector  ) {
        this.setLiver( new Liver( psychologyCard.getModelForPassport(), dataValidateInspector ) );
        if ( value == 1 ) this.setAddress( new Address( psychologyCard.getPinpp() ).save( psychologyCard.getModelForAddress(), dataValidateInspector ) );

        else if ( dataValidateInspector
                    .checkData
                    .test( 2, psychologyCard
                            .getModelForAddress()
                            .getTemproaryRegistration() ) )
                this.setAddress(
                        new Address( psychologyCard.getPinpp() )
                                .save( psychologyCard
                                        .getModelForAddress()
                                        .getTemproaryRegistration() ) );

        else this.setLiver( null ); }
}
