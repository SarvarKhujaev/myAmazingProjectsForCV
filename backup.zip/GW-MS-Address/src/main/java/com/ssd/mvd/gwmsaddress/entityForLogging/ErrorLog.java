package com.ssd.mvd.gwmsaddress.entityForLogging;

@lombok.Data
@lombok.Builder
public final class ErrorLog {
    private Long createdAt;
    private String errorMessage;
    private String integratedService;
    private String integratedServiceApiDescription;
}