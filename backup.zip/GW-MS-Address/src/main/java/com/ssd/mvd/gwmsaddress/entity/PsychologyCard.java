package com.ssd.mvd.gwmsaddress.entity;

import com.ssd.mvd.gwmsaddress.entity.modelForPassport.ModelForPassport;
import com.ssd.mvd.gwmsaddress.entity.modelForAddress.ModelForAddress;
import com.ssd.mvd.gwmsaddress.constants.ErrorResponse;
import reactor.util.function.Tuple2;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public final class PsychologyCard {
    private Pinpp pinpp;
    private ModelForAddress modelForAddress;
    private ModelForPassport modelForPassport;

    private ErrorResponse errorResponse;

    public PsychologyCard ( final ErrorResponse errorResponse ) { this.setErrorResponse( errorResponse ); }

    public PsychologyCard( final Pinpp pinpp, final Tuple2< ModelForAddress, ModelForPassport > tuple ) {
        this.setModelForPassport( tuple.getT2() );
        this.setModelForAddress( tuple.getT1() );
        this.setPinpp( pinpp ); }
}