package com.ssd.mvd.gwmsaddress.config;

import com.ssd.mvd.gwmsaddress.GwMsAddressApplication;
import com.ssd.mvd.gwmsaddress.inspectors.LogInspector;

import java.util.HashMap;
import java.util.Map;

public class Config extends LogInspector {
    private Boolean flag = true;
    public Boolean getFlag() { return this.flag; }

    protected void setFlag( final Boolean flag ) { this.flag = flag; }

    private String tokenForGai;

    protected String getTokenForGai() { return this.tokenForGai; }

    protected void setTokenForGai( final String tokenForGai ) { this.tokenForGai = tokenForGai; }

    private String tokenForPassport;

    protected String getTokenForPassport() { return this.tokenForPassport; }

    protected void setTokenForPassport ( final String tokenForPassport ) { this.tokenForPassport = tokenForPassport; }

    // how many minutes to wait for Thread in SerDes class
    // 180 mins by default
    private Integer waitingMins = 180;

    protected Integer getWaitingMins() { return this.waitingMins; }

    protected void setWaitingMins( final Integer waitingMins ) { this.waitingMins = waitingMins; }

    private final Map< String, Object > fields = new HashMap<>();
    private final Map< String, String > headers = new HashMap<>();

    protected Map< String, Object > getFields() { return this.fields; }

    protected Map< String, String > getHeaders() { return this.headers; }

    protected final String LOGIN_FOR_GAI_TOKEN = GwMsAddressApplication
            .context
            .getEnvironment()
            .getProperty( "variables.GAI_VARIABLES.LOGIN_FOR_GAI_TOKEN" );

    protected final String CURRENT_SYSTEM_FOR_GAI = GwMsAddressApplication
            .context
            .getEnvironment()
            .getProperty( "variables.GAI_VARIABLES.CURRENT_SYSTEM_FOR_GAI" );

    protected final String PASSWORD_FOR_GAI_TOKEN = GwMsAddressApplication
            .context
            .getEnvironment()
            .getProperty( "variables.GAI_VARIABLES.PASSWORD_FOR_GAI_TOKEN" );

    protected final String API_FOR_GAI_TOKEN = GwMsAddressApplication
            .context
            .getEnvironment()
            .getProperty( "variables.GAI_VARIABLES.API_FOR_GAI_TOKEN" );

    protected final String API_FOR_PINPP = GwMsAddressApplication
            .context
            .getEnvironment()
            .getProperty( "variables.OVIR_VARIABLES.API_FOR_PINPP" );

    protected final String API_FOR_PASSPORT_MODEL = GwMsAddressApplication
            .context
            .getEnvironment()
            .getProperty( "variables.OVIR_VARIABLES.API_FOR_PASSPORT_MODEL" );

    protected final String API_FOR_MODEL_FOR_ADDRESS = GwMsAddressApplication
            .context
            .getEnvironment()
            .getProperty( "variables.OVIR_VARIABLES.API_FOR_MODEL_FOR_ADDRESS" );

    protected final String BASE64_IMAGE_TO_LINK_CONVERTER_API = GwMsAddressApplication
            .context
            .getEnvironment()
            .getProperty( "variables.OVIR_VARIABLES.BASE64_IMAGE_TO_LINK_CONVERTER_API" );

    protected final String ERROR_LOGS = GwMsAddressApplication
            .context
            .getEnvironment()
            .getProperty( "variables.KAFKA_VARIABLES.KAFKA_TOPICS.ERROR_LOGS" );

    protected final String ADMIN_PANEL = GwMsAddressApplication
            .context
            .getEnvironment()
            .getProperty( "variables.KAFKA_VARIABLES.KAFKA_TOPICS.ADMIN_PANEL" );

    protected final String ADMIN_PANEL_ERROR_LOG = GwMsAddressApplication
            .context
            .getEnvironment()
            .getProperty( "variables.KAFKA_VARIABLES.KAFKA_TOPICS.ADMIN_PANEL_ERROR_LOG" );
}
