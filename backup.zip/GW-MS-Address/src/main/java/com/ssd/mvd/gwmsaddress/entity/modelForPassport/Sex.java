package com.ssd.mvd.gwmsaddress.entity.modelForPassport;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public final class Sex {
    private Integer Id;
    private String Value;
    private String IdValue;
}
