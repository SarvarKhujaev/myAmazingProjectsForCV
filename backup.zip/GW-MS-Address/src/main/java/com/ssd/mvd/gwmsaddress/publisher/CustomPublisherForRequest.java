package com.ssd.mvd.gwmsaddress.publisher;

import com.ssd.mvd.gwmsaddress.request.RequestForModelOfAddress;
import com.ssd.mvd.gwmsaddress.request.RequestForPassport;
import com.ssd.mvd.gwmsaddress.inspectors.LogInspector;
import com.ssd.mvd.gwmsaddress.controller.SerDes;

import org.reactivestreams.Subscription;
import org.reactivestreams.Subscriber;
import org.reactivestreams.Publisher;

public final class CustomPublisherForRequest extends LogInspector implements Publisher< String > {
    private final String value;

    public CustomPublisherForRequest ( final Integer integer, final Object object ) {
        this.value = SerDes
            .getSerDes()
            .getGson()
            .toJson( integer == 0 ? new RequestForPassport( String.valueOf( object ) )
                    : new RequestForModelOfAddress( String.valueOf( object ) ) ); }

    @Override
    public void subscribe( final Subscriber subscriber ) { subscriber.onSubscribe( new Subscription() {
        @Override
        public void request( final long l ) {
            subscriber.onNext( value );
            subscriber.onComplete(); }

        @Override
        public void cancel() { subscriber.onError( new Exception( "Message was not sent!!!" ) ); } } ); }
}
