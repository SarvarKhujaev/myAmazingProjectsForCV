package com.ssd.mvd.gwmsaddress.entity.modelForAddress;

import com.ssd.mvd.gwmsaddress.inspectors.DataValidateInspector;
import com.ssd.mvd.gwmsaddress.entity.Pinpp;
import java.util.List;

@lombok.Data
public final class Address {
    private String region;
    private String cadastr;
    private String country;
    private String address;
    private String district;
    private String dateOfRegister;

    public Address ( final Pinpp pinpp ) {
        this.setRegion( pinpp.getRegion() );
        this.setCountry( pinpp.getCountry() );
        this.setCadastr( pinpp.getCadastre() );
        this.setDistrict( pinpp.getDistrict() ); }

    public Address save ( final ModelForAddress modelForAddress,
                          final DataValidateInspector dataValidateInspector ) {
        if ( dataValidateInspector
                .checkData
                .test( 5, modelForAddress )
            && dataValidateInspector
                .checkData
                .test( 0, modelForAddress.getPermanentRegistration() ) ) {
            this.setAddress( modelForAddress.getPermanentRegistration().getPAddress() );
            this.setDateOfRegister( modelForAddress.getPermanentRegistration().getPRegistrationDate() ); }
        return this; }

    public Address save ( final List< TemproaryRegistration > temproaryRegistration ) {
        this.setDateOfRegister( temproaryRegistration.get( 0 ).getPRegistrationDate() );
        this.setAddress( temproaryRegistration.get( 0 ).getPAddress() );
        return this; }
}