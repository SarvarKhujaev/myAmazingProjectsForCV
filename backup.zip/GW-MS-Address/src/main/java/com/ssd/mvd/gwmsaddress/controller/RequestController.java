package com.ssd.mvd.gwmsaddress.controller;

import com.ssd.mvd.gwmsaddress.inspectors.DataValidateInspector;
import com.ssd.mvd.gwmsaddress.entity.ApiResponseModel;
import com.ssd.mvd.gwmsaddress.inspectors.LogInspector;

import com.googlecode.jsonrpc4j.spring.AutoJsonRpcServiceImpl;
import com.googlecode.jsonrpc4j.JsonRpcService;
import org.springframework.stereotype.Service;
import com.googlecode.jsonrpc4j.JsonRpcMethod;
import com.googlecode.jsonrpc4j.JsonRpcParam;

@Service
@AutoJsonRpcServiceImpl
@JsonRpcService( value = "/api/v1/address" )
public final class RequestController extends LogInspector {
    @JsonRpcMethod( value = "permanent.by.pinfl" ) // находит данные по дате рождения и паспорту и возвращает постоянное место жительства
    public ApiResponseModel getPersonPermanentAddress ( @JsonRpcParam( value = "pinfl" ) final String pinfl ) {
        super.logging( "PINFL: " + pinfl );
        return SerDes.getSerDes().getFlag()
                ? new ApiResponseModel( SerDes
                .getSerDes()
                .getGetPsychologyCardByPinfl()
                .apply( pinfl )
                .block(), 1, DataValidateInspector.getInstance() )
                : super.getErrorResponse.get(); }

    @JsonRpcMethod( value = "temporary.by.pinfl" ) // находит данные по дате рождения и паспорту и возвращает временное место жительства
    public ApiResponseModel getPersonTemporaryAddress ( @JsonRpcParam( value = "pinfl" ) final String pinfl ) {
        super.logging( "PINFL: " + pinfl );
        return SerDes.getSerDes().getFlag()
                ? new ApiResponseModel( SerDes
                .getSerDes()
                .getGetPsychologyCardByPinfl()
                .apply( pinfl )
                .block(), 2, DataValidateInspector.getInstance() )
                : super.getErrorResponse.get(); }
}