package com.ssd.mvd.gwmsaddress.entity.modelForAddress;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.ssd.mvd.gwmsaddress.constants.ErrorResponse;
import java.util.List;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public final class ModelForAddress {
    private com.ssd.mvd.gwmsaddress.entity.modelForPassport.RequestGuid RequestGuid;
    private PermanentRegistration PermanentRegistration;
    @JsonDeserialize
    private List< com.ssd.mvd.gwmsaddress.entity.modelForAddress.TemproaryRegistration > TemproaryRegistration;

    private ErrorResponse errorResponse;

    public ModelForAddress ( final ErrorResponse errorResponse ) { this.setErrorResponse( errorResponse ); }
}