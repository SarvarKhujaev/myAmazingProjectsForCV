package com.ssd.mvd.gwmsaddress.constants;

public enum Methods {
    CADASTER,
    GET_PINPP,
    UPDATE_TOKENS,
    BASE64_TO_LINK,
    GET_MODEL_FOR_ADDRESS,
    GET_MODEL_FOR_PASSPORT,
    CONVERT_BASE64_TO_LINK,
}
