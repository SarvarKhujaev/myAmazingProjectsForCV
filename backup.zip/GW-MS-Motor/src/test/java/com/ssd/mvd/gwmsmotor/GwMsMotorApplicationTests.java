package com.ssd.mvd.gwmsmotor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GwMsMotorApplicationTests {

    @Test
    void contextLoads() {
    }

}
