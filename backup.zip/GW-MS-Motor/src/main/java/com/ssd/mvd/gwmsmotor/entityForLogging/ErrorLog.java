package com.ssd.mvd.gwmsmotor.entityForLogging;

@lombok.Data
@lombok.Builder
public final class ErrorLog {
    private Long createdAt;
    private String errorMessage;
    private String integratedService;
    private String integratedServiceApiDescription;
}