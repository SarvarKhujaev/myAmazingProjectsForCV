package com.ssd.mvd.gwmsmotor.config;

import com.ssd.mvd.gwmsmotor.GwMsMotorApplication;
import com.ssd.mvd.gwmsmotor.controller.LogInspector;

import java.util.HashMap;
import java.util.Map;

public class Config extends LogInspector {

    protected String getLOGIN_FOR_GAI_TOKEN () { return this.LOGIN_FOR_GAI_TOKEN; }

    protected String getCURRENT_SYSTEM_FOR_GAI () { return this.CURRENT_SYSTEM_FOR_GAI; }

    protected String getPASSWORD_FOR_GAI_TOKEN() { return this.PASSWORD_FOR_GAI_TOKEN; }

    protected String getAPI_FOR_GAI_TOKEN() { return this.API_FOR_GAI_TOKEN; }

    protected String getAPI_FOR_TONIROVKA() { return this.API_FOR_TONIROVKA; }

    protected String getAPI_FOR_VEHICLE_DATA() { return this.API_FOR_VEHICLE_DATA; }

    protected String getAPI_FOR_FOR_INSURANCE() { return this.API_FOR_FOR_INSURANCE; }

    protected String getAPI_FOR_VIOLATION_LIST() { return this.API_FOR_VIOLATION_LIST; }

    protected String getAPI_FOR_DOVERENNOST_LIST() { return this.API_FOR_DOVERENNOST_LIST; }

    protected String getAPI_FOR_MODEL_FOR_CAR_LIST() { return this.API_FOR_MODEL_FOR_CAR_LIST; }

    protected String getERROR_LOGS() { return this.ERROR_LOGS; }

    protected String getADMIN_PANEL() { return this.ADMIN_PANEL; }

    protected String getADMIN_PANEL_ERROR_LOG() { return this.ADMIN_PANEL_ERROR_LOG; }

    // how many minutes to wait for Thread in SerDes class
    // 180 mins by default
    private Integer waitingMins = 180;

    protected Integer getWaitingMins() { return this.waitingMins; }

    protected void setWaitingMins ( final Integer waitingMins ) { this.waitingMins = waitingMins; }

    private Boolean flag = true;

    public Boolean getFlag() { return this.flag; }

    protected void setFlag ( final Boolean flag ) { this.flag = flag; }

    private String tokenForGai;

    protected String getTokenForGai() { return this.tokenForGai; }

    protected void setTokenForGai ( final String tokenForGai ) { this.tokenForGai = tokenForGai; }

    private final Map< String, Object > fields = new HashMap<>();
    private final Map< String, String > headers = new HashMap<>();

    protected Map< String, Object > getFields() { return this.fields; }

    protected Map< String, String > getHeaders() { return this.headers; }

    private final String LOGIN_FOR_GAI_TOKEN = GwMsMotorApplication
            .context
            .getEnvironment()
            .getProperty( "variables.GAI_VARIABLES.GAI_AUTHORIZATION.LOGIN_FOR_GAI_TOKEN" );

    private final String CURRENT_SYSTEM_FOR_GAI = GwMsMotorApplication
            .context
            .getEnvironment()
            .getProperty( "variables.GAI_VARIABLES.GAI_AUTHORIZATION.CURRENT_SYSTEM_FOR_GAI" );

    private final String PASSWORD_FOR_GAI_TOKEN = GwMsMotorApplication
            .context
            .getEnvironment()
            .getProperty( "variables.GAI_VARIABLES.GAI_AUTHORIZATION.PASSWORD_FOR_GAI_TOKEN" );

    private final String API_FOR_GAI_TOKEN = GwMsMotorApplication
            .context
            .getEnvironment()
            .getProperty( "variables.GAI_VARIABLES.GAI_SERVICES.API_FOR_GAI_TOKEN" );

    private final String API_FOR_TONIROVKA = GwMsMotorApplication
            .context
            .getEnvironment()
            .getProperty( "variables.GAI_VARIABLES.GAI_SERVICES.API_FOR_TONIROVKA" );

    private final String API_FOR_VEHICLE_DATA = GwMsMotorApplication
            .context
            .getEnvironment()
            .getProperty( "variables.GAI_VARIABLES.GAI_SERVICES.API_FOR_VEHICLE_DATA" );

    private final String API_FOR_FOR_INSURANCE = GwMsMotorApplication
            .context
            .getEnvironment()
            .getProperty( "variables.GAI_VARIABLES.GAI_SERVICES.API_FOR_FOR_INSURANCE" );

    private final String API_FOR_VIOLATION_LIST = GwMsMotorApplication
            .context
            .getEnvironment()
            .getProperty( "variables.GAI_VARIABLES.GAI_SERVICES.API_FOR_VIOLATION_LIST" );

    private final String API_FOR_DOVERENNOST_LIST = GwMsMotorApplication
            .context
            .getEnvironment()
            .getProperty( "variables.GAI_VARIABLES.GAI_SERVICES.API_FOR_DOVERENNOST_LIST" );

    private final String API_FOR_MODEL_FOR_CAR_LIST = GwMsMotorApplication
            .context
            .getEnvironment()
            .getProperty( "variables.GAI_VARIABLES.GAI_SERVICES.API_FOR_MODEL_FOR_CAR_LIST" );

    private final String ERROR_LOGS = GwMsMotorApplication
            .context
            .getEnvironment()
            .getProperty( "variables.KAFKA_VARIABLES.KAFKA_TOPICS.ERROR_LOGS" );

    private final String ADMIN_PANEL = GwMsMotorApplication
            .context
            .getEnvironment()
            .getProperty( "variables.KAFKA_VARIABLES.KAFKA_TOPICS.ADMIN_PANEL" );

    private final String ADMIN_PANEL_ERROR_LOG = GwMsMotorApplication
            .context
            .getEnvironment()
            .getProperty( "variables.KAFKA_VARIABLES.KAFKA_TOPICS.ADMIN_PANEL_ERROR_LOG" );
}
