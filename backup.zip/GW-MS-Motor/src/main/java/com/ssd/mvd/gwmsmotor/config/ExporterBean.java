package com.ssd.mvd.gwmsmotor.config;

import com.googlecode.jsonrpc4j.spring.AutoJsonRpcServiceImplExporter;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Bean;
import org.springframework.http.MediaType;

@Configuration
public class ExporterBean {
        @Bean
        public AutoJsonRpcServiceImplExporter autoJsonRpcServiceImplExporter() {
            AutoJsonRpcServiceImplExporter exp = new AutoJsonRpcServiceImplExporter();
            exp.setContentType(MediaType.APPLICATION_JSON_VALUE);
            return exp; }
}
