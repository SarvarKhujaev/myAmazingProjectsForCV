package com.ssd.mvd.gwmsmotor.config;

import reactor.netty.http.client.HttpClientResponse;
import com.ssd.mvd.gwmsmotor.entity.CarTotalData;

import reactor.core.publisher.Mono;
import reactor.netty.ByteBufMono;

import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.Optional;
import java.util.List;

public class DataValidateInspector {
    private static final DataValidateInspector INSTANCE = new DataValidateInspector();

    public static DataValidateInspector getInstance () { return INSTANCE; }

    protected <T> Mono< T > convert ( final T o ) { return Optional.ofNullable( o ).isPresent() ? Mono.just( o ) : Mono.empty(); }

    public final BiFunction< Object, Integer, Boolean > checkData = ( o, value ) -> switch ( value ) {
            case 1 -> o != null && !( ( List<?> ) o ).isEmpty();
            case 2 -> o != null && !String.valueOf( o ).isEmpty();
            default -> ( (CarTotalData) o ).getModelForCarList() != null
                    && ( (CarTotalData) o )
                    .getModelForCarList()
                    .getModelForCarList() != null
                    && !( (CarTotalData) o )
                    .getModelForCarList()
                    .getModelForCarList()
                    .isEmpty(); };

    protected final Function< Integer, Integer > checkDifference = integer -> integer > 0 && integer < 100 ? integer : 10;

    protected final BiFunction<HttpClientResponse, ByteBufMono, Boolean > checkResponse =
            ( httpClientResponse, byteBufMono ) -> byteBufMono != null && httpClientResponse.status().code() == 200;
}
