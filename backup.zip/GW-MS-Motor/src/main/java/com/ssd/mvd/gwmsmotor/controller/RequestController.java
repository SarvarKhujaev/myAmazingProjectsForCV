package com.ssd.mvd.gwmsmotor.controller;

import com.googlecode.jsonrpc4j.spring.AutoJsonRpcServiceImpl;
import com.googlecode.jsonrpc4j.JsonRpcService;
import com.googlecode.jsonrpc4j.JsonRpcMethod;
import com.googlecode.jsonrpc4j.JsonRpcParam;

import com.ssd.mvd.gwmsmotor.entity.ApiResponseModel;
import com.ssd.mvd.gwmsmotor.entity.ModelForCarList;
import com.ssd.mvd.gwmsmotor.entity.modelForGai.*;
import org.springframework.stereotype.Service;
import com.ssd.mvd.gwmsmotor.config.Config;

@Service
@AutoJsonRpcServiceImpl
@JsonRpcService( value = "/api/v1/motor" )
public final class RequestController extends LogInspector {
    @JsonRpcMethod( value = "auto.carList.by.gosNumber" ) // находит данные о машинах по пинфл человека
    public ModelForCarList getCarList ( @JsonRpcParam( value = "pinfl" ) final String pinfl ) {
        super.logging( "getCarList: " + pinfl );
        return SerDes.getSerDes().getFlag()
                ? SerDes
                .getSerDes()
                .getGetModelForCarList()
                .apply( pinfl )
                .block()
                : new ModelForCarList( super.getErrorResponse.get() ); }

    @JsonRpcMethod( value = "auto.data.by.gosNumber" ) // находит данные о машине по номеру
    public ModelForCar getCarData ( @JsonRpcParam( value = "gosNumber" ) final String gosNumber ) {
        super.logging( "getCarData: " + gosNumber );
        return SerDes.getSerDes().getFlag()
                ? SerDes
                .getSerDes()
                .getGetVehicleData()
                .apply( gosNumber )
                .block()
                : new ModelForCar( super.getErrorResponse.get() ); }

    @JsonRpcMethod( value = "auto.tonirovka.by.gosNumber" ) // находит данные о тонировке машины
    public Tonirovka getCarTonirovka ( @JsonRpcParam( value = "gosNumber" ) final String gosNumber ) {
        super.logging( "getCarTonirovka: " + gosNumber );
        return SerDes.getSerDes().getFlag()
                ? SerDes
                .getSerDes()
                .getGetVehicleTonirovka()
                .apply( gosNumber )
                .block()
                : new Tonirovka( super.getErrorResponse.get() ); }

    @JsonRpcMethod( value = "auto.insurance.by.gosNumber" ) // находит данные о страховке машины
    public Insurance getCarInsurance ( @JsonRpcParam( value = "gosNumber" ) final String gosNumber ) {
        super.logging( "getCarInsurance: " + gosNumber );
        return SerDes.getSerDes().getFlag()
                ? SerDes
                .getSerDes()
                .getInsurance()
                .apply( gosNumber )
                .block()
                : new Insurance( super.getErrorResponse.get() ); }

    @JsonRpcMethod( value = "auto.violations.by.gosNumber" ) // находит данные о штрафах
    public ViolationsList getCarViolations ( @JsonRpcParam( value = "gosNumber" ) final String gosNumber ) {
        super.logging( "getCarViolations: " + gosNumber );
        return SerDes.getSerDes().getFlag()
                ? SerDes
                .getSerDes()
                .getGetViolationList()
                .apply( gosNumber )
                .block()
                : new ViolationsList( super.getErrorResponse.get() ); }

    @JsonRpcMethod( value = "auto.doverennost.by.gosNumber" ) // находит данные о доверенности
    public DoverennostList getCarDoverennostList ( @JsonRpcParam( value = "gosNumber" ) final String gosNumber ) {
        super.logging( "getCarDoverennostList: " + gosNumber );
        return SerDes.getSerDes().getFlag()
                ? SerDes
                .getSerDes()
                .getGetDoverennostList()
                .apply( gosNumber )
                .block()
                : new DoverennostList( super.getErrorResponse.get() ); }

    @JsonRpcMethod( value = "auto.by.pinfl" ) // находит данные о машинах по пинфл человека
    public ApiResponseModel getPersonTotalDataByPinfl ( @JsonRpcParam( value = "pinfl" ) final String pinfl ) {
        super.logging( "getPersonTotalDataByPinfl: " + pinfl );
        if ( !SerDes.getSerDes().getFlag() ) SerDes.getSerDes().getUpdateTokens().get();

        return SerDes.getSerDes().getFlag()
                ? super.checkData.apply( pinfl, 2 )
                ? new ApiResponseModel( SerDes
                .getSerDes()
                .getGetModelForCarList()
                .apply( pinfl )
                .block() )
                : new ApiResponseModel()
                : new ApiResponseModel(); }
}