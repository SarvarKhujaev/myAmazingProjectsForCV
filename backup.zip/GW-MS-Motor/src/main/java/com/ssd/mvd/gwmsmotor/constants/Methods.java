package com.ssd.mvd.gwmsmotor.constants;

public enum Methods {
    CADASTER,
    GET_PINPP,
    GET_INSURANCE,
    GET_TONIROVKA,
    UPDATE_TOKENS,
    BASE64_TO_LINK,
    GET_VEHILE_DATA,
    GET_VIOLATION_LIST,
    GET_DOVERENNOST_LIST,
    GET_MODEL_FOR_CAR_LIST,
}
