package com.ssd.mvd.gwmsmotor.entity.modelForGai;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public final class pDistrict {
    private Integer Id;
    private String value;
    private String IdValue;
}
