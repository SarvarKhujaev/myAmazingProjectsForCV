package com.ssd.mvd.gwmsmotor.entity.modelForGai;

@lombok.Data
public final class Doverennost {
    private String DateBegin;
    private String DateValid;
    private String IssuedBy;
}
