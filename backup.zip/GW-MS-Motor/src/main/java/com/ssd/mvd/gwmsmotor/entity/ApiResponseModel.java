package com.ssd.mvd.gwmsmotor.entity;

import com.ssd.mvd.gwmsmotor.entity.modelForGai.ModelForCar;
import com.ssd.mvd.gwmsmotor.config.DataValidateInspector;
import java.util.List;

@lombok.Data
public final class ApiResponseModel {
    private Integer count;
    private List< ModelForCar > modelForCarList;

    public ApiResponseModel () {}

    public ApiResponseModel ( final ModelForCarList modelForCarList ) {
        this.setCount( DataValidateInspector
                .getInstance()
                .checkData
                .apply( modelForCarList.getModelForCarList(), 1 )
                ? modelForCarList.getModelForCarList().size()
                : 0 );
        this.setModelForCarList( modelForCarList.getModelForCarList() ); }
}
